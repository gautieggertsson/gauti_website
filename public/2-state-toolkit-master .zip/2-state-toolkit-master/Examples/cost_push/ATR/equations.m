% Equations
eq.is     = 1;  % comment
eq.pc     = 2;  % comment
eq.i_tr   = 3;  % comment
eq.z      = 4;  % comment

eq.r      = 5;  % comment
eq.rstar  = 6;  % comment
eq.cps    = 7;  % cost push shock

eq.rule   = 8;  % interest rate