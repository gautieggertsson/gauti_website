% Variables
vars.x     = 1;   % comment
vars.pi    = 2;   % comment
vars.i_tr  = 3;   % comment
vars.i     = 4;   % comment
vars.z     = 5;   % comment
vars.rstar = 6;   % comment
vars.r     = 7;   % comment
vars.u_s   = 8;   % cost push shock