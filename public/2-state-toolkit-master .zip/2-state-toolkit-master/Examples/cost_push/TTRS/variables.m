% Variables
vars.x      = 1;
vars.pi     = 2;
vars.i      = 3;      

vars.x_lag  = 4;
vars.pi_lag = 5;
vars.i_lag  = 6;     

vars.rstar  = 7;
vars.r      = 8;
vars.u_s    = 9;   % cost push shock