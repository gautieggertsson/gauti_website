% Equations
eq.is    = 1;  % comment
eq.pc    = 2;  % comment
eq.pl    = 3;  % price level def.
eq.real  = 4;
eq.ngdpc = 5;  % cumulated nominal gdp def.

eq.rstar = 6;  % comment
eq.r     = 7;  % comment
eq.cps   = 8;  % cost push shock

eq.rule  = 9;  % comment