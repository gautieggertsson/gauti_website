% Equations
eq.is    = 1;  % comment
eq.pc    = 2;  % comment
eq.pl    = 3;  % comment

eq.rstar = 4;  % comment
eq.r     = 5;  % comment
eq.cps   = 6;  % cost push shock

eq.rule  = 7;  % comment