% Variables
vars.x     = 1;   % comment
vars.pi    = 2;   % comment
vars.real  = 3;
vars.i     = 4;   % comment

vars.p_lag = 5;   % comment
vars.y_lag = 6;   % comment

vars.rstar = 7;   % comment
vars.r     = 8;   % comment
vars.u_s   = 9;   % cost push shock