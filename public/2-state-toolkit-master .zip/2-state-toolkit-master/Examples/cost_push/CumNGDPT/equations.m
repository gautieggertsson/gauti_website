% Equations
eq.is    = 1;  % comment
eq.pc    = 2;  % comment
eq.pl    = 3;  % price level def.
eq.ngdpc = 4;  % cumulated nominal gdp def.
eq.real   = 5;

eq.r     = 6;  % comment
eq.rstar = 7;  % comment
eq.cps   = 8;  % cost push shock

eq.rule  = 9;  % comment