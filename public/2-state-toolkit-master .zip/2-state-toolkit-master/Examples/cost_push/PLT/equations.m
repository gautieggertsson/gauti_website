% Equations
eq.is     = 1;  % comment
eq.pc     = 2;  % comment
eq.pl     = 3;  % comment

eq.r      = 4;  % comment
eq.cps    = 5;  % cost push shock

eq.rule   = 6;  % comment