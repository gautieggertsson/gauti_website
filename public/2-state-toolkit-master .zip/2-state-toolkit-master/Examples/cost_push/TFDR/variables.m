% variables
vars.x      = 1;
vars.pi     = 2;
vars.i      = 3;
vars.i_lag  = 4;
vars.r      = 5;
vars.u_s    = 6;   % cost push shock