% Equations
eq.is     = 1;  % comment
eq.pc     = 2;  % comment
eq.foc_x  = 3;  % comment
eq.foc_pi = 4;  % comment
eq.real   = 5;

eq.r      = 6;  % interest rate shoch
eq.cps    = 7;  % cost push shock

eq.i      = 8;  % interest rate