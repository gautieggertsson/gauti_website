% Variables
vars.x       = 1;   % comment
vars.pi      = 2;   % comment
vars.real    = 3;
vars.i       = 4;   % comment      
vars.phi1    = 5;   % comment
vars.phi2    = 6;   % comment
vars.r       = 7;   % comment 
vars.u_s     = 8;   % cost push shock