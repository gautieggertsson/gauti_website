% Variables
vars.x        = 1;   % comment
vars.pi       = 2;   % comment
vars.i        = 3;   % comment

vars.pi_lag1  = 4;
vars.pi_lag2  = 5;
vars.pi_lag3  = 6;
vars.pi_lag4  = 7;
vars.pi_lag5  = 8;
vars.pi_lag6  = 9;
vars.pi_lag7  = 10;
vars.pi_lag8  = 11;
vars.pi_lag9  = 12;
vars.pi_lag10 = 13;
vars.pi_lag11 = 14;
vars.pi_lag12 = 15;
vars.pi_lag13 = 16;
vars.pi_lag14 = 17;
vars.pi_lag15 = 18;
vars.pi_lag16 = 19;
vars.pi_lag17 = 20;
vars.pi_lag18 = 21;
vars.pi_lag19 = 22;

vars.rstar    = 23;
vars.r        = 24;  % comment
vars.u_s      = 25;  % cost push shock