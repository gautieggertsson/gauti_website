% Equations
eq.is       = 1;  % comment
eq.pc       = 2;  % comment

eq.pi_lag1  = 3;
eq.pi_lag2  = 4;
eq.pi_lag3  = 5;
eq.pi_lag4  = 6;
eq.pi_lag5  = 7;
eq.pi_lag6  = 8;
eq.pi_lag7  = 9;
eq.pi_lag8  = 10;
eq.pi_lag9  = 11;
eq.pi_lag10 = 12;
eq.pi_lag11 = 13;
eq.pi_lag12 = 14;
eq.pi_lag13 = 15;
eq.pi_lag14 = 16;
eq.pi_lag15 = 17;
eq.pi_lag16 = 18;
eq.pi_lag17 = 19;
eq.pi_lag18 = 20;
eq.pi_lag19 = 21;

eq.rstar    = 22;
eq.r        = 23;  % comment
eq.cps      = 24;  % cost push shock

eq.rule     = 25;  % interest rate