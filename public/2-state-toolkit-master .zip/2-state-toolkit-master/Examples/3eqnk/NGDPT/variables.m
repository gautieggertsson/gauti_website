% Variables
vars.x     = 1;   % comment
vars.pi    = 2;   % comment
vars.i     = 3;   % comment
vars.p_lag = 4;   % comment
vars.rstar = 5;   % comment
vars.r     = 6;   % comment