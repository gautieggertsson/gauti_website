% Equations
eq.is     = 1;  % comment
eq.pc     = 2;  % comment

eq.x_lag  = 3;  % comment
eq.pi_lag = 4;  % comment
eq.i_lag  = 5;  % comment

eq.rstar  = 6;  % comment
eq.r      = 7;  % comment

eq.rule   = 8;  % comment