function f=Gfcn(z,sigma)
f = normcdf(z-sigma);
end
