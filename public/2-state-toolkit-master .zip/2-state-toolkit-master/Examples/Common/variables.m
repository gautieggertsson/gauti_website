% Variables
vars.x      = 1;
vars.pi     = 2;
vars.i_imp  = 3;      
vars.i      = 4;    
vars.x_lag  = 5;
vars.pi_lag = 6;
vars.i_lag  = 7;     

vars.rstar  = 8;
vars.r      = 9;