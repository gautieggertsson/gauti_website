% Equations
eq.is     = 1;  % comment
eq.pc     = 2;  % comment

eq.x_lag  = 3;  % comment
eq.pi_lag = 4;  % comment
eq.i_lag  = 5;  % comment
eq.i_imp  = 6;  % comment

eq.rstar  = 7;  % comment
eq.r      = 8;  % comment

eq.rule   = 9;  % comment