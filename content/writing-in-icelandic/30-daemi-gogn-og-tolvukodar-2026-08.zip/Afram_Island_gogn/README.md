# Afram_Island_gogn: gögn, forrit og myndir greinarinnar

Opinn gagnapakki greinarinnar **„30 dæmi um villandi framsetningu í skýrslu Áfram Íslands: Mat á
fullyrðingu Áfram Íslands um efnahagslega yfirburði Íslands gagnvart
ríkjum Evrópusambandsins“** eftir
Gauta B. Eggertsson (fyrsta útgáfa, 23. ágúst 2026, 82 bls.). Greinin
endurmetur samanburðina úr greiningu Kontext ehf. fyrir RSE og Áfram
Ísland (júlí 2026) með samræmdum tímabilum, sambærilegum mælikvörðum og
samanburði við öll 27 aðildarríki ESB.

Pakkinn geymir frosin frumgögn með heimildarslóð og sóttdagsetningu fyrir
hverja tölu, forritin sem reikna hverja tölu og teikna hverja mynd, og
myndirnar sjálfar eins og þær birtast í greininni. Allt má keyra án
nettengingar.

Greinin fylgir í `grein/Mat_a_fullyrdingu_Afram_Islands_2026.pdf`. Útgáfan
sem pakkinn svarar til er auðkennd með SHA-256 gátsummu PDF-skjalsins:

```
dc03d676c85f74ab624983e7073a93f3c78297702d117a788dc221bd37299d9a
```

## Uppbygging

```
README.md                    þessi lýsing
LEYFI.md                     leyfisskilmálar
GATSUMMUR_SHA256.txt         SHA-256 gátsummur allra gagna- og myndaskráa
grein/                       greinin sjálf (PDF)
myndir/                      myndir greinarinnar, 24 talsins, eins og þær birtast
talnaskra.csv                hver tala greinarinnar: gildi, staður, gagnasafn, skilgreining
forrit/                      run_all.m, reikna_nidurstodur.m, gera_myndir.m,
                             afkoda_jsonstat.m, gera_villudreifing_30.py
gogn/                        gagnagrunnur.csv, handvirk_gogn.csv og hra/ (frosin API-svör)
nidurstodur/                 m1.csv til m11.csv (gagnafylki mynda) og utreikningar.txt
prof/                        sjálfvirk próf (matlab.unittest)
lokagerdgogn/                frystar einingar einstakra mynda: hra/, gogn/, lysigogn/,
                             forrit/ og nidurstodur/ fyrir hverja; sjá lokagerdgogn/README.md
endurgerd/                   verður til við keyrslu forrit/gera_myndir.m
```

## Myndirnar og endurgerð þeirra

Myndirnar í `myndir/` eru skrárnar sem greinin fellir inn, bæti fyrir bæti.
Forritin skrifa endurgerðar myndir í `endurgerd/` (MATLAB) eða í `mynd/`
innan hverrar einingar (Python), svo birtu skrárnar haldist óbreyttar og
bera megi útkomuna saman við þær. Allar skipanir eru gefnar frá rót pakkans.

| Mynd | Skipun |
|---|---|
| `m1_hagvoxtur`, `m2_vlf_starfandi`, `m3_framleidni`, `m3b_framleidnistig`, `m4_ungmenni`, `m5_atvinnuleysi`, `m7_flokt`, `m10_skuldir`, `m12_adhvarf`, `m13_atvinnuleysi` | `matlab -batch "run('forrit/gera_myndir.m')"` (frosin gögn í forritinu sjálfu; sama keyrsla sækir einnig vaxtamyndirnar, verðlagsmyndina og IMD-myndina í einingar þeirra) |
| `styrivextir_bru`, `m8_vextir`, `heimili_60m` | `matlab -batch "run('lokagerdgogn/mynd04_vextir/forrit/gera_vaxtamyndir.m')"` |
| `m2_verdlag` | `matlab -batch "run('lokagerdgogn/mynd02_verdlag/forrit/gera_mynd02.m')"` |
| `m9_imd` | `python3 lokagerdgogn/mynd05_samkeppnishaefni/forrit/gera_mynd05.py` |
| `m15_kaupmattur`, `m15b_kaupmattur_2007` | `python3 lokagerdgogn/mynd15_kaupmattur/forrit/gera_mynd15.py` |
| `m16_radstofunartekjur` | `python3 lokagerdgogn/mynd16_radstofunartekjur/forrit/gera_mynd16.py` |
| `m17_laun_evrur_kaupmattur` | `python3 lokagerdgogn/mynd17_laun_evrur_kaupmattur/forrit/gera_mynd17.py` |
| `m18_vinnandi_hendur` | `python3 lokagerdgogn/mynd18_vinnandi_hendur/forrit/gera_mynd18.py` |
| `m19_neysla` | `python3 lokagerdgogn/mynd19_neysla/forrit/gera_mynd19.py` |
| `m20_d11_d1` | `python3 lokagerdgogn/mynd20_d11_d1/forrit/gera_mynd20.py` |
| `mynd4_oecd` | `python3 lokagerdgogn/mynd_oecd/forrit/gera_mynd_oecd.py` |
| `villudreifing_30` | `python3 forrit/gera_villudreifing_30.py` |

Handfærðu framleiðnigildin í `m3b_framleidnistig` eru prófuð gegn frystu
skránni með `python3 lokagerdgogn/framleidni_kjarna/profa_m3b_samraemi.py`.
Skuldatölurnar í `m10_skuldir` eru í `lokagerdgogn/weo_apr2026_debt/`.

Python-myndirnar eru bæti fyrir bæti eins og birtu skrárnar þegar sömu
útgáfur safnanna eru notaðar. PDF-skrár úr MATLAB bera tímastimpil í
lýsigögnum sínum og eru bornar saman eftir röstun, punkt fyrir punkt.

## Talnaskráin og prófin

Hver tala greinarinnar á sér línu í `talnaskra.csv` (158 línur auk hauss):
númer, gildi í grein, staður í grein, lýsing, gagnasafn eða heimild,
skilgreining stærðarinnar og tegund. Forritið `forrit/reikna_nidurstodur.m`
reiknar hverja tölu að nýju úr `gogn/gagnagrunnur.csv` og
`gogn/handvirk_gogn.csv`, skrifar gagnafylki myndanna í `nidurstodur/m*.csv`
og ber hverja tölu saman við gildið í greininni í
`nidurstodur/utreikningar.txt` með stöðunni OK eða FRÁVIK. Vikmörk hverrar
línu eru hálf eining aftasta birta tugastafs; sæti og talningar eru nákvæm.

```matlab
addpath('forrit')
run_all                 % reiknar og teiknar allt úr frosnu gögnunum, ekkert net
runtests('prof')        % prófasafnið, keyrir án nets
```

Keyrslan telur 204 tölusamanburði; 203 eru innan skekkjumarka og eitt
frávik er skráð og skýrt í `utreikningar.txt`: Seðlabanki Evrópu endurskoðaði
apríltölu Lettlands eftir að gögnin voru fryst (4,18 í grein, 4,15 í
endurskoðuðum gögnum; breytir engri niðurstöðu). Prófasafnið í `prof/`
prófar JSON-stat-afkóðarann gegn þekktum gildum, reitafjölda og gæsalappir
allra CSV-skráa, skema og landafjölda gagnagrunnsins, og burðarniðurstöður
greinarinnar með námundunarvikmörkum birtingarinnar. Prófin breyta engu í
pakkanum.

Krafist er MATLAB R2024b eða nýrra án viðbótarsafna, og Python 3 með
`matplotlib` og `pandas` fyrir Python-forritin. `run_all('refresh')` sækir
gögn að nýju og krefst sækjaranna (`saekja_*.m`), sem fylgja ekki pakkanum;
frosnu gögnin duga til að endurgera og sannprófa hverja tölu.

## Gögnin

`gogn/gagnagrunnur.csv` er ein löng tafla, semíkommuskilin, UTF-8, með
dálkunum `rod;svaedi;timi;gildi;eining;gagnasafn;api_slod;sott_dags`. Hver
lína segir þannig sjálf hvaðan hún kom og hvenær. `gogn/handvirk_gogn.csv`
hefur sama snið með `heimild`, `slod_eda_skjal` og `athugasemd` í stað
API-dálkanna og geymir tölur sem ekkert API þjónar (bankavextir, spár, tölur
greiningarinnar sjálfrar). `gogn/hra/` geymir frosin API-svör orðrétt.
Ríki EES utan ESB koma hvergi fyrir í unnu gögnunum; það er prófað.

Frumgögn og sóttdagsetningar:

- **Eurostat** (`nama_10_gdp`, `nama_10_pc`, `nama_10_lp_ulc`, `tec00114`,
  `tesem160`, `lfsi_emp_a`, `une_rt_a`, `une_rt_m`, `yth_empl_140`,
  `edat_lfse_20`, `lc_lci_lev`, `prc_ppp_ind`, `prc_colc`, `demo_pjan`,
  `met_10r_3gdp`, `gov_10dd_edpt1` og fleiri): sótt 12. júlí 2026 í
  meginkeyrsluna; einingar einstakra mynda sóttu sín gögn 14. til 30. júlí
  2026 (`mynd02_verdlag`, `mynd04_vextir`, `framleidni_kjarna`,
  `mynd15_kaupmattur`, `mynd16_radstofunartekjur`, `mynd19_neysla`),
  3. til 4. ágúst 2026 (`mynd17_laun_evrur_kaupmattur`,
  `mynd18_vinnandi_hendur`) og 23. ágúst 2026 (`mynd20_d11_d1`).
- **Alþjóðagjaldeyrissjóðurinn**, World Economic Outlook apríl 2026
  (`GGXWDG_NGDP`): sótt 12. júlí 2026 (meginkeyrsla) og 20. júlí 2026
  (`lokagerdgogn/weo_apr2026_debt`).
- **Seðlabanki Íslands** (gengi, tímaraðir 4055 og 4064; meginvextir;
  væntingakönnun): sótt 12. til 14. júlí 2026 og 20. júlí 2026.
- **Seðlabanki Evrópu** (`eurofxref-hist`, MFI-vaxtatölur, lykilvextir):
  sótt 12. júlí 2026 og 20. júlí 2026.
- **Hagstofa Íslands** (PxWeb-töflur, meðal annars `MAN02005`, `MAN03250`,
  `TEK01002`, `TEK02014`, `TEK01001`, `THJ06020`, `THJ06021`, `THJ01000`,
  `VIS01000`, `VIS01005`): sótt 12. til 21. júlí 2026 og 29. júlí 2026.
- **OECD** (SDMX, höfuðborgarsvæði) og **Alþjóðabankinn** (WDI): sótt
  12. júlí 2026.
- **IMD**, World Competitiveness Booklet 2025: sótt 20. júlí 2026; talnataka
  með blaðsíðutilvísunum í `lokagerdgogn/mynd05_samkeppnishaefni`.
- **ILOSTAT** (meðalmánaðarlaun): í `lokagerdgogn/mynd_oecd`.

Nákvæmar fyrirspurnir, útgáfutímar Eurostat og SHA-256 gátsummur hverrar
skrár eru í `lysigogn/` hverrar einingar og í `GATSUMMUR_SHA256.txt`.
Gagnasafnskóðar og raðir hverrar stærðar eru raktar í Viðauka A
greinarinnar.

## Efni þriðja aðila sem fylgir ekki pakkanum

Til að virða höfundarrétt annarra fylgja eftirtaldar frumheimildir ekki;
þær má nálgast hjá útgefendum og sannreyna með gátsummunum sem skráðar eru:

- *IMD World Competitiveness Booklet 2025* (imd.org); gátsumma í
  `lokagerdgogn/mynd05_samkeppnishaefni/lysigogn/manifest.json`.
- *ECB Survey of Monetary Analysts*, júní 2026 (ecb.europa.eu); gátsumma í
  `lokagerdgogn/mynd04_vextir/lysigogn/MANIFEST.md`.
- Greining Áfram Íslands sjálf (aframisland.is); gátsumma í
  `lokagerdgogn/mynd02_verdlag/lysigogn/manifest.json`.

## Leyfi

Forrit pakkans eru gefin út með MIT-leyfi og gögn, töflur, myndir og texti
höfundar með leyfinu Creative Commons Attribution 4.0 (CC BY 4.0); sjá
`LEYFI.md`. Frosin afrit gagna frá Eurostat, Hagstofu Íslands, Seðlabanka
Íslands, Seðlabanka Evrópu, Alþjóðagjaldeyrissjóðnum, OECD, Alþjóðabankanum
og ILO lúta skilmálum þeirra stofnana, sem heimila endurnot með
tilvísun til heimildar.

## Tengd söfn sama höfundar

- [vextir-utreikningar](https://github.com/gautieggertsson/vextir-utreikningar):
  vaxtagreinin (Eggertsson 2026a).
- [kaupmattur](https://gautieggertsson.github.io/kaupmattur) og
  [svarvisir](https://gautieggertsson.github.io/svarvisir): kaupmáttargreinarnar
  (Eggertsson 2026b; 2026c).
- [Afram_Island_Verd](https://github.com/gautieggertsson/Afram_Island_Verd):
  verðlagsgreinin (Eggertsson 2026d).
- [gautiesb.is](https://gautiesb.is): staðreyndaskoðun OECD-launatölunnar
  (Eggertsson 2026e).

Ábendingar um villur eru vel þegnar: Gauti_Eggertsson@brown.edu.
