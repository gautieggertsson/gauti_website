#!/usr/bin/env python3
"""
Mynd m18_vinnandi_hendur: sami mælikvarði fyrir og eftir leiðréttingu fyrir
sjálfstætt starfandi. Vinstri: launatekjur launþega (D11) á íbúa, raunvirt,
eins og greining Áfram Íslands reiknar (Ísland 4. sæti, 129). Hægri:
vinnutekjur allra vinnandi handa á íbúa (D1 skalað með hlutfalli starfandi og
launþega); Ísland fellur í 6. sæti. Sömu x-kvarðar; efsta súlan er besta sætið.

Gögn: ../gogn/vinnutekjur_allra_2024.csv (fryst tafla úr Eurostat nama_10_a10,
nama_10_a10_e, nasa_10_nf_tr, nama_10_pe og prc_ppp_ind). Ekkert netsamband.
Keyrsla: python3 gera_mynd18.py; myndin skrifast í ../mynd/.
"""
import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

HERE = os.path.dirname(os.path.abspath(__file__))
ROT = os.path.dirname(HERE)
CSV = os.path.join(ROT, "gogn", "vinnutekjur_allra_2024.csv")
FIGS = os.path.join(ROT, "mynd")
os.makedirs(FIGS, exist_ok=True)

EU = "EU27_2020"
RED = "#c8102e"
MUTED = "#9db4c8"
DARK = "#1a1a1a"
GREY = "#8a8a8a"

rows = {}
with open(CSV) as fh:
    for row in csv.DictReader(fh):
        rows[row["geo"]] = row

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                     "axes.edgecolor": "0.75", "axes.linewidth": 0.8})


def ic(x, nd=1):
    return f"{x:.{nd}f}".replace(".", ",")


def panel(ax, key, title, title_color):
    vals = {g: float(r[key]) for g, r in rows.items()}
    # hæst efst = besta sætið efst (regla myndanna um röðun)
    order = sorted(vals, key=lambda g: -vals[g])
    ypos = list(range(len(order)))[::-1]
    colors = [RED if g == "IS" else (DARK if g == EU else MUTED)
              for g in order]
    ax.barh(ypos, [vals[g] for g in order], height=0.62, color=colors,
            zorder=3)
    for y, g in zip(ypos, order):
        ax.text(vals[g] + 3.5, y, ic(vals[g]), va="center", ha="left",
                fontsize=8.0,
                fontweight="bold" if g in ("IS", EU) else "normal",
                color=RED if g == "IS" else (DARK if g == EU else "0.35"))
    ax.set_yticks(ypos)
    ax.set_yticklabels([rows[g]["name"] for g in order], fontsize=8.8)
    for tick, g in zip(ax.get_yticklabels(), order):
        if g == "IS":
            tick.set_color(RED)
            tick.set_fontweight("bold")
        elif g == EU:
            tick.set_fontweight("bold")
    ax.set_xlim(0, 268)
    ax.xaxis.set_major_locator(mticker.MultipleLocator(50))
    ax.xaxis.set_major_formatter(
        mticker.FuncFormatter(lambda v, _: ic(v, 0)))
    for s in ["top", "right", "left"]:
        ax.spines[s].set_visible(False)
    ax.grid(axis="x", color="0.88", lw=0.8, zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(length=0)
    ax.set_title(title, fontsize=10.6, fontweight="bold", color=title_color,
                 loc="left", pad=10)
    ax.set_xlabel("vísitala, ESB = 100", fontsize=8, color=GREY)
    return vals, order, ypos


fig, (axL, axR) = plt.subplots(1, 2, figsize=(12.6, 9.4))
fig.subplots_adjust(top=0.825, bottom=0.10, left=0.095, right=0.985,
                    wspace=0.44)

valsL, orderL, yposL = panel(
    axL, "idx_d11",
    "Eins og glærurnar reikna: launatekjur\nlaunþega á íbúa", DARK)
valsR, orderR, yposR = panel(
    axR, "idx_allhands_p",
    "Réttar breytur: vinnutekjur allra\nvinnandi handa á íbúa", RED)

isL = yposL[orderL.index("IS")]
axL.annotate("4. sæti — en hér vantar\ntekjur sjálfstætt starfandi",
             xy=(valsL["IS"] + 24, isL), xytext=(260, isL - 5.0),
             fontsize=9.0, color=DARK, va="center", ha="right",
             fontweight="bold",
             arrowprops=dict(arrowstyle="->", color=DARK, lw=1.1,
                             connectionstyle="arc3,rad=0.25"))
isR = yposR[orderR.index("IS")]
axR.annotate("Ísland fellur í 6. sæti,\nvísitalan úr 129 í 115",
             xy=(valsR["IS"] + 24, isR), xytext=(260, isR - 5.0),
             fontsize=9.0, color=RED, va="center", ha="right",
             fontweight="bold",
             arrowprops=dict(arrowstyle="->", color=RED, lw=1.1,
                             connectionstyle="arc3,rad=0.25"))

fig.text(0.035, 0.965, "Þegar allar vinnandi hendur eru taldar með "
         "rennur Ísland niður listann",
         fontsize=14, fontweight="bold", color=DARK, ha="left")
fig.text(0.035, 0.928,
         "Vinnutekjur á íbúa 2024, leiðréttar fyrir verðlagi neyslu (ESB = 100). "
         "Vinstra megin telur aðeins launasumma launþega — en tekjur sjálfstætt\n"
         "starfandi (14,3% starfandi í ESB, 4,6% á Íslandi) bókast utan hennar. "
         "Hægra megin er launasumman sköluð upp svo tekjur allra vinnandi handa\n"
         "teljist með; þá lækkar Ísland en löndin með marga sjálfstætt starfandi "
         "hækka.",
         fontsize=9.3, color=GREY, ha="left", va="top")
fig.text(0.035, 0.012,
         "Heimild: Eurostat (nama_10_a10: laun D11 og launakostnaður D1; "
         "nama_10_a10_e: starfandi EMP_DC og launþegar SAL_DC; nama_10_pe: "
         "mannfjöldi; prc_ppp_ind: verðlagsvísitala einstaklingsneyslu A01);\n"
         "útreikningar höfundar. ESB-ríkin 27 og Ísland, árið 2024. Hægri mynd: "
         "D1 x (starfandi/launþegar), þ.e. gert ráð fyrir að hver sjálfstætt "
         "starfandi hafi sömu vinnutekjur og meðallaunþegi.",
         fontsize=6.8, color=GREY, ha="left", va="bottom")

path = os.path.join(FIGS, "m18_vinnandi_hendur.png")
fig.savefig(path, dpi=200)
print("written:", path)
