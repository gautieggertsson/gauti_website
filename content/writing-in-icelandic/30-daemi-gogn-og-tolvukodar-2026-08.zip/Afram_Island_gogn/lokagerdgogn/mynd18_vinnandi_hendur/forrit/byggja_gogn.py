#!/usr/bin/env python3
"""
Byggir ../gogn/vinnutekjur_allra_2024.csv úr hráafritunum í ../hra/.

Vinnutekjur allra vinnandi handa á íbúa, 2024. Greining Áfram Íslands ber
saman launatekjur launþega (D11) á íbúa, en í ESB eru 14,3% starfandi
sjálfstætt starfandi og tekjur þeirra bókast sem blönduð tekja (B.3), ekki
laun; á Íslandi er hlutfallið 4,6%. Hér er launasumman D1 sköluð upp fyrir
sjálfstætt starfandi (stöðluð aðlöguð launahlutdeild: gert ráð fyrir að hver
sjálfstætt starfandi hafi sömu vinnutekjur og meðallaunþegi), bæði á grunni
fjölda starfandi og vinnustunda, og að auki efri mörk með mældri blandaðri
tekju heimila (B3G).

Allt raunvirt með verðlagsvísitölu einstaklingsneyslu (AIC PLI, A01), deilt
með meðalmannfjölda, vísitala ESB=100, sæti innan ESB-27 og Íslands.
Keyrsla: python3 byggja_gogn.py. Ekkert netsamband.
"""
import csv
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
FROZEN = os.path.join(HERE, "..", "hra")
RAW = FROZEN
OUT = os.path.join(HERE, "..", "gogn")
os.makedirs(OUT, exist_ok=True)

EU = "EU27_2020"
EU_MEMBERS = ["AT", "BE", "BG", "HR", "CY", "CZ", "DE", "DK", "EE", "EL",
              "ES", "FI", "FR", "HU", "IE", "IT", "LT", "LU", "LV", "MT",
              "NL", "PL", "PT", "RO", "SE", "SI", "SK"]
NAMES = {
    "AT": "Austurríki", "BE": "Belgía", "BG": "Búlgaría", "HR": "Króatía",
    "CY": "Kýpur", "CZ": "Tékkland", "DE": "Þýskaland", "DK": "Danmörk",
    "EE": "Eistland", "EL": "Grikkland", "ES": "Spánn", "FI": "Finnland",
    "FR": "Frakkland", "HU": "Ungverjaland", "IE": "Írland", "IT": "Ítalía",
    "LT": "Litháen", "LU": "Lúxemborg", "LV": "Lettland", "MT": "Malta",
    "NL": "Holland", "PL": "Pólland", "PT": "Portúgal", "RO": "Rúmenía",
    "SE": "Svíþjóð", "SI": "Slóvenía", "SK": "Slóvakía", "IS": "Ísland",
    EU: "ESB",
}
GEOS = EU_MEMBERS + ["IS", EU]
RANK_GROUP = EU_MEMBERS + ["IS"]


def load_jsonstat(path):
    d = json.load(open(path))
    dims, sizes = d["id"], d["size"]
    cats = [[c for c, _ in sorted(d["dimension"][k]["category"]["index"].items(),
                                  key=lambda x: x[1])] for k in dims]
    out = {}
    for flat, v in d["value"].items():
        flat = int(flat)
        key, rem = [], flat
        for i in range(len(dims) - 1, -1, -1):
            rem, j = divmod(rem, sizes[i])
            key.append(cats[i][j])
        out[tuple(reversed(key))] = v
    return out


def get(table, *want):
    for key, v in table.items():
        parts = set(key)
        if all(w in parts for w in want):
            return v
    return None


def ranks(vals, group=RANK_GROUP):
    ordered = sorted([g for g in group if vals.get(g) is not None],
                     key=lambda g: -vals[g])
    return {g: i + 1 for i, g in enumerate(ordered)}, len(ordered)


# ---------------------------------------------------------------- inntak
wages = load_jsonstat(os.path.join(FROZEN, "nama_10_a10_D1_D11_2024.json"))
sal = load_jsonstat(os.path.join(FROZEN, "nama_10_a10_e_SAL_2024.json"))
ppp = load_jsonstat(os.path.join(FROZEN, "estat_prc_ppp_ind.json"))
pop_t = load_jsonstat(os.path.join(FROZEN, "nama_10_pe_2024.json"))
emp = load_jsonstat(os.path.join(RAW, "nama_10_a10_e_EMP_2024_all.json"))
b3g_t = load_jsonstat(os.path.join(RAW, "nasa_10_nf_tr_B3G_2024.json"))

d1 = {g: get(wages, "CP_MEUR", "D1", g) for g in GEOS}
d11 = {g: get(wages, "CP_MEUR", "D11", g) for g in GEOS}
sal_per = {g: get(sal, "SAL_DC", "THS_PER", g) for g in GEOS}
sal_hw = {g: get(sal, "SAL_DC", "THS_HW", g) for g in GEOS}
emp_per = {g: get(emp, "EMP_DC", "THS_PER", g) for g in GEOS}
emp_hw = {g: get(emp, "EMP_DC", "THS_HW", g) for g in GEOS}
b3g = {g: get(b3g_t, "RECV", "B3G", "S14_S15", g) for g in GEOS}
pop = {g: get(pop_t, "POP_NC", "THS_PER", g) for g in GEOS}
pli = {g: get(ppp, "PLI_EU27_2020", "A01", g, "2024") for g in GEOS}
pli[EU] = 100.0

b3g_missing = [g for g in GEOS if b3g.get(g) is None]


# ------------------------------------------------------------ mælikvarðar
def per_capita_real(numer_meur):
    """MEUR -> EUR á íbúa, nafnvirði og raunvirði (AIC PLI)."""
    eur, real = {}, {}
    for g in GEOS:
        if numer_meur.get(g) and pop.get(g):
            eur[g] = numer_meur[g] * 1e6 / (pop[g] * 1e3)
            if pli.get(g):
                real[g] = eur[g] / (pli[g] / 100.0)
    return eur, real


measures = {}  # name -> (eur, real, index, rank, n)


def add_measure(name, numer):
    eur, real = per_capita_real(numer)
    idx = {g: 100 * real[g] / real[EU] for g in real}
    idx_eur = {g: 100 * eur[g] / eur[EU] for g in eur}
    r, n = ranks(real)
    measures[name] = dict(eur=eur, real=real, idx=idx, idx_eur=idx_eur,
                          rank=r, n=n)


# a) eins og glærurnar: launatekjur launþega (D11) á íbúa
add_measure("d11_pc", d11)

# b) aðaltala, fjöldagrunnur: D1 x (starfandi/launþegar)
imput_per = {g: d1[g] * emp_per[g] / sal_per[g] for g in GEOS
             if d1.get(g) and emp_per.get(g) and sal_per.get(g)}
add_measure("allhands_persons", imput_per)

# c) aðaltala, stundagrunnur: D1 x (stundir starfandi/stundir launþega)
imput_hw = {g: d1[g] * emp_hw[g] / sal_hw[g] for g in GEOS
            if d1.get(g) and emp_hw.get(g) and sal_hw.get(g)}
add_measure("allhands_hours", imput_hw)

# d) efri mörk: D1 + mæld blönduð tekja heimila (B3G, inniheldur
#    fjármagnsþátt -> ofmat á vinnutekjum)
d1_b3g = {g: d1[g] + b3g[g] for g in GEOS
          if d1.get(g) and b3g.get(g) is not None}
add_measure("d1_b3g", d1_b3g)

# samhengistölur: raunlaun á launþega og á stund (D11-grunnur)
wage_pe_real = {g: d11[g] * 1e6 / (sal_per[g] * 1e3) / (pli[g] / 100)
                for g in GEOS if d11.get(g) and sal_per.get(g) and pli.get(g)}
wage_ph_real = {g: d11[g] * 1e6 / (sal_hw[g] * 1e3) / (pli[g] / 100)
                for g in GEOS if d11.get(g) and sal_hw.get(g) and pli.get(g)}
idx_pe = {g: 100 * wage_pe_real[g] / wage_pe_real[EU] for g in wage_pe_real}
idx_ph = {g: 100 * wage_ph_real[g] / wage_ph_real[EU] for g in wage_ph_real}
r_pe, n_pe = ranks(wage_pe_real)
r_ph, n_ph = ranks(wage_ph_real)

# hlutfall sjálfstætt starfandi
self_emp_share = {g: 100 * (1 - sal_per[g] / emp_per[g]) for g in GEOS
                  if sal_per.get(g) and emp_per.get(g)}

# ------------------------------------------------------------- skynsemispróf
is_d11 = measures["d11_pc"]
is_per = measures["allhands_persons"]
is_hw = measures["allhands_hours"]
checks = [
    ("D11 á íbúa raunvirt = 129,2 (glærutalan endurgerð)",
     abs(is_d11["idx"]["IS"] - 129.2) < 0.15),
    ("D11 á íbúa: Ísland 4. sæti af 28",
     is_d11["rank"]["IS"] == 4 and is_d11["n"] == 28),
    ("Fjöldagrunnur lendir nálægt 111-116",
     110.0 <= is_per["idx"]["IS"] <= 118.0),
    ("Stundagrunnur lendir nálægt 111-116",
     108.0 <= is_hw["idx"]["IS"] <= 118.0),
    ("Sjálfst. starfandi IS ~4,6%",
     abs(self_emp_share["IS"] - 4.6) < 0.5),
    ("Sjálfst. starfandi ESB ~14,3%",
     abs(self_emp_share[EU] - 14.3) < 0.5),
    ("Raunlaun á launþega ~98,3", abs(idx_pe["IS"] - 98.3) < 0.3),
    ("Raunlaun á stund ~104,8", abs(idx_ph["IS"] - 104.8) < 0.3),
]
for label, ok in checks:
    print(("OK  " if ok else "FAIL") + " " + label)
    assert ok, label

# --------------------------------------------------------------- úttak
with open(os.path.join(OUT, "vinnutekjur_allra_2024.csv"), "w",
          newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["geo", "name", "pop_ths", "pli_aic",
                "self_emp_share_pct",
                "d11_pc_eur", "d11_pc_real", "idx_d11", "rank_d11",
                "allhands_p_pc_eur", "allhands_p_pc_real",
                "idx_allhands_p", "rank_allhands_p",
                "allhands_h_pc_real", "idx_allhands_h", "rank_allhands_h",
                "d1b3g_pc_real", "idx_d1b3g", "rank_d1b3g"])
    order = sorted(is_per["real"], key=lambda g: -is_per["real"][g])
    for g in order:
        m, p, h, b = is_d11, is_per, is_hw, measures["d1_b3g"]
        w.writerow([
            g, NAMES[g], pop[g], pli[g],
            round(self_emp_share[g], 1),
            round(m["eur"][g]), round(m["real"][g]),
            round(m["idx"][g], 1), m["rank"].get(g, ""),
            round(p["eur"][g]), round(p["real"][g]),
            round(p["idx"][g], 1), p["rank"].get(g, ""),
            round(h["real"][g]), round(h["idx"][g], 1), h["rank"].get(g, ""),
            round(b["real"][g]) if g in b["real"] else "",
            round(b["idx"][g], 1) if g in b["idx"] else "",
            b["rank"].get(g, ""),
        ])

with open(os.path.join(OUT, "key_numbers.csv"), "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["key", "label_is", "value", "source"])
    rows = [
        ("idx_d11_is", "Launatekjur launþega (D11) á íbúa, raunvirt (ESB=100)",
         round(is_d11["idx"]["IS"], 1), "nama_10_a10 D11 / nama_10_pe / prc_ppp_ind A01"),
        ("rank_d11_is", "Sæti Íslands, D11 á íbúa",
         f'{is_d11["rank"]["IS"]} af {is_d11["n"]}', "sama"),
        ("idx_allhands_p_is", "Vinnutekjur allra á íbúa, fjöldagrunnur (ESB=100)",
         round(is_per["idx"]["IS"], 1),
         "D1 x (EMP_DC/SAL_DC, THS_PER), nama_10_a10 + nama_10_a10_e"),
        ("rank_allhands_p_is", "Sæti Íslands, fjöldagrunnur",
         f'{is_per["rank"]["IS"]} af {is_per["n"]}', "sama"),
        ("idx_allhands_h_is", "Vinnutekjur allra á íbúa, stundagrunnur (ESB=100)",
         round(is_hw["idx"]["IS"], 1),
         "D1 x (EMP_DC/SAL_DC, THS_HW)"),
        ("rank_allhands_h_is", "Sæti Íslands, stundagrunnur",
         f'{is_hw["rank"]["IS"]} af {is_hw["n"]}', "sama"),
        ("idx_d1b3g_is", "D1 + B3G á íbúa, raunvirt (ESB=100, efri mörk)",
         round(measures["d1_b3g"]["idx"]["IS"], 1),
         "nama_10_a10 D1 + nasa_10_nf_tr B3G S14_S15"),
        ("rank_d1b3g_is", "Sæti Íslands, D1+B3G",
         f'{measures["d1_b3g"]["rank"]["IS"]} af {measures["d1_b3g"]["n"]}',
         "sama; vantar: " + ",".join(b3g_missing)),
        ("idx_d11_eur_is", "D11 á íbúa í evrum (ESB=100)",
         round(is_d11["idx_eur"]["IS"], 1), "án verðlagsleiðréttingar"),
        ("idx_allhands_p_eur_is", "Vinnutekjur allra á íbúa í evrum (ESB=100)",
         round(is_per["idx_eur"]["IS"], 1), "án verðlagsleiðréttingar"),
        ("self_emp_share_is", "Sjálfstætt starfandi, % starfandi, Ísland",
         round(self_emp_share["IS"], 1), "nama_10_a10_e EMP_DC vs SAL_DC"),
        ("self_emp_share_eu", "Sjálfstætt starfandi, % starfandi, ESB",
         round(self_emp_share[EU], 1), "sama"),
        ("idx_wage_pe_is", "Raunlaun á launþega (ESB=100), samhengi",
         round(idx_pe["IS"], 1), f'sæti {r_pe["IS"]} af {n_pe}'),
        ("idx_wage_ph_is", "Raunlaun á greidda stund (ESB=100), samhengi",
         round(idx_ph["IS"], 1), f'sæti {r_ph["IS"]} af {n_ph}'),
        ("b3g_missing", "Lönd án B3G 2024", ";".join(b3g_missing) or "engin",
         "nasa_10_nf_tr"),
    ]
    for row in rows:
        w.writerow(row)

print("\n--- lykiltölur, Ísland ---")
print(f'D11 á íbúa (glæruaðferð):   {is_d11["idx"]["IS"]:.1f}  sæti {is_d11["rank"]["IS"]} af {is_d11["n"]}')
print(f'Allra hendur, fjöldi:       {is_per["idx"]["IS"]:.1f}  sæti {is_per["rank"]["IS"]} af {is_per["n"]}')
print(f'Allra hendur, stundir:      {is_hw["idx"]["IS"]:.1f}  sæti {is_hw["rank"]["IS"]} af {is_hw["n"]}')
print(f'D1+B3G (efri mörk):         {measures["d1_b3g"]["idx"]["IS"]:.1f}  sæti {measures["d1_b3g"]["rank"]["IS"]} af {measures["d1_b3g"]["n"]}')
print(f'B3G vantar: {b3g_missing}')
