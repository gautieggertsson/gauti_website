#!/usr/bin/env python3
"""
Býr til frystu gagnaskrána ../gogn/kaupmattur_vinnustundar_2024_d11_d1.csv úr
hráafritunum í ../hra/ (sótt af Eurostat 23.8.2026). gera_mynd20.py les aðeins
CSV-skrána.

  lc_lci_lev: EUR, B-S_X_O, lcstruct D11 og D1_D4_MD5, 2024 (útgáfa 23.4.2026, p = bráðabirgðatölur)
  prc_ppp_ind: PLI_EU27_2020, ppp_cat E011, 2024 (útgáfa 10.7.2025, COICOP 1999)
  prc_ppp_ind_1: sama, ppp_cat18 E011 (útgáfa 9.7.2026, COICOP 2018), til samanburðar
"""
import csv, json, os
HERE = os.path.dirname(os.path.abspath(__file__))
ROT = os.path.dirname(HERE)
EU = "EU27_2020"
EU27 = ["AT","BE","BG","HR","CY","CZ","DE","DK","EE","EL","ES","FI","FR","HU","IE","IT","LT","LU","LV","MT","NL","PL","PT","RO","SE","SI","SK"]
NAMES = {"AT":"Austurríki","BE":"Belgía","BG":"Búlgaría","HR":"Króatía","CY":"Kýpur","CZ":"Tékkland","DE":"Þýskaland","DK":"Danmörk","EE":"Eistland","EL":"Grikkland","ES":"Spánn","FI":"Finnland","FR":"Frakkland","HU":"Ungverjaland","IE":"Írland","IT":"Ítalía","LT":"Litháen","LU":"Lúxemborg","LV":"Lettland","MT":"Malta","NL":"Holland","PL":"Pólland","PT":"Portúgal","RO":"Rúmenía","SE":"Svíþjóð","SI":"Slóvenía","SK":"Slóvakía","IS":"Ísland",EU:"ESB"}

def load(path):
    d = json.load(open(path)); dims, sizes = d["id"], d["size"]
    cats = [[c for c,_ in sorted(d["dimension"][k]["category"]["index"].items(), key=lambda x:x[1])] for k in dims]
    out = {}
    for flat, v in d["value"].items():
        flat=int(flat); key=[]; rem=flat
        for i in range(len(dims)-1,-1,-1):
            rem,j = divmod(rem,sizes[i]); key.append(cats[i][j])
        out[tuple(reversed(key))] = v
    return out
def g(t,*w):
    for k,v in t.items():
        if all(x in k for x in w): return v
lc = load(os.path.join(ROT,"hra","lc_lci_lev_D11_D1_2024.json"))
p  = load(os.path.join(ROT,"hra","prc_ppp_ind_E011_A01_2024.json"))
p1 = load(os.path.join(ROT,"hra","prc_ppp_ind_1_E011_A01_2024.json"))
rows=[]
for geo in EU27+["IS",EU]:
    d11=g(lc,"D11",geo); d1=g(lc,"D1_D4_MD5",geo)
    e=g(p,"E011",geo) if geo!=EU else 100.0; e1=g(p1,"E011",geo) if geo!=EU else 100.0
    rows.append(dict(geo=geo,name=NAMES[geo],d11_eur_h=d11,d1_eur_h=d1,pli_e011_2024=e,pli_e011_coicop2018=e1,
                     d11_real=round(d11/(e/100),2),d1_real=round(d1/(e/100),2)))
for key in ("d11_real","d1_real"):
    order = sorted([r for r in rows if r["geo"]!=EU], key=lambda r:-r[key])
    for i,r in enumerate(order): r["rank_"+key]=i+1
    [r for r in rows if r["geo"]==EU][0]["rank_"+key]=""
with open(os.path.join(ROT,"gogn","kaupmattur_vinnustundar_2024_d11_d1.csv"),"w",newline="") as fh:
    w=csv.DictWriter(fh,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(sorted(rows,key=lambda r:-r["d11_real"]))
for r in sorted(rows,key=lambda r:-r["d11_real"]):
    print(f"{r['name']:13s} D11 {r['d11_eur_h']:5.1f} -> {r['d11_real']:6.2f} ({r['rank_d11_real']})   D1 {r['d1_eur_h']:5.1f} -> {r['d1_real']:6.2f} ({r['rank_d1_real']})")
eu27=[r for r in rows if r["geo"] in EU27]
print("óvegið meðaltal 27: D11", round(sum(r["d11_real"] for r in eu27)/27,2), "D1", round(sum(r["d1_real"] for r in eu27)/27,2))
