#!/usr/bin/env python3
"""
Mynd m20_d11_d1: kaupmáttur vinnustundar 2024 á tveimur launaliðum, hlið við hlið.

Vinstri: laun á vinnustund (D11, launakostnaðarkönnun Eurostat lc_lci_lev,
atvinnugreinar B-S án opinberrar stjórnsýslu O), deilt með verðlagsvísitölu
einkaneysluútgjalda heimila (prc_ppp_ind, E011, PLI_EU27_2020, 2024).
Hægri: sama með heildarlaunakostnaði (D1_D4_MD5: laun, launatengd gjöld
launagreiðenda og skattar að frádregnum styrkjum). ESB-ríkin 27 og Ísland;
lóðrétt brotalína er ESB27 sem ein heild (vegið meðaltal Eurostat).

Gögn: ../gogn/kaupmattur_vinnustundar_2024_d11_d1.csv (fryst tafla, byggð úr
hráafritunum í ../hra/ með byggja_gogn.py; sótt af Eurostat 23.8.2026, sjá
../lysigogn/manifest.json). Ekkert netsamband.
Keyrsla: python3 gera_mynd20.py; myndin skrifast í ../mynd/.
"""
import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

HERE = os.path.dirname(os.path.abspath(__file__))
ROT = os.path.dirname(HERE)
CSV = os.path.join(ROT, "gogn", "kaupmattur_vinnustundar_2024_d11_d1.csv")
MYND = os.path.join(ROT, "mynd")
os.makedirs(MYND, exist_ok=True)

EU = "EU27_2020"
RED = "#B83A32"
BLUE = "#4878A8"
DARK = "#1a1a1a"
GREY = "#8a8a8a"

rows = {}
with open(CSV) as fh:
    for row in csv.DictReader(fh):
        rows[row["geo"]] = row

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                     "axes.edgecolor": "0.75", "axes.linewidth": 0.8})


def ic(x, nd=1):
    return f"{x:.{nd}f}".replace(".", ",")


def panel(ax, key, title, title_color):
    vals = {g: float(r[key]) for g, r in rows.items() if g != EU}
    eu = float(rows[EU][key])
    order = sorted(vals, key=lambda g: -vals[g])
    ypos = list(range(len(order)))[::-1]
    colors = [RED if g == "IS" else BLUE for g in order]
    ax.barh(ypos, [vals[g] for g in order], height=0.62, color=colors,
            zorder=3)
    for y, g in zip(ypos, order):
        ax.text(vals[g] + 0.6, y, ic(vals[g]), va="center", ha="left",
                fontsize=8.0,
                fontweight="bold" if g == "IS" else "normal",
                color=RED if g == "IS" else "0.35", zorder=5,
                bbox=dict(boxstyle="square,pad=0.12", fc="white", ec="none"))
    ax.set_yticks(ypos)
    ax.set_yticklabels([rows[g]["name"] for g in order], fontsize=8.8)
    for tick, g in zip(ax.get_yticklabels(), order):
        if g == "IS":
            tick.set_color(RED)
            tick.set_fontweight("bold")
    ax.axvline(eu, color=DARK, lw=1.2, ls=(0, (5, 3)), zorder=2)
    ax.text(eu + 0.4, len(order) - 0.35, f"ESB sem ein heild: {ic(eu)}",
            fontsize=8.4, color=DARK, fontweight="bold", ha="left",
            va="bottom")
    ax.set_xlim(0, 50)
    ax.set_ylim(-0.8, len(order) + 0.9)
    ax.xaxis.set_major_locator(mticker.MultipleLocator(10))
    ax.xaxis.set_major_formatter(
        mticker.FuncFormatter(lambda v, _: ic(v, 0)))
    for s in ["top", "right", "left"]:
        ax.spines[s].set_visible(False)
    ax.grid(axis="x", color="0.88", lw=0.8, zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(length=0)
    ax.set_title(title, fontsize=11, fontweight="bold", color=title_color,
                 loc="left", pad=10)
    ax.set_xlabel("evrur á vinnustund, á verðlagi einkaneyslu ESB", fontsize=8,
                  color=GREY)
    return vals, order, ypos, eu


fig, (axL, axR) = plt.subplots(1, 2, figsize=(12.6, 9.2))
fig.subplots_adjust(top=0.845, bottom=0.10, left=0.095, right=0.985,
                    wspace=0.42)

rankL = rows["IS"]["rank_d11_real"]
rankR = rows["IS"]["rank_d1_real"]
valsL, orderL, yposL, euL = panel(
    axL, "d11_real", f"Laun (D11): Ísland í {rankL}. sæti af 28", DARK)
valsR, orderR, yposR, euR = panel(
    axR, "d1_real", f"Launakostnaður (D1): Ísland í {rankR}. sæti af 28",
    DARK)

isL = yposL[orderL.index("IS")]
axL.annotate(f"{ic(valsL['IS'])} á móti {ic(euL)}:\nrétt yfir\nheild ESB",
             xy=(valsL["IS"] + 3.2, isL), xytext=(49, isL - 6.0),
             fontsize=9.2, color=RED, va="center", ha="right",
             fontweight="bold",
             arrowprops=dict(arrowstyle="->", color=RED, lw=1.1,
                             connectionstyle="arc3,rad=0.25"))
isR = yposR[orderR.index("IS")]
axR.annotate(f"{ic(valsR['IS'])} á móti {ic(euR)}:\nrétt undir\nheild ESB",
             xy=(valsR["IS"] + 3.2, isR), xytext=(49.5, isR - 7.5),
             fontsize=9.2, color=RED, va="center", ha="right",
             fontweight="bold",
             arrowprops=dict(arrowstyle="->", color=RED, lw=1.1,
                             connectionstyle="arc3,rad=0.25"))

fig.text(0.035, 0.965, "Kaupmáttur vinnustundar 2024: launaliðurinn ræður hvort "
         "Ísland er rétt yfir eða rétt undir heild ESB",
         fontsize=14, fontweight="bold", color=DARK, ha="left")
fig.text(0.035, 0.925,
         "Laun á vinnustund 2024 í evrum, deilt með verðlagsvísitölu "
         "einkaneysluútgjalda heimila (ESB = 100; Ísland 161,7). Vinstri: laun "
         "ein (D11). Hægri: heildarlaunakostnaður (D1), þ.e. laun\nað viðbættum "
         "launatengdum gjöldum launagreiðenda. Brotalínan er ESB-ríkin 27 sem "
         "ein heild (vegið meðaltal). Launatengd gjöld eru lægra álag á Íslandi "
         "en að jafnaði í ESB.",
         fontsize=9.5, color=GREY, ha="left", va="top")
fig.text(0.035, 0.012,
         "Heimild: Eurostat (lc_lci_lev: launakostnaður á vinnustund í evrum, "
         "atvinnugreinar B-S án O, launaliðir D11 og D1_D4_MD5, bráðabirgðatölur, "
         "útgáfa 23.4.2026; prc_ppp_ind: verðlagsvísitala einkaneysluútgjalda "
         "heimila E011,\nútgáfa 10.7.2025); útreikningar höfundar. ESB-ríkin 27 "
         "og Ísland, árið 2024. Gögn sótt 23.8.2026.",
         fontsize=6.8, color=GREY, ha="left", va="bottom")

for ext in ("png", "pdf"):
    path = os.path.join(MYND, f"m20_d11_d1.{ext}")
    fig.savefig(path, dpi=200)
    print("written:", path)
