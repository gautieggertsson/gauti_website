#!/usr/bin/env python3
"""Mynd: níu mælingar á launum Íslendinga (mynd4_oecd.png í greininni).

Les frystu niðurstöðuskrárnar í ../gogn/ og teiknar sætamyndina. Sætin eru
varin með assert svo myndin bregðist ef frystu skrárnar breytast.
Keyrsla: python3 gera_mynd_oecd.py  (úttak í ../mynd/mynd4_oecd.png)
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROT = Path(__file__).resolve().parents[1]
GOGN = ROT / "gogn"
MYND = ROT / "mynd"
RANK_CROSSWALK_CSV = GOGN / "institution_rank_crosswalk.csv"
LCHRS_CSV = GOGN / "oecd_lchrs_ppp_2024.csv"
ILO_CSV = GOGN / "ilo_EAR_EMTA_SEX_CUR_NB_A_2015plus.csv"


def main() -> None:
    MYND.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.titlesize": 14,
        "axes.labelsize": 10,
    })

    cross = pd.read_csv(RANK_CROSSWALK_CSV)

    def cross_rank(source: str, measure: str, basket: str) -> tuple[int, int]:
        row = cross[
            (cross["source_family"] == source)
            & (cross["measure"] == measure)
            & (cross["ppp_basket"] == basket)
        ]
        assert len(row) == 1, (source, measure, basket, len(row))
        return int(row.iloc[0]["iceland_rank"]), int(row.iloc[0]["sample_n"])

    euro_source = "Statistics Iceland -> Eurostat; OECD hours where applicable"
    rank_hour_e011 = cross_rank(euro_source, "D11 per employee-hour", "household final consumption (E011)")
    rank_person_e011 = cross_rank(euro_source, "D11 per employee", "household final consumption (E011)")
    rank_ft_e011 = cross_rank(euro_source, "OECD-method D11 annual wage", "household final consumption (E011)")
    rank_person_a01 = cross_rank(euro_source, "D11 per employee", "AIC (A01)")
    rank_ameco = cross_rank("AMECO + Eurostat PPP", "AMECO D1 per employee", "household final consumption (E011)")
    rank_wb = cross_rank("Eurostat wages + World Bank PPP", "D11 per employee", "World Bank household/NPISH consumption")
    rank_oecd = cross_rank("OECD published", "Average annual wages", "private/household consumption")

    lchrs = pd.read_csv(LCHRS_CSV)
    lchrs_is = lchrs[lchrs["ref_area"] == "ISL"]
    assert len(lchrs_is) == 1
    rank_lchrs = (
        int(lchrs_is.iloc[0]["rank_complete_case_intersection"]),
        int(lchrs_is.iloc[0]["sample_n"]),
    )

    ilo = pd.read_csv(ILO_CSV)
    ilo_codes = {
        "ISL", "AUT", "BEL", "BGR", "HRV", "CYP", "CZE", "DNK", "EST",
        "FIN", "FRA", "DEU", "GRC", "HUN", "IRL", "ITA", "LVA", "LTU",
        "LUX", "MLT", "NLD", "POL", "PRT", "ROU", "SVK", "SVN", "ESP",
        "SWE", "NOR", "CHE", "GBR",
    }
    ilo_2020 = ilo[
        (ilo["time"] == 2020)
        & (ilo["classif1"] == "CUR_TYPE_PPP")
        & (ilo["ref_area"].isin(ilo_codes))
    ].copy()
    assert len(ilo_2020) == 31 and ilo_2020["ref_area"].nunique() == 31
    ilo_2020["rank"] = ilo_2020["obs_value"].rank(method="min", ascending=False).astype(int)
    rank_ilo = (int(ilo_2020.loc[ilo_2020["ref_area"] == "ISL", "rank"].iloc[0]), 31)
    assert rank_ilo == (9, 31)

    ranking_rows = [
        ("OECD: birt AAW-röð, 2024", *rank_oecd, "released"),
        ("D11 á unna klst. launþega, E011", *rank_hour_e011, "uniform"),
        ("D11 á launþega, E011", *rank_person_e011, "uniform"),
        ("D11 á launþega × FT/all, E011", *rank_ft_e011, "uniform"),
        ("D11 á launþega, A01", *rank_person_a01, "uniform"),
        ("AMECO HWCDW: D1/launþega, E011", *rank_ameco, "context"),
        ("D11/launþega + PPP Alþjóðabankans", *rank_wb, "context"),
        ("ILO: meðalmánaðarlaun 2020", *rank_ilo, "context"),
        ("OECD PDB: D1 á unna klst. (LCHRS)", *rank_lchrs, "context"),
    ]
    assert ranking_rows[0][1:3] == (1, 37)
    assert all(7 <= row[1] <= 12 for row in ranking_rows[1:])

    rank_path = MYND / "mynd4_oecd.png"
    fig, ax = plt.subplots(figsize=(9.4, 5.55), dpi=190)
    ypos = list(range(len(ranking_rows)))
    for y_i, (_, rank, sample_n, kind) in zip(ypos, ranking_rows):
        ax.hlines(y_i, 1, rank, color="#D7DEE7", linewidth=1.4, zorder=1)
        if kind == "released":
            ax.scatter(rank, y_i, s=118, marker="D", color="#D94F04", edgecolor="white", linewidth=0.8, zorder=3)
        elif kind == "uniform":
            ax.scatter(rank, y_i, s=92, marker="o", color="#2E74B5", edgecolor="white", linewidth=0.8, zorder=3)
        else:
            ax.scatter(rank, y_i, s=92, marker="o", color="#55B96B", edgecolor="white", linewidth=0.8, zorder=3)
        offset = 0.24 if rank < 11 else -0.22
        ha = "left" if rank < 11 else "right"
        ax.text(rank + offset, y_i, f"{rank}/{sample_n}", va="center", ha=ha, color="#17212B", fontsize=9.2)
    ax.set_yticks(ypos, [row[0] for row in ranking_rows])
    ax.invert_yaxis()
    ax.set_xlim(0.8, 12.55)
    ax.set_xticks([1, 2, 4, 6, 8, 10, 12])
    ax.set_xlabel("Sæti Íslands (1 = hæst)", color="#5F6B76")
    ax.set_title("Aðeins útgefna OECD-röðin setur Ísland í 1. sæti", loc="left", fontweight="bold", color="#0B2545", pad=22)
    ax.text(
        0,
        1.035,
        "Átta aðrar endurgeranlegar útfærslur setja Ísland í 7.–12. sæti.",
        transform=ax.transAxes,
        color="#5F6B76",
        fontsize=10,
    )
    released_handle = ax.scatter([], [], s=70, marker="D", color="#D94F04", label="Útgefin OECD-röð")
    uniform_handle = ax.scatter([], [], s=65, marker="o", color="#2E74B5", label="Samræmd 2024-smíð")
    context_handle = ax.scatter([], [], s=65, marker="o", color="#55B96B", label="Samhengis-/þolpróf")
    ax.legend(
        handles=[released_handle, uniform_handle, context_handle],
        loc="lower center",
        bbox_to_anchor=(0.5, -0.26),
        ncol=3,
        frameon=False,
        fontsize=8.8,
        handletextpad=0.35,
        columnspacing=1.15,
    )
    ax.grid(axis="x", color="#E9EDF2", linewidth=0.8)
    ax.set_axisbelow(True)
    ax.tick_params(axis="y", length=0, labelsize=9)
    ax.tick_params(axis="x", colors="#7A8591")
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.spines["bottom"].set_color("#C7CFD8")
    fig.subplots_adjust(left=0.34, right=0.96, top=0.82, bottom=0.23)
    fig.savefig(rank_path, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("Mynd skrifuð:", rank_path)


if __name__ == "__main__":
    main()
