#!/usr/bin/env python3
"""
Myndir m15_kaupmattur og m15b_kaupmattur_2007: kaupmáttur launa á Íslandi,
í ESB og á Norðurlöndum innan ESB.

m15_kaupmattur.png: endurgerð myndar Áfram Íslands með sömu smíð og sniði,
ársfjórðungslegar launavísitölur Eurostat (lc_lci_r2_q, D11, atvinnugreinar
B-S, árstíða- og dagaleiðrétt, 2020=100) deilt með ársfjórðungsmeðaltali
samræmdrar vísitölu neysluverðs (prc_hicp_midx, CP00), 1. ársfj. 2013 = 100;
aðeins Ísland, ESB og Norðurlönd í ESB.

m15b_kaupmattur_2007.png: tuttugu ára samanburður, 2007 = 100. Lína Áfram
Íslands er D1 á vinnustund launþega deilt með HICP (endurgerir birtar tölur
síðunnar); hinar línurnar nota eina og sömu smíð fyrir öll ríki: laun D11 á
launþega deilt með verðvísitölu einkaneyslu þjóðhagsreikninga
(P31_S14_S15, PD15_NAC), sem nær til húsnæðis í öllum ríkjunum. Norðurlönd í
ESB eru Danmörk, Svíþjóð og Finnland, vegin með fjölda launþega hvers árs.

Gögn: frystir útdrættir úr Eurostat-skrám í ../gogn/ (nama_10_gdp,
nama_10_a10_e, prc_hicp_aind, lc_lci_r2_q, prc_hicp_midx) og vísitala
neysluverðs Hagstofu Íslands (VIS01000). Ekkert netsamband.
Keyrsla: python3 gera_mynd15.py; myndirnar skrifast í ../mynd/ og
talnataflan í ../nidurstodur/.
"""
import json
import pathlib

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = pathlib.Path(__file__).resolve().parents[1]
RAW, OUT, FIG = BASE / "gogn", BASE / "nidurstodur", BASE / "mynd"
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)

GEOS = ["IS", "EU27_2020", "DK", "NO", "SE", "FI"]
Y0, Y1 = 2007, 2025   # 2007 er hápunktur kaupmáttar á Íslandi fyrir hrun, það
                      # grunnár sem er Íslandi óhagstæðast (spegilmynd þess
                      # lágpunktsárs, 2013, sem Áfram Ísland byrjar á)


def estat_multi(fname, geos, **filt):
    chunks = []
    for ch in pd.read_csv(RAW / fname, chunksize=1_000_000, low_memory=False):
        m = ch.geo.isin(geos)
        for k, v in filt.items():
            m &= ch[k].isin(v if isinstance(v, (list, tuple)) else [v])
        chunks.append(ch[m])
    return pd.concat(chunks)


def to_series(d):
    return d.set_index("TIME_PERIOD")["OBS_VALUE"].astype(float).sort_index()


gdp = estat_multi("estat_nama_10_gdp.csv", GEOS,
                  na_item=["D1", "D11", "P31_S14_S15"],
                  unit=["CP_MNAC", "PD15_NAC"])
emp = estat_multi("estat_nama_10_a10_e.csv", GEOS,
                  na_item=["SAL_DC"], unit=["THS_HW", "THS_PER"],
                  nace_r2=["TOTAL"])
hicp = estat_multi("estat_prc_hicp_aind.csv", GEOS,
                   coicop=["CP00"], unit=["INX_A_AVG"])

def get(df, geo, **kw):
    m = df.geo == geo
    for k, v in kw.items():
        m &= df[k] == v
    return to_series(df[m])


cpi_raw = json.loads((RAW / "hagstofa_VIS01000_cpi.json")
                     .read_text(encoding="utf-8-sig"))
cpi_m = pd.Series({r["key"][0]: float(r["values"][0]) for r in cpi_raw["data"]})
cpi_g = cpi_m.groupby(cpi_m.index.str[:4].astype(int)).agg(["mean", "count"])
CPI_IS = cpi_g.loc[cpi_g["count"] == 12, "mean"]

# Ísland, aðferð Áfram Íslands (endurgerir síðuna): D1 á vinnustund / HICP.
# Allar samanburðarlínur nota sömu varfærnu smíðina fyrir hvert ríki, svo
# samanburðurinn milli ríkja er samhverfur: D11 á launþega deilt með
# verðvísitölu einkaneyslu hvers ríkis, sem nær til húsnæðis eigenda
# (reiknaðrar húsaleigu) alls staðar. Fyrir Ísland gefur sú vísitala +3% á
# tímabilinu 2007-2025 á móti +6% með vísitölu neysluverðs (sama yfir
# 2013-2025).
series = {}
D1_IS = get(gdp, "IS", na_item="D1", unit="CP_MNAC")
EH_IS = get(emp, "IS", unit="THS_HW")
s = ((D1_IS / EH_IS) / get(hicp, "IS")).dropna()
series["IS"] = (s / s[Y0] * 100).loc[Y0:Y1]

for geo in GEOS:
    D11 = get(gdp, geo, na_item="D11", unit="CP_MNAC")
    NS = get(emp, geo, unit="THS_PER")
    PHF = get(gdp, geo, na_item="P31_S14_S15", unit="PD15_NAC")
    low = ((D11 / NS) / PHF).dropna()
    key = "IS_low_hfce" if geo == "IS" else geo
    series[key] = (low / low[Y0] * 100).loc[Y0:Y1]

# Aðallína Íslands: sama smíð og hjá öllum öðrum ríkjum (D11 á launþega /
# verðvísitala einkaneyslu), ein regla fyrir alla. Útgáfan með vísitölu
# neysluverðs (+6% á móti +3% yfir 2007-2025) er varðveitt í talnatöflunni
# og nefnd í neðanmálsgrein myndarinnar.
series["IS_low"] = series["IS_low_hfce"]
D11_IS = get(gdp, "IS", na_item="D11", unit="CP_MNAC")
NS_IS = get(emp, "IS", unit="THS_PER")
low_cpi = ((D11_IS / NS_IS) / CPI_IS).dropna()
series["IS_low_cpi"] = (low_cpi / low_cpi[Y0] * 100).loc[Y0:Y1]

# Launavísitala Eurostat (LCI, D11) deilt með HICP fyrir Ísland (frá 2008),
# á ársgrunni, stillt að línu þjóðhagsreikninga árið 2008 til sannprófunar
d = pd.read_csv(RAW / "estat_lc_lci_r2_q_IS.csv")
d = d[(d.lcstruct == "D11") & (d.s_adj == "SCA") & (d.unit == "I20")]
lci = to_series(d)
lci_a = lci.groupby(lci.index.str[:4].astype(int)).mean()
lci_real = (lci_a / get(hicp, "IS")).dropna()
lci_line = (lci_real / lci_real[2008] * float(series["IS"][2008])).loc[2008:Y1]

# Norðurlönd í ESB eru Danmörk, Svíþjóð og Finnland (Noregur er í EES en
# ekki ESB), vegin með fjölda launþega hvers árs svo samtalan speglist í
# vegnu ESB-27-línunni.
NORD = ("DK", "SE", "FI")
w_emp = {g: get(emp, g, unit="THS_PER") for g in NORD}
w_tot = sum(w_emp.values())
nordic_avg = sum(series[g] * w_emp[g] for g in NORD) / w_tot
nordic_avg = nordic_avg.dropna()

tbl = pd.DataFrame({
    "IS_authors_D1h_HICP": series["IS"],
    "IS_LCI_D11_HICP_rebased2008": lci_line,
    "IS_D11perEmp_HFCE": series["IS_low"],
    "IS_D11perEmp_CPI": series["IS_low_cpi"],
    "EU27": series["EU27_2020"],
    "Nordic_EU_weighted": nordic_avg,
    "DK": series["DK"], "NO": series["NO"], "SE": series["SE"],
    "FI": series["FI"],
})
tbl.round(1).to_csv(OUT / "m15b_kaupmattur_2007_radir.csv")

# --------------------------------------------------------------------- mynd
# Stærð miðuð við vefbirtingu: stórt letur sem þolir minnkun niður í um
# 700 punkta breidd og símaskjái.
plt.rcParams.update({"figure.dpi": 200, "font.size": 14})
fig, ax = plt.subplots(figsize=(8.6, 5.4))

ax.plot(nordic_avg.index, nordic_avg.values, color="#5a5a5a", lw=2,
        label="Norðurlönd í ESB")
ax.plot(series["EU27_2020"].index, series["EU27_2020"].values,
        color="#c00000", lw=2, label="ESB")
ax.plot(series["IS"].index, series["IS"].values, color="#7fb2e5", lw=2,
        ls="--", label="Áfram Ísland")
ax.plot(series["IS_low"].index, series["IS_low"].values, color="#1f5fa8",
        lw=2.8, label="Ísland")
# rauður hringur þar sem úrtak Áfram Íslands hefst (2013)
ax.plot(2013, series["IS"][2013], "o", ms=12, mfc="none", mec="#c00000",
        mew=2, zorder=5)
ax.annotate("upphaf úrtaks Áfram Íslands (2013)", (2013, series["IS"][2013]),
            textcoords="offset points", xytext=(9, -19), color="#c00000",
            fontsize=11.5)

ax.axhline(100, color="grey", lw=0.5)


def arrow_box(axis, x, y_from, y_to, label, color, lw=2.2, fontsize=12,
              anchor="above"):
    """Lóðrétt ör frá y_from að y_to við x. anchor="above": rammaður
    merkimiði miðjaður fyrir ofan örvaroddinn; anchor="side": merkimiði
    við efri hluta örvarinnar."""
    axis.annotate("", xy=(x, y_to), xytext=(x, y_from),
                  arrowprops=dict(arrowstyle="-|>", color=color, lw=lw))
    if anchor == "above":
        axis.annotate(label, (x, y_to),
                      textcoords="offset points", xytext=(0, 7),
                      color=color, fontsize=fontsize, fontweight="bold",
                      ha="center", va="bottom",
                      bbox=dict(boxstyle="round,pad=0.35", fc="white",
                                ec=color))
    else:
        axis.annotate(label, (x, y_to),
                      textcoords="offset points", xytext=(12, -4),
                      color=color, fontsize=fontsize, fontweight="bold",
                      ha="left", va="top",
                      bbox=dict(boxstyle="round,pad=0.35", fc="white",
                                ec=color))


# Örvarnar standa hægra megin við gögnin og enda allar í 2025-gildi hverrar
# raðar; merkimiðarnir sitja fyrir ofan örvarnar svo ekkert skarist, nema
# merkimiði Áfram Íslands sem liggur við efri hluta sinnar (mun hærri) örvar.
# Ör Áfram Íslands spannar úrtak þeirra sjálfra (2013 til 2025).
xs = [Y1 + 1.2, Y1 + 5.2, Y1 + 10.4, Y1 + 14.0]
arrow_box(ax, xs[0], series["IS"][2013], series["IS"][Y1],
          "Áfram Ísland\n+68%", "#4d94d0", anchor="side")
arrow_box(ax, xs[1], 100, nordic_avg[Y1],
          f"Norðurlönd\ní ESB +{nordic_avg[Y1]-100:.0f}%", "#5a5a5a")
arrow_box(ax, xs[2], 100, series["EU27_2020"][Y1],
          f"ESB\n+{series['EU27_2020'][Y1]-100:.0f}%", "#c00000")
arrow_box(ax, xs[3], 100, series["IS_low"][Y1],
          f"Ísland\n+{series['IS_low'][Y1]-100:.0f}%", "#1f5fa8")

ax.set_xlim(Y0, Y1 + 16.2)
ax.set_ylim(74, 142)
ax.set_xticks(range(Y0, Y1 + 1, 3))
ax.set_ylabel(f"vísitala, {Y0} = 100")
ax.set_title("Kaupmáttur á Íslandi frá hruni samkvæmt öðrum mælikvarða",
             fontsize=15.5)
ax.legend(fontsize=11, loc="upper left")
ax.grid(lw=0.3, alpha=0.5)
fig.tight_layout(rect=(0, 0.115, 1, 1))
FN1 = 9
fig.text(0.01, 0.078,
         "*+68% er birt tala Áfram Íslands (LCI/HICP, 2013–2025); árleg nálgun "
         "þjóðhagsreikninga á sama tímabili: +63%.",
         fontsize=FN1, color="#666666")
fig.text(0.01, 0.012,
         "Öll lönd: laun á launþega m.v. einkaneysluverðvísitölu þjóðhagsreikninga "
         "(með húsnæði); vísitala neysluverðs gæfi Íslandi +6%.\nNorðurlönd innan "
         "ESB: Danmörk, Svíþjóð og Finnland, vegin með fjölda launþega.",
         fontsize=FN1, color="#666666", va="bottom")
fig.savefig(FIG / "m15b_kaupmattur_2007.png")

print(tbl.loc[[2007, 2009, 2013, 2015, 2019, 2024, 2025]].round(1).to_string())

# ===========================================================================
# Mynd m15_kaupmattur: endurgerð myndar Áfram Íslands, sama smíð og snið,
# en aðeins Ísland, ESB og Norðurlönd í ESB. Ársfjórðungsleg launavísitala
# Eurostat (D11, NACE B-S, SCA, 2020=100) deilt með ársfjórðungsmeðaltali
# mánaðarlegrar HICP, 1. ársfj. 2013 = 100.
# ===========================================================================
def hicp_q(geo):
    m = pd.read_csv(RAW / f"estat_prc_hicp_midx_{geo}.csv")
    s = m.set_index("TIME_PERIOD")["OBS_VALUE"].astype(float)
    return s.groupby(s.index.str[:4] + "-Q" +
                     ((s.index.str[5:7].astype(int) - 1) // 3 + 1).astype(str)
                     ).mean()


def lci_real_q(geo):
    d = pd.read_csv(RAW / f"estat_lc_lci_r2_q_{geo}.csv")
    d = d[(d.lcstruct == "D11") & (d.s_adj == "SCA") & (d.unit == "I20")]
    lci = d.set_index("TIME_PERIOD")["OBS_VALUE"].astype(float).sort_index()
    r = (lci / hicp_q(geo)).dropna()
    r = r / r["2013-Q1"] * 100
    return r[(r.index >= "2013-Q1") & (r.index <= "2025-Q4")]


def qf(idx):
    return [float(q[:4]) + (int(q[-1]) - 1) / 4 for q in idx]


rep = {g: lci_real_q(g) for g in GEOS}
# ársfjórðungsleg samtala Norðurlanda: sömu launþegavogir, yfirfærðar á
# ársfjórðunga eftir ári
common_q = rep["DK"].index
wq = {g: pd.Series([float(w_emp[g][int(q[:4])]) for q in common_q],
                   index=common_q) for g in NORD}
wq_tot = sum(wq.values())
nord_q_avg = sum(rep[g] * wq[g] for g in NORD) / wq_tot

fig2, ax2 = plt.subplots(figsize=(8.6, 5.4))
ax2.plot(qf(rep["IS"].index), rep["IS"].values, color="#2f6db4", lw=2.4,
         label="Ísland")
ax2.plot(qf(rep["EU27_2020"].index), rep["EU27_2020"].values,
         color="#c00000", lw=2, label="ESB")
ax2.plot(qf(nord_q_avg.index), nord_q_avg.values, color="#1a2b4a", lw=2,
         label="Norðurlönd í ESB")
ax2.axhline(100, color="grey", lw=0.7, ls="--")

# merkimiðar fyrir ofan örvarnar; háa örin fyrir Áfram Ísland fær sinn
# merkimiða við efri hlutann. +68% er haldið til samræmis við birta síðu
# (endurgerður endapunktur: +67%).
is_end = rep["IS"].iloc[-1]
eu_end = rep["EU27_2020"].iloc[-1]
no_end = nord_q_avg.iloc[-1]
x_end = qf(rep["IS"].index)[-1]
arrow_box(ax2, x_end + 0.8, 100, is_end, "Áfram Ísland\n+68%", "#2f6db4",
          anchor="side")
arrow_box(ax2, x_end + 5.2, 100, eu_end, f"ESB\n+{eu_end-100:.0f}%",
          "#c00000")
arrow_box(ax2, x_end + 9.0, 100, no_end,
          f"Norðurlönd í ESB\n+{no_end-100:.0f}%", "#1a2b4a")

ax2.set_title("Kaupmáttarvöxtur samkvæmt Áfram Íslandi síðustu ár\n"
              "„sama á hvaða mælikvarða er litið“",
              fontsize=15.5)
ax2.set_xticks(range(2013, 2026, 2))
ax2.set_xlim(2013, 2037.5)
ax2.set_ylim(93, 180)
ax2.legend(fontsize=11, loc="upper left")
ax2.grid(lw=0.3, alpha=0.4)
fig2.tight_layout(rect=(0, 0.045, 1, 1))
fig2.text(0.01, 0.012, "Heimild: Eurostat (lc_lci_r2_q, prc_hicp_midx). "
          "Norðurlönd innan ESB: DK, SE, FI, vegin með fjölda launþega.",
          fontsize=9, color="#666666")
fig2.savefig(FIG / "m15_kaupmattur.png")

print("\nendapunktar endurgerðar (2013-Q1=100):",
      {g: round(rep[g].iloc[-1], 1) for g in ("IS", "EU27_2020")},
      "Nordic avg:", round(nord_q_avg.iloc[-1], 1))
