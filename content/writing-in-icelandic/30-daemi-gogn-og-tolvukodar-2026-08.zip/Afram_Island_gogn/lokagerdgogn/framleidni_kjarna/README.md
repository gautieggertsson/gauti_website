# Framleiðnipróf Íslands án auðlindageira

Prófar hvort hátt heildarframleiðnistig vinnuafls á Íslandi (vinnsluvirði á
vinnustund, EU27=100) sé breiðfætt eða samþjappað í A03 (fiskveiðum og
fiskeldi), D (rafmagni, gasi, gufu og loftræstingu) og C24 (framleiðslu
grunnmálma).

Einingin stendur sjálfstætt; tölur hennar eru handfærðar í `forrit/gera_myndir.m`
(mynd `m3b_framleidnistig.pdf`) og prófaðar gegn frystu skránni með
`profa_m3b_samraemi.py`.

## Afurðir

| Skrá | Innihald |
|---|---|
| `memo/memo.md` | Minnisblað með niðurstöðum og túlkun |
| `memo/S0_S4_table.csv` | Sæti Íslands undir næmnisútfærslum S0–S4 |
| `country_productivity_resource_exclusion.csv` | Aðalúttaksskráin, öll lönd og ár |
| `figs/` (verður til við keyrslu `06_figures.py`) | Mynd A: raðirnar tvær, sama ár og lönd; Mynd B: geirasúlur Íslands á móti vestrænu miðgildi |
| `data/raw/*.json`, `data/raw/retrieval_log.json` | Frosin, óbreytt API-svör Eurostat ásamt nákvæmum fyrirspurnaslóðum og tímastimplum |
| `data/processed/*.csv` | Milliborð, samanburðarhópatölur, stöðugleika- og næmnistöflur |
| `code/01..07_*.py` | Öll keyrsluröðin, keyrð í talnaröð |
| `profa_m3b_samraemi.py` | Samræmispróf handfærðu gildanna í `forrit/gera_myndir.m` |

## Endurgerð

```bash
cd code
python3 01_fetch_eurostat.py       # sækir hrá JSON-svör Eurostat að nýju (netið þarf; sleppa má til að nota frystu svörin)
python3 02_build_panel.py          # afkóðar JSON-stat -> snyrt borð + jafnvirðisstuðla
python3 03_determine_year.py       # heildleikafylki -> aðalár = 2023
python3 04_analysis.py             # kjarnamælingar, næmni, aðalúttaksskráin
python3 05_comparison_groups.py    # hópatölur EU27/vestræns hóps/evrusvæðis/Norðurlanda, stöðugleiki
python3 06_figures.py              # Mynd A og Mynd B
python3 07_fair_comparison.py      # sömu-úrtaks (sanngjarn) sætasamanburður minnisblaðsins
```

## Gagnaheimildir og skilgreiningar

- **Vinnsluvirði**: `nama_10_a64`, na_item=`B1G` (vergt vinnsluvirði á
  grunnverði), eining=`CP_MEUR` (evrur á verðlagi hvers árs). Engin
  jafnvirðiseining er til á A64-sundurliðun, svo evruvinnsluvirði hverrar
  atvinnugreinar er umreiknað í jafnvirðisstaðal með lands- og
  ársbundnum stuðli úr `nama_10_gdp` (na_item=`B1GQ`, `CP_MEUR` /
  `CP_MPPS_EU27_2020`). Vinnsluvirði (ekki landsframleiðsla) er notað í
  geirafrádrættinum því vöruskattar að frádregnum styrkjum verða ekki
  greindir á atvinnugreinar.
- **Vinnustundir**: `nama_10_a64_e`, na_item=`EMP_DC` (heildarstörf,
  innlent hugtak, launþegar og sjálfstætt starfandi), eining=`THS_HW`
  (þúsundir vinnustunda).
- **Lönd**: EU27 (samsetning 2020) auk Íslands; Noregi aðeins bætt við þar
  sem tekið er fram (Norðurlandapróf).
- **Aðalár**: 2023, síðasta árið með birt bæði sundurliðað vinnsluvirði og
  vinnustundir Íslands (vinnustundir 2024–25 eru til en vinnsluvirði ekki
  enn). Ráðið eingöngu af heildleika gagna, ekki af niðurstöðunni (sjá
  úttak `03_determine_year.py`).
- **Vantandi/trúnaðargögn**: Belgía, Búlgaría, Þýskaland, Eistland,
  Frakkland, Litáen, Lúxemborg (vinnustundir A03 og/eða C24) og Malta
  (vinnustundir D) birta enga nothæfa vinnustundasundurliðun þessara
  atvinnugreina neitt ár 2013–2023. Þau eru *undanskilin*
  geirafrádráttarsamanburðinum (S3/S4) og merkt í `data_flags`; aldrei
  fyllt með núllum. Allar íslenskar sellur sem notaðar eru bera merkið `p`
  (bráðabirgðatölur) hjá Eurostat.
- **Sanngjarn samanburður**: þar sem LP_all (28 lönd) og LP_core (20 lönd)
  hafa ólíka úrtakssamsetningu nota allar sætabreytingafullyrðingar
  minnisblaðsins *sama* fasta 20 landa úrtakið (eða 11 landa vestræna
  hópinn) fyrir báðar útfærslur (sjá `07_fair_comparison.py`).
  Aðalúttaksskráin birtir að auki óskertu dálkana
  `rank_all_eu27`/`rank_core_eu27`.
- **OECD (2025)**: Mosiashvili og Jin, „Firm-level productivity dynamics in
  Iceland", OECD Economics Department Working Papers nr. 1847 (læst
  áskrift; útdráttur og OECD-hagskýrslan um Ísland 2025 aðeins notuð til
  eigindlegrar krossprófunar; ekkert línurit var talnalesið eða notað sem
  gögn).
