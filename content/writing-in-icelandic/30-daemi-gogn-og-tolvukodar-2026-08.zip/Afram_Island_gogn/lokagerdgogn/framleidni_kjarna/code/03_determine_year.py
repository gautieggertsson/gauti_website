"""
Determine the latest year for which Iceland and a sufficiently complete set of
EU27 countries have non-missing GVA and hours for TOTAL, A03, D and C24.

Prints a completeness matrix (country x year) and writes it to
data/processed/completeness_report.csv.
"""
import os

import pandas as pd

PROC_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "processed")

EU27_2020 = [
    "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "EL",
    "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK",
    "SI", "ES", "SE",
]
GEOS = EU27_2020 + ["IS"]
NACE = ["TOTAL", "A03", "D", "C24"]


def main():
    panel = pd.read_csv(os.path.join(PROC_DIR, "panel_long.csv"))
    panel = panel[panel.geo.isin(GEOS)]

    rows = []
    for year in sorted(panel.year.unique()):
        for geo in GEOS:
            sub = panel[(panel.year == year) & (panel.geo == geo)]
            complete = True
            missing_bits = []
            for n in NACE:
                r = sub[sub.nace_r2 == n]
                has_gva = (not r.empty) and pd.notna(r["gva_meur"].iloc[0])
                has_hours = (not r.empty) and pd.notna(r["hours_ths"].iloc[0])
                if not (has_gva and has_hours):
                    complete = False
                    missing_bits.append(n)
            rows.append({
                "year": year, "geo": geo, "complete": complete,
                "missing": ";".join(missing_bits),
            })

    rep = pd.DataFrame(rows)
    rep.to_csv(os.path.join(PROC_DIR, "completeness_report.csv"), index=False)

    print("Countries with complete TOTAL/A03/D/C24 GVA+hours, by year (count out of {}):".format(len(GEOS)))
    summary = rep.groupby("year")["complete"].sum()
    print(summary.to_string())

    print("\nIceland completeness by year:")
    print(rep[rep.geo == "IS"][["year", "complete", "missing"]].to_string(index=False))

    print("\nFor each year, which countries are INCOMPLETE:")
    for year in sorted(rep.year.unique()):
        incomplete = rep[(rep.year == year) & (~rep.complete)]
        if not incomplete.empty:
            print(f"  {year}: " + ", ".join(f"{r.geo}({r.missing})" for _, r in incomplete.iterrows()))
        else:
            print(f"  {year}: (all complete)")


if __name__ == "__main__":
    main()
