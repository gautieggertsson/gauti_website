"""
Freeze raw Eurostat downloads for the Iceland sector-exclusion productivity test.

Datasets:
  - nama_10_a64    : Gross value added (B1G), current prices, million euro, by A*64 industry
  - nama_10_a64_e  : Hours worked (THS_HW), domestic concept, total employment (EMP_DC), by A*64 industry
  - nama_10_gdp    : GDP (B1GQ), current prices, million euro AND million PPS (EU27 from 2020)

Countries: EU27 (2020 composition) + Iceland + Norway.
Industries: TOTAL, A03 (fishing & aquaculture), D (electricity, gas, steam, air-con), C24 (basic metals).

Every raw response is saved verbatim (unmodified JSON) together with the exact
query URL and a retrieval timestamp, per the task's freezing requirement.
"""
import json
import os
import subprocess
import time
import urllib.parse

RAW_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
os.makedirs(RAW_DIR, exist_ok=True)

BASE = "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data"

EU27_2020 = [
    "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "EL",
    "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK",
    "SI", "ES", "SE",
]
GEOS = EU27_2020 + ["IS", "NO"]
NACE = ["TOTAL", "A03", "D", "C24", "B"]  # B (mining & quarrying) added for S4 sensitivity
SINCE = "2013"


def build_url(dataset, params, geos=None, nace=None):
    q = []
    for k, v in params.items():
        q.append((k, v))
    if geos:
        for g in geos:
            q.append(("geo", g))
    if nace:
        for n in nace:
            q.append(("nace_r2", n))
    qs = urllib.parse.urlencode(q)
    return f"{BASE}/{dataset}?{qs}"


def fetch(url, outfile):
    result = subprocess.run(
        ["curl", "-s", "--fail", "-A", "iceland-productivity-test/1.0", url],
        capture_output=True, check=True,
    )
    data = result.stdout
    with open(outfile, "wb") as f:
        f.write(data)
    return json.loads(data)


def main():
    log = []
    retrieval_ts = time.strftime("%Y-%m-%dT%H:%M:%S%z")

    jobs = [
        (
            "nama_10_a64",
            {"format": "JSON", "lang": "EN", "na_item": "B1G", "unit": "CP_MEUR",
             "sinceTimePeriod": SINCE},
            GEOS, NACE,
            "nama_10_a64_gva_raw.json",
        ),
        (
            "nama_10_a64_e",
            {"format": "JSON", "lang": "EN", "na_item": "EMP_DC", "unit": "THS_HW",
             "sinceTimePeriod": SINCE},
            GEOS, NACE,
            "nama_10_a64_e_hours_raw.json",
        ),
        (
            "nama_10_gdp",
            {"format": "JSON", "lang": "EN", "na_item": "B1GQ",
             "unit": "CP_MEUR", "sinceTimePeriod": SINCE},
            GEOS, None,
            "nama_10_gdp_eur_raw.json",
        ),
        (
            "nama_10_gdp",
            {"format": "JSON", "lang": "EN", "na_item": "B1GQ",
             "unit": "CP_MPPS_EU27_2020", "sinceTimePeriod": SINCE},
            GEOS, None,
            "nama_10_gdp_pps_raw.json",
        ),
    ]

    for dataset, params, geos, nace, outfile in jobs:
        url = build_url(dataset, params, geos, nace)
        outpath = os.path.join(RAW_DIR, outfile)
        print(f"Fetching {dataset} -> {outfile}")
        d = fetch(url, outpath)
        n_obs = len(d.get("value", {}))
        print(f"  {n_obs} observations, size={d.get('size')}")
        log.append({
            "dataset": dataset,
            "outfile": outfile,
            "query_url": url,
            "retrieval_timestamp_utc": retrieval_ts,
            "n_observations": n_obs,
            "eurostat_updated": d.get("updated"),
        })
        time.sleep(1)

    with open(os.path.join(RAW_DIR, "retrieval_log.json"), "w") as f:
        json.dump(log, f, indent=2)
    print("Wrote retrieval_log.json")


if __name__ == "__main__":
    main()
