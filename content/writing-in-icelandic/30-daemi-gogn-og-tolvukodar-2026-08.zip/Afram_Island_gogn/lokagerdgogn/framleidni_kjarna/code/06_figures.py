"""
Figure A: two country rankings, same year (2023), same countries (S3-complete
set of 20: EU27 members with usable A03/D/C24 hours+GVA, plus Iceland) —
all-sector GVA/hour vs GVA/hour excluding A03, D, C24. Iceland highlighted;
Western peers shown in a restrained distinct colour.

Figure B: Iceland's four sector bars (A03, D, C24, residual core) against the
Western-group median.
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

PROC_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "processed")
FIG_DIR = os.path.join(os.path.dirname(__file__), "..", "figs")
os.makedirs(FIG_DIR, exist_ok=True)

WESTERN_EU = ["AT", "BE", "DK", "FI", "FR", "DE", "EL", "IE", "IT", "LU", "NL", "PT", "ES", "SE"]

COUNTRY_NAMES_IS = {
    "AT": "Austria", "BE": "Belgium", "BG": "Bulgaria", "HR": "Croatia", "CY": "Cyprus",
    "CZ": "Czechia", "DK": "Denmark", "EE": "Estonia", "FI": "Finland", "FR": "France",
    "DE": "Germany", "EL": "Greece", "HU": "Hungary", "IE": "Ireland", "IT": "Italy",
    "LV": "Latvia", "LT": "Lithuania", "LU": "Luxembourg", "MT": "Malta", "NL": "Netherlands",
    "PL": "Poland", "PT": "Portugal", "RO": "Romania", "SK": "Slovakia", "SI": "Slovenia",
    "ES": "Spain", "SE": "Sweden", "IS": "Iceland", "NO": "Norway",
}

COL_ICELAND = "#1f5fa8"
COL_WESTERN = "#8faedb"
COL_OTHER = "#c9c9c9"
COL_BAR_CORE = "#4d4d4d"


def bar_color(geo):
    if geo == "IS":
        return COL_ICELAND
    if geo in WESTERN_EU:
        return COL_WESTERN
    return COL_OTHER


def figure_a():
    fa = pd.read_csv(os.path.join(PROC_DIR, "figureA_data.csv"))
    fa["country_name"] = fa.geo.map(COUNTRY_NAMES_IS)

    fig, axes = plt.subplots(1, 2, figsize=(13, 8), sharey=False)

    for ax, col, title in zip(
        axes, ["lp_all", "lp_core"],
        ["A. All sectors\n(GVA per hour, PPS)", "B. Excluding A03, D, C24\n(GVA per hour, PPS)"]
    ):
        d = fa.sort_values(col, ascending=True)
        colors = [bar_color(g) for g in d.geo]
        ax.barh(d.country_name, d[col], color=colors, edgecolor="white", height=0.7)
        for y, (v, geo) in enumerate(zip(d[col], d.geo)):
            weight = "bold" if geo == "IS" else "normal"
            ax.text(v + 0.5, y, f"{v:.0f}", va="center", ha="left", fontsize=8, weight=weight)
        ax.set_title(title, fontsize=11)
        ax.set_xlim(0, fa[["lp_all"]].values.max() * 1.15)
        ax.tick_params(axis="y", labelsize=8)
        for label in ax.get_yticklabels():
            if label.get_text() == "Iceland":
                label.set_weight("bold")
                label.set_color(COL_ICELAND)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    handles = [
        plt.Rectangle((0, 0), 1, 1, color=COL_ICELAND, label="Iceland"),
        plt.Rectangle((0, 0), 1, 1, color=COL_WESTERN, label="Mature Western EU peers"),
        plt.Rectangle((0, 0), 1, 1, color=COL_OTHER, label="Other EU countries"),
    ]
    fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False, fontsize=9, bbox_to_anchor=(0.5, 0.06))
    fig.suptitle(
        "Figure A. Iceland's rank barely moves when fishing, electricity and basic metals are\n"
        "removed from both value added and hours — 2023, same 20 countries in both panels",
        fontsize=12, y=0.995,
    )
    fig.text(0.5, 0.005, "Source: Eurostat nama_10_a64 / nama_10_a64_e / nama_10_gdp. Sample: EU27 members\n"
                        "with usable A03/D/C24 hours-worked data, plus Iceland (n=20). Provisional Icelandic data.",
              ha="center", fontsize=7.5, color="#555555")
    fig.tight_layout(rect=[0, 0.13, 1, 0.94])
    out = os.path.join(FIG_DIR, "figureA_ranking_comparison.png")
    fig.savefig(out, dpi=200)
    fig.savefig(out.replace(".png", ".pdf"))
    print("Wrote", out)


def figure_b():
    fb = pd.read_csv(os.path.join(PROC_DIR, "figureB_data.csv"))
    order = ["A03", "D", "C24", "Core"]
    fb = fb.set_index("sector").loc[order].reset_index()
    labels = {
        "A03": "Fishing &\naquaculture (A03)",
        "D": "Electricity, gas,\nsteam, air-con (D)",
        "C24": "Basic metals\n(C24)",
        "Core": "Residual core\neconomy",
    }

    fig, ax = plt.subplots(figsize=(8, 6))
    x = range(len(order))
    width = 0.35
    bars_isl = ax.bar([i - width / 2 for i in x], fb["iceland_lp"], width,
                       label="Iceland", color=COL_ICELAND)
    bars_med = ax.bar([i + width / 2 for i in x], fb["western_median_lp"], width,
                       label="Mature Western EU median", color=COL_WESTERN)

    for bars in (bars_isl, bars_med):
        for b in bars:
            h = b.get_height()
            ax.text(b.get_x() + b.get_width() / 2, h + 2, f"{h:.0f}", ha="center", va="bottom", fontsize=9)

    ax.set_xticks(list(x))
    ax.set_xticklabels([labels[s] for s in order], fontsize=9)
    ax.set_ylabel("GVA per hour worked, PPS (current prices, 2023)")
    ax.set_title(
        "Figure B. Iceland's core economy is also above the Western-group median —\n"
        "the gap is largest in fishing, electricity and basic metals",
        fontsize=11,
    )
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(frameon=False, fontsize=9)
    fig.text(0.5, 0.01, "Source: Eurostat nama_10_a64 / nama_10_a64_e / nama_10_gdp, 2023. Western-group\n"
                        "median = AT, DK, EL, ES, FI, IE, IT, NL, PT, SE (countries with usable sector detail).",
              ha="center", fontsize=7.5, color="#555555")
    fig.tight_layout(rect=[0, 0.06, 1, 1])
    out = os.path.join(FIG_DIR, "figureB_iceland_sector_bars.png")
    fig.savefig(out, dpi=200)
    fig.savefig(out.replace(".png", ".pdf"))
    print("Wrote", out)


if __name__ == "__main__":
    figure_a()
    figure_b()
