"""
Core analysis for the Iceland sector-exclusion labour-productivity test.

Computes, for EU27 + Iceland (+ Norway where noted):
  - LP_all, LP_core (S3: exclude A03, D, C24)
  - GVA/hours excluded shares, resource_productivity_boost
  - Sequential decomposition of the A03/D/C24 contribution to LP_all - LP_core
  - Sensitivity specifications S0-S4
  - Comparison-group medians/means and Iceland's ranks
  - The required output CSV
"""
import os

import numpy as np
import pandas as pd

PROC_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "processed")

EU27_2020 = [
    "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "EL",
    "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK",
    "SI", "ES", "SE",
]
WESTERN_EU = ["AT", "BE", "DK", "FI", "FR", "DE", "EL", "IE", "IT", "LU", "NL", "PT", "ES", "SE"]
EURO_AREA = ["AT", "BE", "HR", "CY", "EE", "FI", "FR", "DE", "EL", "IE", "IT",
             "LV", "LT", "LU", "MT", "NL", "PT", "SK", "SI", "ES"]
NORDIC = ["DK", "FI", "SE"]

COUNTRY_NAMES = {
    "AT": "Austria", "BE": "Belgium", "BG": "Bulgaria", "HR": "Croatia", "CY": "Cyprus",
    "CZ": "Czechia", "DK": "Denmark", "EE": "Estonia", "FI": "Finland", "FR": "France",
    "DE": "Germany", "EL": "Greece", "HU": "Hungary", "IE": "Ireland", "IT": "Italy",
    "LV": "Latvia", "LT": "Lithuania", "LU": "Luxembourg", "MT": "Malta", "NL": "Netherlands",
    "PL": "Poland", "PT": "Portugal", "RO": "Romania", "SK": "Slovakia", "SI": "Slovenia",
    "ES": "Spain", "SE": "Sweden", "IS": "Iceland", "NO": "Norway",
}

PRINCIPAL_YEAR = 2023
THREE_YEARS = [2021, 2022, 2023]
SECTOR_ORDER = ["A03", "D", "C24"]  # matches S1 -> S2 -> S3 sequence


def load_wide():
    panel = pd.read_csv(PROC_DIR + "/panel_long.csv")
    ppp = pd.read_csv(PROC_DIR + "/ppp_factors.csv")[["geo", "year", "eur_per_pps"]]

    wide = panel.pivot_table(
        index=["geo", "year"], columns="nace_r2",
        values=["gva_meur", "hours_ths"], aggfunc="first",
    )
    wide.columns = [f"{a}_{b}" for a, b in wide.columns]
    wide = wide.reset_index()

    flags = panel.pivot_table(
        index=["geo", "year"], columns="nace_r2",
        values=["gva_meur_flag", "hours_ths_flag"], aggfunc="first",
    )
    flags.columns = [f"{a}_{b}" for a, b in flags.columns]
    flags = flags.reset_index()

    wide = wide.merge(flags, on=["geo", "year"], how="left")
    wide = wide.merge(ppp, on=["geo", "year"], how="left")
    return wide


def to_pps(df, meur_col):
    return df[meur_col] / df["eur_per_pps"]


def build_country_year_metrics(wide):
    df = wide.copy()

    for n in ["TOTAL", "A03", "D", "C24", "B"]:
        gva_col = f"gva_meur_{n}"
        if gva_col in df.columns:
            df[f"gva_pps_{n}"] = to_pps(df, gva_col)

    # data completeness / flag summary for the S3 sector set
    required_cols = []
    for n in ["TOTAL", "A03", "D", "C24"]:
        required_cols += [f"gva_meur_{n}", f"hours_ths_{n}"]
    df["s3_complete"] = df[required_cols].notna().all(axis=1)

    def flagstr(row):
        bits = []
        for n in ["TOTAL", "A03", "D", "C24"]:
            for kind, col in [("gva", f"gva_meur_flag_{n}"), ("hw", f"hours_ths_flag_{n}")]:
                v = row.get(col)
                if isinstance(v, str) and v.strip():
                    bits.append(f"{n}:{kind}={v.strip()}")
        if not row["s3_complete"]:
            missing = [n for n in ["TOTAL", "A03", "D", "C24"]
                       if pd.isna(row.get(f"gva_meur_{n}")) or pd.isna(row.get(f"hours_ths_{n}"))]
            bits.append("missing_detail:" + ",".join(missing))
        return ";".join(bits) if bits else ""

    df["data_flags"] = df.apply(flagstr, axis=1)

    # sensitivity specs: cumulative exclusion sets
    specs = {
        "S0": [],
        "S1": ["A03"],
        "S2": ["A03", "D"],
        "S3": ["A03", "D", "C24"],
        "S4": ["A03", "B", "D", "C24"],
    }
    for spec, excl in specs.items():
        need_cols = [f"gva_meur_{n}" for n in excl] + [f"hours_ths_{n}" for n in excl]
        have_all = df[need_cols].notna().all(axis=1) if need_cols else pd.Series(True, index=df.index)

        gva_excl_meur = sum((df[f"gva_meur_{n}"].fillna(0) for n in excl), start=pd.Series(0.0, index=df.index))
        hours_excl = sum((df[f"hours_ths_{n}"].fillna(0) for n in excl), start=pd.Series(0.0, index=df.index))

        gva_rem_meur = df["gva_meur_TOTAL"] - gva_excl_meur
        hours_rem = df["hours_ths_TOTAL"] - hours_excl
        gva_rem_pps = gva_rem_meur / df["eur_per_pps"]

        lp = gva_rem_pps * 1000.0 / hours_rem  # PPS per hour worked
        lp = lp.where(have_all & df["hours_ths_TOTAL"].notna() & df["gva_meur_TOTAL"].notna())
        df[f"lp_{spec}"] = lp
        df[f"{spec}_complete"] = have_all

    df["lp_all"] = df["lp_S0"]
    df["lp_core"] = df["lp_S3"]

    df["gva_excluded_share"] = (
        df["gva_meur_A03"].fillna(0) + df["gva_meur_D"].fillna(0) + df["gva_meur_C24"].fillna(0)
    ) / df["gva_meur_TOTAL"]
    df["hours_excluded_share"] = (
        df["hours_ths_A03"].fillna(0) + df["hours_ths_D"].fillna(0) + df["hours_ths_C24"].fillna(0)
    ) / df["hours_ths_TOTAL"]
    df["resource_productivity_boost"] = df["lp_all"] / df["lp_core"] - 1.0

    # sequential contribution decomposition: A03 = S0-S1, D = S1-S2, C24 = S2-S3
    df["contrib_A03"] = df["lp_S0"] - df["lp_S1"]
    df["contrib_D"] = df["lp_S1"] - df["lp_S2"]
    df["contrib_C24"] = df["lp_S2"] - df["lp_S3"]

    # per-sector productivity levels (PPS/hour) and multiple relative to core
    for n in ["A03", "D", "C24", "B"]:
        gva_col = f"gva_pps_{n}"
        hours_col = f"hours_ths_{n}"
        if gva_col in df.columns:
            df[f"lp_{n}"] = df[gva_col] * 1000.0 / df[hours_col]
    df["lp_multiple_A03"] = df["lp_A03"] / df["lp_core"]
    df["lp_multiple_D"] = df["lp_D"] / df["lp_core"]
    df["lp_multiple_C24"] = df["lp_C24"] / df["lp_core"]

    # identity check: LP_all = hours_excl_share*LP_excluded_pooled + (1-share)*LP_core
    gva_excl_pps = (df["gva_pps_A03"].fillna(0) + df["gva_pps_D"].fillna(0) + df["gva_pps_C24"].fillna(0))
    hours_excl = (df["hours_ths_A03"].fillna(0) + df["hours_ths_D"].fillna(0) + df["hours_ths_C24"].fillna(0))
    df["lp_excluded_pooled"] = gva_excl_pps * 1000.0 / hours_excl
    df["identity_check_lp_all"] = (
        df["hours_excluded_share"] * df["lp_excluded_pooled"]
        + (1 - df["hours_excluded_share"]) * df["lp_core"]
    )
    df["identity_residual"] = df["lp_all"] - df["identity_check_lp_all"]

    return df


def rank_within(df, year, geos, value_col, ascending=False):
    sub = df[(df.year == year) & (df.geo.isin(geos)) & df[value_col].notna()].copy()
    sub["rank"] = sub[value_col].rank(ascending=ascending, method="min").astype(int)
    return sub.set_index("geo")["rank"]


def main():
    wide = load_wide()
    df = build_country_year_metrics(wide)

    out_dir = PROC_DIR
    df.to_csv(os.path.join(out_dir, "metrics_all_countries_years.csv"), index=False)

    # ---- Focus on principal year ----
    py = df[df.year == PRINCIPAL_YEAR].copy()

    all_geos = EU27_2020 + ["IS"]
    r_all_eu27 = rank_within(df, PRINCIPAL_YEAR, all_geos, "lp_all")
    r_core_eu27 = rank_within(df, PRINCIPAL_YEAR, all_geos, "lp_core")
    western_geos = WESTERN_EU + ["IS"]
    r_all_western = rank_within(df, PRINCIPAL_YEAR, western_geos, "lp_all")
    r_core_western = rank_within(df, PRINCIPAL_YEAR, western_geos, "lp_core")

    py = py.set_index("geo")
    py["rank_all_eu27"] = r_all_eu27
    py["rank_core_eu27"] = r_core_eu27
    py["rank_all_western"] = r_all_western
    py["rank_core_western"] = r_core_western
    py = py.reset_index()

    print("=" * 80)
    print(f"PRINCIPAL YEAR: {PRINCIPAL_YEAR}")
    print("=" * 80)
    print(f"\nEU27+IS countries with complete S3 data: {py[py.s3_complete].geo.isin(all_geos).sum()} of {len(all_geos)}")
    missing_s3 = sorted(set(all_geos) - set(py[py.s3_complete].geo))
    print("Missing from S3 (core) comparison:", [COUNTRY_NAMES[g] for g in missing_s3])

    isl = py[py.geo == "IS"].iloc[0]
    print(f"\nIceland {PRINCIPAL_YEAR}:")
    print(f"  LP_all  = {isl['lp_all']:.2f} PPS/hour   (rank {int(isl['rank_all_eu27'])} of {r_all_eu27.notna().sum()} in EU27+IS)")
    print(f"  LP_core = {isl['lp_core']:.2f} PPS/hour   (rank {int(isl['rank_core_eu27'])} of {r_core_eu27.notna().sum()} in EU27+IS)")
    print(f"  Western rank all:  {int(isl['rank_all_western'])} of {r_all_western.notna().sum()}")
    print(f"  Western rank core: {int(isl['rank_core_western'])} of {r_core_western.notna().sum()}")
    print(f"  GVA excluded share  = {isl['gva_excluded_share']*100:.2f}%")
    print(f"  Hours excluded share= {isl['hours_excluded_share']*100:.2f}%")
    print(f"  resource_productivity_boost = {isl['resource_productivity_boost']*100:.1f}%")
    print(f"  contributions (PPS/hr): A03={isl['contrib_A03']:.2f} D={isl['contrib_D']:.2f} C24={isl['contrib_C24']:.2f}")
    print(f"  identity residual = {isl['identity_residual']:.6f}")

    # ---- Save required CSV ----
    cols_map = {
        "geo": "country", "year": "year",
        "gva_pps_TOTAL": "gva_total_pps", "hours_ths_TOTAL": "hours_total",
        "gva_pps_A03": "gva_a03_pps", "hours_ths_A03": "hours_a03",
        "gva_pps_D": "gva_d_pps", "hours_ths_D": "hours_d",
        "gva_pps_C24": "gva_c24_pps", "hours_ths_C24": "hours_c24",
        "lp_all": "lp_all", "lp_core": "lp_core",
        "resource_productivity_boost": "resource_productivity_boost",
        "gva_excluded_share": "gva_excluded_share",
        "hours_excluded_share": "hours_excluded_share",
        "data_flags": "data_flags",
    }
    full = df[df.geo.isin(all_geos)].copy()
    r_all_full = full.groupby("year").apply(
        lambda g: g.set_index("geo")["lp_all"].rank(ascending=False, method="min")
    ).reset_index()
    # simpler: compute ranks per year directly
    out_rows = []
    for year in sorted(full.year.unique()):
        sub = full[full.year == year]
        ra = rank_within(df, year, all_geos, "lp_all")
        rc = rank_within(df, year, all_geos, "lp_core")
        raw = rank_within(df, year, western_geos, "lp_all")
        rcw = rank_within(df, year, western_geos, "lp_core")
        for _, row in sub.iterrows():
            g = row["geo"]
            rec = {v: row.get(k) for k, v in cols_map.items()}
            rec["country_name"] = COUNTRY_NAMES.get(g, g)
            rec["rank_all_eu27"] = ra.get(g, np.nan)
            rec["rank_core_eu27"] = rc.get(g, np.nan)
            rec["rank_all_western"] = raw.get(g, np.nan)
            rec["rank_core_western"] = rcw.get(g, np.nan)
            out_rows.append(rec)
    out_df = pd.DataFrame(out_rows)
    ordered_cols = [
        "country", "country_name", "year", "gva_total_pps", "hours_total",
        "gva_a03_pps", "hours_a03", "gva_d_pps", "hours_d", "gva_c24_pps", "hours_c24",
        "lp_all", "lp_core", "resource_productivity_boost", "gva_excluded_share",
        "hours_excluded_share", "rank_all_eu27", "rank_core_eu27",
        "rank_all_western", "rank_core_western", "data_flags",
    ]
    out_df = out_df[ordered_cols].sort_values(["year", "country"])
    csv_path = os.path.join(os.path.dirname(__file__), "..", "country_productivity_resource_exclusion.csv")
    out_df.to_csv(csv_path, index=False)
    print(f"\nWrote {csv_path} ({len(out_df)} rows)")


if __name__ == "__main__":
    main()
