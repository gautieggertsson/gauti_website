"""
Parse the frozen Eurostat JSON-stat files and build a tidy country-year-industry
panel for the Iceland sector-exclusion productivity test.

Output: data/processed/panel_long.csv (one row per country-year-industry-series)
        data/processed/ppp_factors.csv (euro-per-PPS conversion factor by country-year)
"""
import itertools
import json
import os

import pandas as pd

RAW_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
PROC_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "processed")
os.makedirs(PROC_DIR, exist_ok=True)


def jsonstat_to_df(path, value_name):
    """Decode a Eurostat JSON-stat 2.0 payload into a tidy long DataFrame."""
    with open(path) as f:
        d = json.load(f)

    dim_ids = d["id"]
    sizes = d["size"]
    dims = d["dimension"]

    # For each dimension, build an ordered list of codes (by category index).
    ordered_codes = []
    for dim_id in dim_ids:
        cat = dims[dim_id]["category"]
        index = cat["index"]
        # index maps code -> position; invert to get position -> code
        pos_to_code = {v: k for k, v in index.items()}
        codes = [pos_to_code[i] for i in range(len(pos_to_code))]
        ordered_codes.append(codes)

    assert [len(c) for c in ordered_codes] == sizes, "size mismatch while decoding"

    values = d.get("value", {})
    status = d.get("status", {})

    rows = []
    # value keys are stringified linear indices in row-major order over dim_ids
    for lin_idx_str, val in values.items():
        lin_idx = int(lin_idx_str)
        # decompose linear index (row-major, last dim fastest)
        idx = []
        remaining = lin_idx
        for size in reversed(sizes):
            idx.append(remaining % size)
            remaining //= size
        idx = list(reversed(idx))
        row = {dim_ids[k]: ordered_codes[k][idx[k]] for k in range(len(dim_ids))}
        row[value_name] = val
        row[value_name + "_flag"] = status.get(lin_idx_str, "")
        rows.append(row)

    return pd.DataFrame(rows)


def main():
    gva = jsonstat_to_df(os.path.join(RAW_DIR, "nama_10_a64_gva_raw.json"), "gva_meur")
    hours = jsonstat_to_df(os.path.join(RAW_DIR, "nama_10_a64_e_hours_raw.json"), "hours_ths")
    gdp_eur = jsonstat_to_df(os.path.join(RAW_DIR, "nama_10_gdp_eur_raw.json"), "gdp_meur")
    gdp_pps = jsonstat_to_df(os.path.join(RAW_DIR, "nama_10_gdp_pps_raw.json"), "gdp_mpps")

    print("GVA rows:", len(gva), "| geos:", gva["geo"].nunique(), "| nace:", sorted(gva["nace_r2"].unique()))
    print("Hours rows:", len(hours), "| geos:", hours["geo"].nunique(), "| nace:", sorted(hours["nace_r2"].unique()))
    print("GDP EUR rows:", len(gdp_eur), "| GDP PPS rows:", len(gdp_pps))

    gva = gva[["geo", "time", "nace_r2", "gva_meur", "gva_meur_flag"]].rename(columns={"time": "year"})
    hours = hours[["geo", "time", "nace_r2", "hours_ths", "hours_ths_flag"]].rename(columns={"time": "year"})

    panel = pd.merge(gva, hours, on=["geo", "year", "nace_r2"], how="outer")
    panel["year"] = panel["year"].astype(int)

    panel_path = os.path.join(PROC_DIR, "panel_long.csv")
    panel.to_csv(panel_path, index=False)
    print(f"Wrote {panel_path} ({len(panel)} rows)")

    # PPP factor: euro per PPS = GDP(current EUR) / GDP(current PPS), national-accounts (B1GQ) basis
    gdp_eur = gdp_eur[["geo", "time", "gdp_meur", "gdp_meur_flag"]].rename(columns={"time": "year"})
    gdp_pps = gdp_pps[["geo", "time", "gdp_mpps", "gdp_mpps_flag"]].rename(columns={"time": "year"})
    ppp = pd.merge(gdp_eur, gdp_pps, on=["geo", "year"], how="outer")
    ppp["year"] = ppp["year"].astype(int)
    ppp["eur_per_pps"] = ppp["gdp_meur"] / ppp["gdp_mpps"]

    ppp_path = os.path.join(PROC_DIR, "ppp_factors.csv")
    ppp.to_csv(ppp_path, index=False)
    print(f"Wrote {ppp_path} ({len(ppp)} rows)")

    # Quick sanity print for Iceland
    print("\nIceland eur_per_pps by year:")
    print(ppp[ppp.geo == "IS"].sort_values("year").to_string(index=False))


if __name__ == "__main__":
    main()
