"""
Fair (same country sample) comparisons needed for the GO/NO-GO test:
  - Iceland's rank under LP_all vs LP_core, holding the country sample fixed
    to the S3-complete set (so rank changes reflect the sector exclusion only,
    not differing data availability).
  - Same for the Western group.
  - Sensitivity S0-S4 on the same fixed (S3-complete) sample.
  - EU27=100 style index for Iceland under LP_all vs LP_core on the same sample.
"""
import os

import pandas as pd

PROC_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "processed")
EU27_2020 = [
    "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "EL",
    "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK",
    "SI", "ES", "SE",
]
WESTERN_EU = ["AT", "BE", "DK", "FI", "FR", "DE", "EL", "IE", "IT", "LU", "NL", "PT", "ES", "SE"]
WESTERN_EXCL_IE_LU = [g for g in WESTERN_EU if g not in ("IE", "LU")]
PRINCIPAL_YEAR = 2023


def fair_rank_block(df, year, geos, label):
    sub = df[(df.year == year) & (df.geo.isin(geos)) & (df.s3_complete)].copy()
    sub["rank_all_sameset"] = sub["lp_all"].rank(ascending=False, method="min")
    sub["rank_core_sameset"] = sub["lp_core"].rank(ascending=False, method="min")
    n = len(sub)
    isl = sub[sub.geo == "IS"]
    print(f"\n--- {label} (n={n} countries with complete S3 data) ---")
    print(sub[["geo", "lp_all", "lp_core", "rank_all_sameset", "rank_core_sameset"]]
          .sort_values("lp_all", ascending=False).to_string(index=False))
    if not isl.empty:
        r_all = int(isl["rank_all_sameset"].iloc[0])
        r_core = int(isl["rank_core_sameset"].iloc[0])
        print(f"Iceland: rank_all={r_all}  rank_core={r_core}  change={r_core - r_all:+d} places  (n={n})")
    return sub


def sensitivity_same_sample(df, year):
    all_geos = EU27_2020 + ["IS"]
    base = df[(df.year == year) & (df.geo.isin(all_geos)) & (df.s3_complete)]
    fixed_geos = base.geo.tolist()
    rows = []
    for spec in ["S0", "S1", "S2", "S3", "S4"]:
        col = f"lp_{spec}"
        sub = df[(df.year == year) & (df.geo.isin(fixed_geos))][["geo", col]].dropna()
        rank = int(sub[col].rank(ascending=False, method="min").loc[sub.geo == "IS"].iloc[0])
        val = sub.loc[sub.geo == "IS", col].iloc[0]
        rows.append({"spec": spec, "iceland_lp": val, "iceland_rank_fixed_sample": rank, "n": len(sub)})
    out = pd.DataFrame(rows)
    print(f"\n--- Sensitivity S0-S4, FIXED sample of {len(fixed_geos)} countries (EU27+IS) ---")
    print(out.to_string(index=False))
    return out


def index_eu27_100(df, year, value_col_all, value_col_core):
    all_geos = EU27_2020
    d = df[(df.year == year) & (df.geo.isin(all_geos)) & (df.s3_complete)]
    agg_all = d["gva_pps_TOTAL"].sum() * 1000 / d["hours_ths_TOTAL"].sum()
    gva_core = d["gva_pps_TOTAL"] - d["gva_pps_A03"].fillna(0) - d["gva_pps_D"].fillna(0) - d["gva_pps_C24"].fillna(0)
    hours_core = d["hours_ths_TOTAL"] - d["hours_ths_A03"].fillna(0) - d["hours_ths_D"].fillna(0) - d["hours_ths_C24"].fillna(0)
    agg_core = gva_core.sum() * 1000 / hours_core.sum()
    isl = df[(df.year == year) & (df.geo == "IS")].iloc[0]
    idx_all = isl["lp_all"] / agg_all * 100
    idx_core = isl["lp_core"] / agg_core * 100
    print(f"\n--- EU27(S3-complete, n={d.geo.nunique()})=100 index, {year} ---")
    print(f"Iceland index_all  = {idx_all:.1f}")
    print(f"Iceland index_core = {idx_core:.1f}")
    print(f"Change: {idx_core - idx_all:+.1f} points ({(idx_core/idx_all-1)*100:+.1f}% relative)")
    return idx_all, idx_core


def main():
    df = pd.read_csv(os.path.join(PROC_DIR, "metrics_all_countries_years.csv"))

    fair_rank_block(df, PRINCIPAL_YEAR, EU27_2020 + ["IS"], "EU27+Iceland")
    fair_rank_block(df, PRINCIPAL_YEAR, WESTERN_EU + ["IS"], "Western group + Iceland")
    fair_rank_block(df, PRINCIPAL_YEAR, WESTERN_EXCL_IE_LU + ["IS"], "Western group (excl IE, LU) + Iceland")

    sens = sensitivity_same_sample(df, PRINCIPAL_YEAR)
    sens.to_csv(os.path.join(PROC_DIR, "sensitivity_S0_S4_fixed_sample.csv"), index=False)

    index_eu27_100(df, PRINCIPAL_YEAR, "lp_all", "lp_core")

    # multi-year fair rank stability
    print("\n" + "=" * 90)
    print("Multi-year fair-rank stability (EU27+IS, S3-complete sample each year)")
    print("=" * 90)
    for year in range(2019, 2024):
        sub = df[(df.year == year) & (df.geo.isin(EU27_2020 + ["IS"])) & (df.s3_complete)].copy()
        sub["rank_all"] = sub["lp_all"].rank(ascending=False, method="min")
        sub["rank_core"] = sub["lp_core"].rank(ascending=False, method="min")
        isl = sub[sub.geo == "IS"]
        if not isl.empty:
            print(f"{year}: n={len(sub)}  rank_all={int(isl.rank_all.iloc[0])}  rank_core={int(isl.rank_core.iloc[0])}  "
                  f"boost={isl.resource_productivity_boost.iloc[0]*100:.1f}%")


if __name__ == "__main__":
    main()
