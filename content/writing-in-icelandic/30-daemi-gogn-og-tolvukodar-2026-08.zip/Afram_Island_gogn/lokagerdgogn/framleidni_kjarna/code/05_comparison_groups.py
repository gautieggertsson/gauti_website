"""
Comparison-group medians/means and Iceland's rank, for the principal year and
the three-year average, under LP_all and LP_core.

Also produces:
  - Figure A data (two rankings, same year/countries)
  - Figure B data (Iceland vs Western median sector profile)
  - S0-S4 sensitivity table
  - Stability-across-years table
"""
import os

import numpy as np
import pandas as pd

PROC_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "processed")

EU27_2020 = [
    "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "EL",
    "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK",
    "SI", "ES", "SE",
]
WESTERN_EU = ["AT", "BE", "DK", "FI", "FR", "DE", "EL", "IE", "IT", "LU", "NL", "PT", "ES", "SE"]
WESTERN_EXCL_IE_LU = [g for g in WESTERN_EU if g not in ("IE", "LU")]
EURO_AREA = ["AT", "BE", "HR", "CY", "EE", "FI", "FR", "DE", "EL", "IE", "IT",
             "LV", "LT", "LU", "MT", "NL", "PT", "SK", "SI", "ES"]
NORDIC = ["DK", "FI", "SE"]
NORDIC_NO = NORDIC + ["NO"]

COUNTRY_NAMES = {
    "AT": "Austria", "BE": "Belgium", "BG": "Bulgaria", "HR": "Croatia", "CY": "Cyprus",
    "CZ": "Czechia", "DK": "Denmark", "EE": "Estonia", "FI": "Finland", "FR": "France",
    "DE": "Germany", "EL": "Greece", "HU": "Hungary", "IE": "Ireland", "IT": "Italy",
    "LV": "Latvia", "LT": "Lithuania", "LU": "Luxembourg", "MT": "Malta", "NL": "Netherlands",
    "PL": "Poland", "PT": "Portugal", "RO": "Romania", "SK": "Slovakia", "SI": "Slovenia",
    "ES": "Spain", "SE": "Sweden", "IS": "Iceland", "NO": "Norway",
}

PRINCIPAL_YEAR = 2023
THREE_YEARS = [2021, 2022, 2023]


def group_stats(df, year, geos, value_col, s3_filter=False):
    sub = df[(df.year == year) & (df.geo.isin(geos))]
    if s3_filter:
        sub = sub[sub.s3_complete]
    vals = sub[["geo", value_col]].dropna()
    iceland_val = vals.loc[vals.geo == "IS", value_col]
    eu_only = vals[vals.geo != "IS"]
    rank = int(vals[value_col].rank(ascending=False, method="min").loc[vals.geo == "IS"].iloc[0]) if not iceland_val.empty else np.nan
    return {
        "n": len(vals),
        "median_incl_is": vals[value_col].median(),
        "mean_incl_is": vals[value_col].mean(),
        "median_excl_is": eu_only[value_col].median(),
        "mean_excl_is": eu_only[value_col].mean(),
        "iceland_value": iceland_val.iloc[0] if not iceland_val.empty else np.nan,
        "iceland_rank": rank,
        "n_incl_is": len(vals),
    }


def main():
    df = pd.read_csv(os.path.join(PROC_DIR, "metrics_all_countries_years.csv"))

    groups = {
        "EU27+IS": EU27_2020 + ["IS"],
        "Western+IS": WESTERN_EU + ["IS"],
        "Western(excl IE,LU)+IS": WESTERN_EXCL_IE_LU + ["IS"],
        "EuroArea+IS": EURO_AREA + ["IS"],
        "Nordic+IS": NORDIC + ["IS"],
        "Nordic+NO+IS": NORDIC_NO + ["IS"],
    }

    print("=" * 100)
    print(f"COMPARISON GROUPS — principal year {PRINCIPAL_YEAR}")
    print("=" * 100)
    rows = []
    for gname, geos in groups.items():
        for metric, s3f in [("lp_all", False), ("lp_core", True)]:
            st = group_stats(df, PRINCIPAL_YEAR, geos, metric, s3_filter=s3f)
            rows.append({"group": gname, "metric": metric, **st})
    gdf = pd.DataFrame(rows)
    print(gdf.to_string(index=False))
    gdf.to_csv(os.path.join(PROC_DIR, "comparison_groups_principal_year.csv"), index=False)

    # ---- three-year average: average the ANNUAL ratios per country, per spec ----
    print("\n" + "=" * 100)
    print(f"THREE-YEAR AVERAGE ({THREE_YEARS[0]}-{THREE_YEARS[-1]}) — average of annual ratios")
    print("=" * 100)
    sub3 = df[df.year.isin(THREE_YEARS)]
    avg3 = sub3.groupby("geo").agg(
        lp_all_avg3=("lp_all", "mean"),
        lp_core_avg3=("lp_core", "mean"),
        n_years_lp_all=("lp_all", "count"),
        n_years_lp_core=("lp_core", "count"),
        s3_complete_all3=("s3_complete", "all"),
    ).reset_index()
    avg3.to_csv(os.path.join(PROC_DIR, "three_year_average.csv"), index=False)

    all_geos = EU27_2020 + ["IS"]
    a3 = avg3[avg3.geo.isin(all_geos)].copy()
    a3["rank_all_3yr"] = a3["lp_all_avg3"].rank(ascending=False, method="min")
    complete3 = a3[a3.s3_complete_all3].copy()
    complete3["rank_core_3yr"] = complete3["lp_core_avg3"].rank(ascending=False, method="min")
    isl_all = a3[a3.geo == "IS"].iloc[0]
    isl_core = complete3[complete3.geo == "IS"].iloc[0] if (complete3.geo == "IS").any() else None
    print(f"Iceland 3yr avg LP_all  = {isl_all['lp_all_avg3']:.2f}  rank {int(isl_all['rank_all_3yr'])} of {len(a3)}")
    if isl_core is not None:
        print(f"Iceland 3yr avg LP_core = {isl_core['lp_core_avg3']:.2f}  rank {int(isl_core['rank_core_3yr'])} of {len(complete3)}")

    # ---- per-year stability check ----
    print("\n" + "=" * 100)
    print("PER-YEAR STABILITY CHECK (2019-2023)")
    print("=" * 100)
    stab_rows = []
    for year in range(2019, 2024):
        ydf = df[df.year == year]
        all_geos_y = EU27_2020 + ["IS"]
        vals_all = ydf[ydf.geo.isin(all_geos_y)][["geo", "lp_all"]].dropna()
        vals_core = ydf[(ydf.geo.isin(all_geos_y)) & (ydf.s3_complete)][["geo", "lp_core"]].dropna()
        isl_a = vals_all[vals_all.geo == "IS"]
        isl_c = vals_core[vals_core.geo == "IS"]
        rank_a = int(vals_all["lp_all"].rank(ascending=False, method="min").loc[isl_a.index[0]]) if len(isl_a) else np.nan
        rank_c = int(vals_core["lp_core"].rank(ascending=False, method="min").loc[isl_c.index[0]]) if len(isl_c) else np.nan
        stab_rows.append({
            "year": year,
            "lp_all_iceland": isl_a["lp_all"].iloc[0] if len(isl_a) else np.nan,
            "rank_all_eu27": rank_a,
            "n_all": len(vals_all),
            "lp_core_iceland": isl_c["lp_core"].iloc[0] if len(isl_c) else np.nan,
            "rank_core_eu27": rank_c,
            "n_core": len(vals_core),
        })
    stab_df = pd.DataFrame(stab_rows)
    print(stab_df.to_string(index=False))
    stab_df.to_csv(os.path.join(PROC_DIR, "stability_by_year.csv"), index=False)

    # ---- Sensitivity table S0-S4 ----
    print("\n" + "=" * 100)
    print(f"SENSITIVITY S0-S4 — Iceland rank in EU27+IS, {PRINCIPAL_YEAR}")
    print("=" * 100)
    sens_rows = []
    for spec in ["S0", "S1", "S2", "S3", "S4"]:
        col = f"lp_{spec}"
        comp_col = f"{spec}_complete"
        sub = df[(df.year == PRINCIPAL_YEAR) & (df.geo.isin(all_geos)) & (df[comp_col])]
        vals = sub[["geo", col]].dropna()
        rank = int(vals[col].rank(ascending=False, method="min").loc[vals.geo == "IS"].iloc[0]) if (vals.geo == "IS").any() else np.nan
        isl_val = vals.loc[vals.geo == "IS", col].iloc[0] if (vals.geo == "IS").any() else np.nan
        sens_rows.append({"spec": spec, "iceland_lp": isl_val, "iceland_rank_eu27is": rank, "n_countries": len(vals)})
    sens_df = pd.DataFrame(sens_rows)
    print(sens_df.to_string(index=False))
    sens_df.to_csv(os.path.join(PROC_DIR, "sensitivity_S0_S4.csv"), index=False)

    # ---- Figure A data: two rankings, same year & same countries (S3-complete set) ----
    fa = df[(df.year == PRINCIPAL_YEAR) & (df.geo.isin(all_geos)) & (df.s3_complete)][
        ["geo", "lp_all", "lp_core"]
    ].copy()
    fa["country_name"] = fa.geo.map(COUNTRY_NAMES)
    fa["is_iceland"] = fa.geo == "IS"
    fa["is_western"] = fa.geo.isin(WESTERN_EU)
    fa.to_csv(os.path.join(PROC_DIR, "figureA_data.csv"), index=False)
    print(f"\nWrote figureA_data.csv ({len(fa)} countries, S3-complete set)")

    # ---- Figure B data: Iceland 4 bars vs Western-group median ----
    isl_row = df[(df.year == PRINCIPAL_YEAR) & (df.geo == "IS")].iloc[0]
    western_complete = df[(df.year == PRINCIPAL_YEAR) & (df.geo.isin(WESTERN_EU)) & (df.s3_complete)]
    fb_rows = []
    for sector, lp_col in [("A03", "lp_A03"), ("D", "lp_D"), ("C24", "lp_C24"), ("Core", "lp_core")]:
        fb_rows.append({
            "sector": sector,
            "iceland_lp": isl_row[lp_col],
            "western_median_lp": western_complete[lp_col].median(),
            "eu27_median_lp": df[(df.year == PRINCIPAL_YEAR) & (df.geo.isin(EU27_2020)) & (df.s3_complete)][lp_col].median(),
        })
    fb = pd.DataFrame(fb_rows)
    fb.to_csv(os.path.join(PROC_DIR, "figureB_data.csv"), index=False)
    print("\nFigure B data (Iceland sector productivity vs Western median):")
    print(fb.to_string(index=False))

    # ---- Sector profile table ----
    print("\n" + "=" * 100)
    print("SECTOR PROFILE — Iceland, Western median, EU27 median")
    print("=" * 100)
    profile_rows = []
    for sector in ["A03", "D", "C24"]:
        isl_share_gva = isl_row[f"gva_meur_{sector}"] / isl_row["gva_meur_TOTAL"]
        isl_share_hours = isl_row[f"hours_ths_{sector}"] / isl_row["hours_ths_TOTAL"]
        isl_multiple = isl_row[f"lp_multiple_{sector}"]
        profile_rows.append({
            "sector": sector,
            "iceland_lp_pps_hr": isl_row[f"lp_{sector}"],
            "western_median_lp": western_complete[f"lp_{sector}"].median(),
            "eu27_median_lp": df[(df.year == PRINCIPAL_YEAR) & (df.geo.isin(EU27_2020)) & (df.s3_complete)][f"lp_{sector}"].median(),
            "iceland_gva_share": isl_share_gva,
            "iceland_hours_share": isl_share_hours,
            "iceland_multiple_vs_core": isl_multiple,
        })
    prof_df = pd.DataFrame(profile_rows)
    print(prof_df.to_string(index=False))
    prof_df.to_csv(os.path.join(PROC_DIR, "sector_profile.csv"), index=False)


if __name__ == "__main__":
    main()
