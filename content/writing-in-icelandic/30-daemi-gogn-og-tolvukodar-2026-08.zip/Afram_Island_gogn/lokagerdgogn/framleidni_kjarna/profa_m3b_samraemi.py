#!/usr/bin/env python3
"""Samræmispróf fyrir m3b-blokkina í forrit/gera_myndir.m.

Ber handfærðu gildin í lpal/lpco (virðisaukning á unna stund 2023, PPS)
saman við frystu skrána country_productivity_resource_exclusion.csv
(dálkar lp_all og lp_core, árið 2023), ásamt vestrænu miðgildunum 51,9
og 44,9 sem myndin sýnir. Keyrsla frá rót pakkans:

    python3 lokagerdgogn/framleidni_kjarna/profa_m3b_samraemi.py

Prófið fellur (exit 1) ef eitthvert gildi víkur meira en 0,05 frá
frystu gögnunum eftir námundun í eina aukastafatölu.
"""
import csv
import os
import re
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROT = os.path.abspath(os.path.join(HERE, "..", ".."))

NOFN = {
    "Ireland": "Írland", "Denmark": "Danmörk", "Netherlands": "Holland",
    "Iceland": "Ísland", "Austria": "Austurríki", "Sweden": "Svíþjóð",
    "Finland": "Finnland", "Italy": "Ítalía", "Spain": "Spánn",
    "Slovenia": "Slóvenía", "Czechia": "Tékkland",
    "Czech Republic": "Tékkland", "Slovakia": "Slóvakía",
    "Cyprus": "Kýpur", "Romania": "Rúmenía", "Hungary": "Ungverjaland",
    "Croatia": "Króatía", "Portugal": "Portúgal", "Poland": "Pólland",
    "Latvia": "Lettland", "Greece": "Grikkland",
}
# Vestræni hópurinn er skilgreindur í frystu skránni sjálfri: ríki með gildi
# í dálknum rank_all_western (14 ríki auk Íslands árið 2023, þar af 10 með
# kjarnasundurliðun). Miðgildin á myndinni eru reiknuð án Íslands.


def lesa_blokk(src, nafn):
    m = re.search(nafn + r"\s*=\s*\{(.*?)\};", src, re.S)
    return {k: float(v) for k, v in re.findall(r"'([^']+)',([0-9.]+)", m.group(1))}


def main():
    src = open(os.path.join(ROT, "forrit", "gera_myndir.m"), encoding="utf-8").read()
    lpal, lpco = lesa_blokk(src, "lpal"), lesa_blokk(src, "lpco")

    csvskra = os.path.join(HERE, "country_productivity_resource_exclusion.csv")
    fryst_all, fryst_core = {}, {}
    vest_all, vest_core = [], []
    for r in csv.DictReader(open(csvskra, encoding="utf-8")):
        if r["year"] != "2023":
            continue
        if r["rank_all_western"] and r["country_name"] != "Iceland":
            if r["lp_all"]:
                vest_all.append(float(r["lp_all"]))
            if r["lp_core"]:
                vest_core.append(float(r["lp_core"]))
        nafn = NOFN.get(r["country_name"])
        if nafn is None:
            continue
        if r["lp_all"]:
            fryst_all[nafn] = float(r["lp_all"])
        if r["lp_core"]:
            fryst_core[nafn] = float(r["lp_core"])

    villur = []
    for heiti, hand, fryst in (("lpal", lpal, fryst_all), ("lpco", lpco, fryst_core)):
        for land, gildi in hand.items():
            if land not in fryst:
                villur.append(f"{heiti}: {land} vantar í frystu gögnin")
                continue
            if abs(gildi - round(fryst[land], 1)) > 0.05:
                villur.append(
                    f"{heiti}: {land} handfært {gildi} en fryst {fryst[land]:.2f}")

    for heiti, gildi, vaent in (("lp_all", vest_all, 51.9),
                                ("lp_core", vest_core, 44.9)):
        midgildi = statistics.median(gildi)
        if abs(round(midgildi, 1) - vaent) > 0.05:
            villur.append(
                f"{heiti}: vestrænt miðgildi (án Íslands) {midgildi:.2f}, "
                f"í mynd {vaent}")

    if villur:
        print("FRÁVIK:")
        for v in villur:
            print(" ", v)
        sys.exit(1)
    print(f"OK: {len(lpal)} lpal-gildi og {len(lpco)} lpco-gildi stemma við "
          f"frystu skrána; vestrænu miðgildin 51,9 og 44,9 stemma.")


if __name__ == "__main__":
    main()
