# Minnisblað: Er hátt heildarframleiðnistig Íslands samþjappað í fiskveiðum, rafmagni og grunnmálmum?

**Gögn:** Eurostat `nama_10_a64`, `nama_10_a64_e`, `nama_10_gdp` (sótt 20.7.2026; allar íslenskar raðir merktar `p`, bráðabirgðatölur). Kóði og hráskrár: `framleidni_kjarna/`.

## 1. Þekja

Síðasta ár með fullbúið vinnsluvirði (B1G, evrur á verðlagi hvers árs) og
vinnustundir (THS_HW, innlent hugtak, `EMP_DC`) fyrir HEILD, A03, D og C24
fyrir Ísland **og** nothæft mengi EU27-ríkja er **2023** (sundurliðað
vinnsluvirði Íslands 2024–25 er óbirt). Þriggja ára meðaltal: 2021–2023.
Átta EU27-ríki (Belgía, Búlgaría, Þýskaland, Eistland, Frakkland, Litáen,
Lúxemborg, Malta) skortir vinnustundasundurliðun A03 eða C24 (Malta: D)
**öll** árin 2013–2023 og eru undanskilin kjarnasamanburðinum
(geirafrádrættinum); merki þeirra er varðveitt í `data_flags`, ekki fyllt
með núllum. Eftir standa **20 af 28** löndum (EU27+Ísland), þar af **11 af
15** í vestræna hópnum (vantar: Belgíu, Frakkland, Þýskaland, Lúxemborg),
fyrir jafngildan S3-samanburð. Allur samanburður hér að neðan heldur þessu
20 landa úrtaki föstu svo sætabreytingar endurspegli geirafrádráttinn
einan, ekki úrtakssamsetningu.

## 2. Stig og sannprófun gagnvart greininni

Sama aðferð (vinnsluvirði/vinnustundir, allar atvinnugreinar, fullt 27
landa EU27-úrtak), 2023: **LP_all = 54,6 PPS/klst., vísitala 122,6
(EU27=100), 7. sæti af 28.** Þetta endurgerir náið, með öðru ári og
vinnsluvirði í stað landsframleiðslu í teljara, tölu greinarinnar frá 2024:
**123,4, 7. sæti** (Eurostat `nama_10_lp_ulc`, byggt á landsframleiðslu).
Við endurgerðum einnig *opinbera* landsframleiðslukvarðann beint: hann
setur Ísland í **5. sæti 2023** og **7. sæti 2024**, tveggja sæta hliðrun
innan einnar gagnaútgáfu, í samræmi við fyrirvara frumskýrslunnar sjálfrar
um að íslenskar tölur séu bráðabirgðatölur og endurskoðunargjarnar.
Vinnsluvirði undanskilur vöruskatta að frádregnum styrkjum (verða ekki
greindir á atvinnugreinar); þess vegna notum við vinnsluvirði en ekki
landsframleiðslu í geirafrádrættinum, og það er jafnframt meginástæða þess
að vinnsluvirðissætið og opinbera landsframleiðslusætið fara ekki alltaf
saman.

## 3. Kjarnaniðurstaða: geirafrádráttur, sömu 20 lönd, 2023

| | LP_all | LP_core (án A03, D, C24) |
|---|---|---|
| Ísland (PPS/klst.) | 54,6 | 51,4 |
| Sæti, EU27+Ísland (n=20) | **4.** | **4.** |
| Sæti, vestræni hópurinn+Ísland (n=11) | **4.** | **4.** |
| Sæti, vestrænt án IE/LU (n=10) | 3. | 3. |
| Vísitala, EU27(n=19)=100 | 135,9 | 130,6 |
| Vestrænt miðgildi (án Íslands) | 51,9 | 44,9 |

Hlutur frádreginna geira í vinnsluvirði Íslands er **10,3%** og í
vinnustundum **4,8%** (2023). **Auðlindaálag framleiðninnar =
LP_all/LP_core − 1 = 6,2%**, það *stærsta meðal landanna 20 með nothæf
gögn*, á móti 1,9% miðgildi vestræna hópsins og 2,0% miðgildi EU27. Sé 3,2
PPS/klst. bilið sundurliðað í röð (A03 → D → C24) leggur rafmagn til 1,78
(56%), grunnmálmar 0,95 (30%) og fiskveiðar 0,45 (14%). Geirasamlagningin
`LP_all = vinnustundahlutur·LP_frádregið + (1−vinnustundahlutur)·LP_core`
stemmir nákvæmlega (leif = 0).

Framleiðnimargfeldi geiranna miðað við kjarnahagkerfi Íslands sjálfs:
**D 4,45×, C24 2,63×, A03 1,38×**, öll með mjög lága vinnustundahluti
(0,98%, 1,08%, 2,69%). Miðað við vestræna miðgildis*stigið* í sama geira er
raforkuframleiðni Íslands varla aðgreinanleg (229 á móti 226 PPS/klst.;
vestrænar veitur eru líka fjármagnsfrekar), en fiskveiðar (71 á móti 25) og
grunnmálmar (135 á móti 52) eru raunverulega 2,6–2,8× vestræna miðgildið,
þ.e. fiskveiði- og álgeirar Íslands eru óvenjuframleiðnir í algildum
fjölþjóðlegum samanburði, ekki aðeins lágstundabjögun.

## 4. Stöðugleiki

| Ár | n | Sæti alls | Sæti kjarna | Álag |
|---|---|---|---|---|
| 2019 | 20 | 4 | 5 | 3,4% |
| 2020 | 20 | 5 | 6 | 4,3% |
| 2021 | 20 | 4 | 5 | 6,1% |
| 2022 | 20 | 4 | 5 | 6,9% |
| 2023 | 20 | 4 | 4 | 6,2% |
| **3 ára meðaltal (2021–23)** | 20 | 4 | 5 | ~6,4% |

Sætið lækkar **í mesta lagi um eitt** hvert ár 2019–2023 (aldrei um fjögur
eða fleiri). Næmni S0→S4 (B, námugreftri, bætt við) á fasta 20 landa
úrtakinu: sætið er **4.** undir hverri einustu útfærslu S0–S4.
Fjölþjóðleg gögn um vinnustundir og vinnsluvirði fiskvinnslu (C10.2) eru
ekki til í þjóðhagsreikningum Eurostat á þeirri sundurliðun og voru ekki
notuð.

## 5. Krosspróf við OECD (2025)

Mosiashvili og Jin (OECD WP 1847) og tengd OECD-hagskýrsla um Ísland
(2025) segja, í samræmi við okkar tölur: heildarframleiðni Íslands helst há
„studd að hluta af starfsemi tengdri náttúruauðlindum"; framleiðnivöxtur
eftir faraldurinn var „drifinn af fjölbreytni og nýsköpun í hefðbundnum
greinum eins og fiskveiðum og ferðaþjónustu"; útflutningur er samþjappaður
í „fiskveiðum, áli og ferðaþjónustu"; og framleiðnivöxtur í skjólgeirum
innlendrar þjónustu er tiltölulega hægur. Engin línurit ritsins voru
talnalesin; þetta er eigindleg samsvörun eingöngu.

## 6. Túlkunarskilyrði

Fjögur skilyrði voru sett fyrirfram um hvaða ályktun gögnin gætu borið:

- **A** (fellur um minnst 4 sæti, EU27+Ísland): **Nei**, fellur um 0–1
  sæti, sama úrtak, hvert ár.
- **B** (fellur í mið- eða neðri helming vestræna hópsins): **Nei**, helst
  í 3.–4. sæti af 10–11 allan tímann.
- **C** (LP_core mest 5% yfir vestrænu miðgildi meðan LP_all er verulega
  hærra): **Nei**, LP_core er **14,6%** yfir vestræna miðgildinu (án
  Íslands), langt yfir 5%.
- **D** (álagið verulega stærra en vestrænt miðgildi): **Já**, 6,2% á móti
  1,9% miðgildi (um 3,2×), stöðugt á bilinu 3,4–6,9% árin 2019–2023.

Stöðugleikinn heldur (sama sætamynstur fimm ár í röð og í þriggja ára
meðaltali) og skilyrði D er uppfyllt, en aðeins fyrir þá þröngu fullyrðingu
sem D styður. Skilyrði A–C, sem myndu réttlæta þá ályktun að framleiðnin
sé sjónhverfing eða að sætið hrynji, eru **ekki** uppfyllt: sæti og stig
Íslands haldast traust í efri hluta þegar nákvæmlega sömu þrír geirar eru
dregnir frá hjá öllum löndum.

**Niðurstaða: auðlindaálag framleiðninnar á Íslandi er hið hæsta í hópnum
og um þrefalt vestrænt miðgildi, en framleiðnisæti Íslands hrynur ekki
þegar geirarnir þrír eru undanskildir; það er sú mynd sem greinin sýnir
(`m3b_framleidnistig`).**
