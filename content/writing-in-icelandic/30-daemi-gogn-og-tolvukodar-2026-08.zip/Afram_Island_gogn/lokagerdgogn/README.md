# Lokagerð gagna: frystar einingar mynda

Hver mappa hér er sjálfstæð, frosin eining fyrir eina eða fleiri myndir
greinarinnar. Einingarnar eiga sameiginlega uppbyggingu:

- `hra/`: óbreytt svör frumgagnabanka (Eurostat, Hagstofa Íslands, Seðlabanki
  Íslands, Seðlabanki Evrópu, Alþjóðagjaldeyrissjóðurinn) eins og þau voru sótt;
- `gogn/`: frosin gagnatafla eða vinnubók með öllum tölum sem myndin notar;
- `lysigogn/`: fyrirspurnir, sóttdagsetningar og SHA-256 gátsummur
  (`manifest.json` eða `MANIFEST.md`);
- `forrit/`: forritið sem les frystu gögnin og teiknar myndina;
- `nidurstodur/`: milliniðurstöður og sannprófunartöflur;
- `mynd/`: verður til við keyrslu og geymir endurgerðu myndina. Birtu myndirnar
  sjálfar eru aðeins í `myndir/` í rót pakkans.

Ekkert forrit hér sækir gögn af netinu við keyrslu. Forritin sem sóttu gögnin
upphaflega (`saekja.py`, `byggja_gogn.py`, `byggja_radir.py`, `01_fetch_eurostat.py`,
`extract_weo_debt.py --refresh`) fylgja með til skjalfestingar á fyrirspurnunum.

## Einingar og myndir

| Mappa | Mynd í greininni | Skipun frá rót pakkans |
|---|---|---|
| `mynd02_verdlag/` | `m2_verdlag.pdf` | `matlab -batch "run('lokagerdgogn/mynd02_verdlag/forrit/gera_mynd02.m')"` |
| `mynd04_vextir/` | `styrivextir_bru.pdf`, `m8_vextir.pdf` (heitir `ibudalan_esb.pdf` í einingunni), `heimili_60m.pdf` | `matlab -batch "run('lokagerdgogn/mynd04_vextir/forrit/gera_vaxtamyndir.m')"` |
| `mynd05_samkeppnishaefni/` | `m9_imd.pdf` (heitir `m5_samkeppnishaefni.pdf` í einingunni) | `python3 lokagerdgogn/mynd05_samkeppnishaefni/forrit/gera_mynd05.py` |
| `framleidni_kjarna/` | gögn `m3b_framleidnistig.pdf` (myndin sjálf er teiknuð í `forrit/gera_myndir.m`) | `python3 lokagerdgogn/framleidni_kjarna/profa_m3b_samraemi.py` |
| `weo_apr2026_debt/` | gögn `m10_skuldir.pdf` (myndin sjálf er teiknuð í `forrit/gera_myndir.m`) | `python3 lokagerdgogn/weo_apr2026_debt/extract_weo_debt.py` |
| `mynd15_kaupmattur/` | `m15_kaupmattur.png`, `m15b_kaupmattur_2007.png` | `python3 lokagerdgogn/mynd15_kaupmattur/forrit/gera_mynd15.py` |
| `mynd16_radstofunartekjur/` | `m16_radstofunartekjur.png` | `python3 lokagerdgogn/mynd16_radstofunartekjur/forrit/gera_mynd16.py` |
| `mynd17_laun_evrur_kaupmattur/` | `m17_laun_evrur_kaupmattur.png` | `python3 lokagerdgogn/mynd17_laun_evrur_kaupmattur/forrit/gera_mynd17.py` |
| `mynd18_vinnandi_hendur/` | `m18_vinnandi_hendur.png` | `python3 lokagerdgogn/mynd18_vinnandi_hendur/forrit/gera_mynd18.py` |
| `mynd19_neysla/` | `m19_neysla.png` | `python3 lokagerdgogn/mynd19_neysla/forrit/gera_mynd19.py` |
| `mynd20_d11_d1/` | `m20_d11_d1.png` | `python3 lokagerdgogn/mynd20_d11_d1/forrit/gera_mynd20.py` |
| `mynd_oecd/` | `mynd4_oecd.png` | `python3 lokagerdgogn/mynd_oecd/forrit/gera_mynd_oecd.py` |

MATLAB-forritin þurfa R2024b eða nýrra og engin viðbótarsöfn. Python-forritin
þurfa Python 3 með `matplotlib` og `pandas`; þau eru keyrð úr hvaða möppu sem
er því slóðir eru reiknaðar út frá staðsetningu forritsins.

Myndirnar sem Python teiknar eru bæti fyrir bæti eins og birtu skrárnar í
`myndir/` þegar sömu útgáfur safnanna eru notaðar. PDF-skrár úr MATLAB og
`gera_mynd05.py` bera tímastimpil í lýsigögnum sínum og eru því bornar saman
eftir röstun (til dæmis `pdftoppm -r 72`), punkt fyrir punkt.

## Stuttar lýsingar

**`mynd02_verdlag/`.** Verðlagsvísir einstaklingsbundinnar neyslu (`A01`)
deilt með hlutfallslegu miðgildi jafngildra ráðstöfunartekna (aðferð síðu 20 í
greiningu Áfram Íslands) á vinstri hlið; verðlagsvísir einkaneysluútgjalda
heimila (`E011`) á hægri hlið. Framreikningur íslenska tekjunefnarans,
afstemming við öll 114 birt gildi síðunnar og næmnipróf eru rakin í
`lysigogn/SAMRAEMING.md`. Frosin vinnubók, hrásvör, fyrirspurnir og gátsummur í
`gogn/`, `hra/` og `lysigogn/manifest.json`.

**`mynd04_vextir/`.** Stýrivaxtabrú Íslands og evrusvæðisins, nafn- og
raunvextir nýrra íbúðalána í 27 ríkjum ESB og á Íslandi, og jafngild föst
greiðsla af 60 m.kr. láni. Heimildir, formúlur og gátsummur í `README.md` og
`lysigogn/MANIFEST.md` einingarinnar.

**`mynd05_samkeppnishaefni/`.** Sæti Íslands í fjórum meginþáttum IMD World
Competitiveness Ranking 2025, úr frystri talnatöflu með blaðsíðutilvísunum í
`lysigogn/manifest.json` og `nidurstodur/NIDURSTODUR.md`. Bókin sjálf fylgir
ekki pakkanum (höfundarréttur), en SHA-256 gátsumma hennar er skráð.

**`framleidni_kjarna/`.** Framleiðnistig vinnuafls 2023 með og án fiskveiða,
orkuvinnslu og málmframleiðslu (A03, D, C24) úr `nama_10_a64`, `nama_10_a64_e`
og `nama_10_gdp`; Python-keyrsluröð 01 til 07, frosin hrásvör og minnisblað.
`profa_m3b_samraemi.py` prófar handfærðu gildin í `forrit/gera_myndir.m` gegn
frystu skránni.

**`weo_apr2026_debt/`.** Vergar skuldir hins opinbera sem hlutfall af
landsframleiðslu, World Economic Outlook apríl 2026, röð `GGXWDG_NGDP`, fyrir
Ísland, öll 27 aðildarríki ESB og ESB-samtölu sjóðsins, 2025 og 2030.

**`mynd15_kaupmattur/`.** Kaupmáttur launa: endurgerð myndar Áfram Íslands
(launavísitala Eurostat deilt með HICP, 1. ársfj. 2013 = 100) og tuttugu ára
samanburður með sömu smíð fyrir öll ríki (laun á launþega deilt með
verðvísitölu einkaneyslu þjóðhagsreikninga, 2007 = 100).

**`mynd16_radstofunartekjur/`.** Kaupmáttur leiðréttra vergra
ráðstöfunartekna heimila á mann (`nasa_10_ki`, `B7G_R_HAB_2010`), rétt
dagsettur, með grunnárunum 2003 og 2007; Norðurlönd í ESB óvegið meðaltal.

**`mynd17_laun_evrur_kaupmattur/`, `mynd18_vinnandi_hendur/`, `mynd19_neysla/`,
`mynd20_d11_d1/`.** Ein frosin gagnatafla og eitt Python-forrit hver: árslaun
á launþega í evrum og að teknu tilliti til verðlags; launatekjur launþega og
vinnutekjur allra vinnandi handa á íbúa; einkaneysla á mann á tveimur
jafnvirðisgengjum; kaupmáttur vinnustundar á launaliðunum `D11` og `D1`.
Heimildir gagnanna eru skráðar í haus hvers forrits og í Viðauka A greinarinnar.

**`mynd_oecd/`.** Níu mælingar á launum Íslendinga eftir stofnunum; inntakið
er frystar niðurstöðutöflur staðreyndaskoðunar höfundar á OECD-launatölunni
(Eggertsson 2026e) og óbreytt niðurhal ILOSTAT.
