#!/usr/bin/env python3
"""
Byggir ../gogn/consumption_per_capita_2024.csv úr hráafritunum í ../hra/.

Tveir mælikvarðar á neyslu á mann 2024 fyrir ESB-27 og Ísland:
  - einkaneysla heimila og félagasamtaka (P31_S14_S15) á mann í PPS eins og
    síða 6 í greiningu Áfram Íslands reiknar hana, með jafnvirðisgengi
    landsframleiðslunnar (nama_10_pc, CP_PPS_EU27_2020_HAB);
  - raunveruleg einstaklingsbundin neysla (AIC) á mann í PPS með
    jafnvirðisgengi neyslunnar (prc_ppp_ind, ppp_cat A01,
    na_item EXP_PPS_EU27_2020_HAB), sá mælikvarði sem Eurostat mælir með.
Keyrsla: python3 byggja_gogn.py. Ekkert netsamband.
"""
import csv
import json
import os


HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "..", "hra")
OUT = os.path.join(HERE, "..", "gogn")
os.makedirs(OUT, exist_ok=True)

EU = "EU27_2020"
EU_MEMBERS = ["AT", "BE", "BG", "HR", "CY", "CZ", "DE", "DK", "EE", "EL",
              "ES", "FI", "FR", "HU", "IE", "IT", "LT", "LU", "LV", "MT",
              "NL", "PL", "PT", "RO", "SE", "SI", "SK"]
NAMES = {
    "AT": "Austurríki", "BE": "Belgía", "BG": "Búlgaría", "HR": "Króatía",
    "CY": "Kýpur", "CZ": "Tékkland", "DE": "Þýskaland", "DK": "Danmörk",
    "EE": "Eistland", "EL": "Grikkland", "ES": "Spánn", "FI": "Finnland",
    "FR": "Frakkland", "HU": "Ungverjaland", "IE": "Írland", "IT": "Ítalía",
    "LT": "Litháen", "LU": "Lúxemborg", "LV": "Lettland", "MT": "Malta",
    "NL": "Holland", "PL": "Pólland", "PT": "Portúgal", "RO": "Rúmenía",
    "SE": "Svíþjóð", "SI": "Slóvenía", "SK": "Slóvakía", "IS": "Ísland",
    EU: "ESB",
}
Y = "2024"
GEOS = EU_MEMBERS + ["IS"]     # ESB-27 og Ísland; ríki utan ESB undanskilin
RANK_GROUP = EU_MEMBERS + ["IS"]


def load_jsonstat(fname):
    d = json.load(open(os.path.join(RAW, fname)))
    dims, sizes = d["id"], d["size"]
    cats = [[c for c, _ in sorted(d["dimension"][k]["category"]["index"].items(),
                                  key=lambda x: x[1])] for k in dims]
    out = {}
    for flat, v in d["value"].items():
        flat = int(flat)
        key, rem = [], flat
        for i in range(len(dims) - 1, -1, -1):
            rem, j = divmod(rem, sizes[i])
            key.append(cats[i][j])
        out[tuple(reversed(key))] = v
    return out


pc = load_jsonstat("estat_nama_10_pc.json")     # (freq, unit, na_item, geo, time)
ppp = load_jsonstat("estat_prc_ppp_ind.json")   # (freq, na_item, ppp_cat, geo, time)

# Smíð síðu 6: einkaneysla heimila og félagasamtaka á mann, jafnvirðisgengi landsframleiðslunnar
deck = {g: pc.get(("A", "CP_PPS_EU27_2020_HAB", "P31_S14_S15", g, Y))
        for g in GEOS + [EU]}
# Leiðrétt: raunveruleg einstaklingsbundin neysla (AIC) á mann, jafnvirðisgengi neyslunnar
aic = {g: ppp.get(("A", "EXP_PPS_EU27_2020_HAB", "A01", g, Y))
       for g in GEOS + [EU]}


def ranks(vals, group):
    ordered = sorted([g for g in group if vals.get(g) is not None],
                     key=lambda g: -vals[g])
    return {g: i + 1 for i, g in enumerate(ordered)}, len(ordered)


r_deck, n = ranks(deck, RANK_GROUP)
r_aic, _ = ranks(aic, RANK_GROUP)

with open(os.path.join(OUT, "consumption_per_capita_2024.csv"), "w",
          newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["geo", "name",
                "slide6_cons_pc_pps_gdp_ppp", "rank_slide6_eu27_plus_is",
                "aic_pc_pps_own_ppp", "rank_aic_eu27_plus_is"])
    for g in sorted(GEOS, key=lambda g: -deck[g]) + [EU]:
        w.writerow([g, NAMES[g], round(deck[g], 1), r_deck.get(g, ""),
                    aic[g], r_aic.get(g, "")])

print(f"Mælikvarði síðu 6: Ísland {deck['IS']:.0f} PPS, sæti {r_deck['IS']} af {n}")
print(f"AIC (eigið jafnvirðisgengi): Ísland {aic['IS']:.0f} PPS, sæti {r_aic['IS']} af {n}")

