#!/usr/bin/env python3
"""
Mynd m19_neysla: neysla á mann, eins og síða 6 í greiningu Áfram Íslands
reiknar hana og rétt reiknuð. Vinstri: einkaneysla heimila á mann umreiknuð
með jafnvirðisgengi landsframleiðslunnar (CP_PPS_EU27_2020_HAB), aðferð
síðunnar, Ísland 2. sæti (122,4). Hægri: raunveruleg einstaklingsbundin
neysla (AIC) á mann á jafnvirðisgengi neyslunnar, Ísland 4. sæti (115,6).
Efsta súlan er mest neysla.

Gögn: ../gogn/consumption_per_capita_2024.csv (fryst tafla úr Eurostat
nama_10_pc og prc_ppp_ind). Ekkert netsamband.
Keyrsla: python3 gera_mynd19.py; myndin skrifast í ../mynd/.
"""
import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

HERE = os.path.dirname(os.path.abspath(__file__))
ROT = os.path.dirname(HERE)
CSV = os.path.join(ROT, "gogn", "consumption_per_capita_2024.csv")
MYND = os.path.join(ROT, "mynd")
os.makedirs(MYND, exist_ok=True)
OUT = os.path.join(MYND, "m19_neysla.png")

EU = "EU27_2020"
RED = "#c8102e"
MUTED = "#9db4c8"
DARK = "#1a1a1a"
GREY = "#8a8a8a"

rows = {}
with open(CSV) as fh:
    for row in csv.DictReader(fh):
        rows[row["geo"]] = row

eu_slide = float(rows[EU]["slide6_cons_pc_pps_gdp_ppp"])
eu_aic = float(rows[EU]["aic_pc_pps_own_ppp"])

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                     "axes.edgecolor": "0.75", "axes.linewidth": 0.8})


def ic(x, nd=1):
    return f"{x:.{nd}f}".replace(".", ",")


def panel(ax, key, eu_val, title, title_color):
    vals = {g: 100.0 * float(r[key]) / eu_val for g, r in rows.items()}
    order = sorted(vals, key=lambda g: -vals[g])
    ypos = list(range(len(order)))[::-1]
    colors = [RED if g == "IS" else (DARK if g == EU else MUTED)
              for g in order]
    ax.barh(ypos, [vals[g] for g in order], height=0.62, color=colors,
            zorder=3)
    for y, g in zip(ypos, order):
        ax.text(vals[g] + 2.5, y, ic(vals[g]), va="center", ha="left",
                fontsize=8.0,
                fontweight="bold" if g in ("IS", EU) else "normal",
                color=RED if g == "IS" else (DARK if g == EU else "0.35"))
    ax.set_yticks(ypos)
    ax.set_yticklabels([rows[g]["name"] for g in order], fontsize=8.8)
    for tick, g in zip(ax.get_yticklabels(), order):
        if g == "IS":
            tick.set_color(RED)
            tick.set_fontweight("bold")
        elif g == EU:
            tick.set_fontweight("bold")
    ax.set_xlim(0, 185)
    ax.xaxis.set_major_locator(mticker.MultipleLocator(50))
    ax.xaxis.set_major_formatter(
        mticker.FuncFormatter(lambda v, _: ic(v, 0)))
    for s in ["top", "right", "left"]:
        ax.spines[s].set_visible(False)
    ax.grid(axis="x", color="0.88", lw=0.8, zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(length=0)
    ax.set_title(title, fontsize=10.6, fontweight="bold", color=title_color,
                 loc="left", pad=10)
    ax.set_xlabel("vísitala, ESB = 100", fontsize=8, color=GREY)
    return vals, order, ypos


fig, (axL, axR) = plt.subplots(1, 2, figsize=(12.6, 9.4))
fig.subplots_adjust(top=0.825, bottom=0.10, left=0.095, right=0.985,
                    wspace=0.44)

valsL, orderL, yposL = panel(
    axL, "slide6_cons_pc_pps_gdp_ppp", eu_slide,
    "Eins og glæran reiknar: neysla á mann\ná jafnvirðisgengi landsframleiðslu",
    DARK)
valsR, orderR, yposR = panel(
    axR, "aic_pc_pps_own_ppp", eu_aic,
    "Rétt breyta: einstaklingsbundin neysla\ná jafnvirðisgengi neyslunnar",
    RED)

isL = yposL[orderL.index("IS")]
axL.annotate("„Nr. 2 í ESB\u201c — en neyslan er\numreiknuð með röngu gengi",
             xy=(valsL["IS"] + 16, isL), xytext=(181, isL - 5.0),
             fontsize=9.0, color=DARK, va="center", ha="right",
             fontweight="bold",
             arrowprops=dict(arrowstyle="->", color=DARK, lw=1.1,
                             connectionstyle="arc3,rad=0.25"))
isR = yposR[orderR.index("IS")]
axR.annotate("Ísland fellur í 4. sæti,\nvísitalan úr 122 í 116",
             xy=(valsR["IS"] + 16, isR), xytext=(181, isR - 5.0),
             fontsize=9.0, color=RED, va="center", ha="right",
             fontweight="bold",
             arrowprops=dict(arrowstyle="->", color=RED, lw=1.1,
                             connectionstyle="arc3,rad=0.25"))

fig.text(0.035, 0.965, "Neysla á mann: rétt jafnvirðisgengi færir Ísland "
         "úr 2. sæti í það 4.",
         fontsize=14, fontweight="bold", color=DARK, ha="left")
fig.text(0.035, 0.928,
         "Neysla á mann 2024 (ESB = 100). Vinstra megin er einkaneysla "
         "heimila umreiknuð með jafnvirðisgengi landsframleiðslunnar — en í "
         "því vegur\nútflutningsverðlag (fiskur, ál, ferðaþjónusta) þungt og "
         "það á ekkert erindi í neyslusamanburð. Hægra megin er raunveruleg "
         "einstaklingsbundin\nneysla (AIC) á jafnvirðisgengi neyslunnar "
         "sjálfrar — kvarðinn sem Eurostat mælir með fyrir samanburð á "
         "lífskjörum heimila.",
         fontsize=9.3, color=GREY, ha="left", va="top")
fig.text(0.035, 0.012,
         "Heimild: Eurostat (nama_10_pc, liður P31_S14_S15, eining "
         "CP_PPS_EU27_2020_HAB; prc_ppp_ind, raunveruleg einstaklingsbundin "
         "neysla á mann í PPS á AIC-gengi);\nútreikningar höfundar. "
         "ESB-ríkin 27 og Ísland, árið 2024.",
         fontsize=6.8, color=GREY, ha="left", va="bottom")

fig.savefig(OUT, dpi=200)
print("written:", OUT)
