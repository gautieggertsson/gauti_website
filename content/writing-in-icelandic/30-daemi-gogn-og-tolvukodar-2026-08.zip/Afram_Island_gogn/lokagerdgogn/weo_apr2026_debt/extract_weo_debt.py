#!/usr/bin/env python3
"""
Extract general government gross debt (% of GDP) from the IMF World Economic
Outlook, April 2026 vintage, for Iceland + all EU27 members + the IMF
"European Union" aggregate, for 2025 and 2030.

Source: IMF Data API (SDMX 2.1), dataflow IMF.RES:WEO version 9.0.0.
This dataflow serves the April 2026 WEO database (the latest full vintage;
the July 2026 WEO Update has no database release). Indicator GGXWDG_NGDP =
"General government gross debt, percent of GDP". No Eurostat data is used.

Usage:
  python3 extract_weo_debt.py            # uses frozen source if present
  python3 extract_weo_debt.py --refresh  # re-download from the IMF API

Outputs (in the script's directory):
  source/weo_apr2026_GGXWDG_NGDP_raw.csv   frozen raw SDMX-CSV API response
  source/provenance.txt                    download URL, date, sha256
  weo_apr2026_debt_ISL_EU27.csv            exact unrounded values, 2025 & 2030
  analysis_summary.txt                     rank, median, mean, tie counts
"""

import csv
import hashlib
import statistics
import subprocess
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC_DIR = HERE / "source"
RAW_FILE = SRC_DIR / "weo_apr2026_GGXWDG_NGDP_raw.csv"
PROV_FILE = SRC_DIR / "provenance.txt"
OUT_CSV = HERE / "weo_apr2026_debt_ISL_EU27.csv"
OUT_TXT = HERE / "analysis_summary.txt"

DATAFLOW = "IMF.RES,WEO,9.0.0"  # April 2026 WEO vintage
INDICATOR = "GGXWDG_NGDP"

EU27 = {
    "AUT": "Austria", "BEL": "Belgium", "BGR": "Bulgaria", "HRV": "Croatia",
    "CYP": "Cyprus", "CZE": "Czech Republic", "DNK": "Denmark",
    "EST": "Estonia", "FIN": "Finland", "FRA": "France", "DEU": "Germany",
    "GRC": "Greece", "HUN": "Hungary", "IRL": "Ireland", "ITA": "Italy",
    "LVA": "Latvia", "LTU": "Lithuania", "LUX": "Luxembourg", "MLT": "Malta",
    "NLD": "Netherlands", "POL": "Poland", "PRT": "Portugal",
    "ROU": "Romania", "SVK": "Slovak Republic", "SVN": "Slovenia",
    "ESP": "Spain", "SWE": "Sweden",
}
ICELAND = {"ISL": "Iceland"}
EU_AGG = {"G998": "European Union (IMF WEO aggregate)"}
ALL_CODES = {**ICELAND, **EU27, **EU_AGG}

URL = (
    "https://api.imf.org/external/sdmx/2.1/data/"
    + DATAFLOW + "/"
    + "+".join(ALL_CODES) + "." + INDICATOR + ".A"
    + "?startPeriod=2025&endPeriod=2030"
)


ACCEPT = "application/vnd.sdmx.data+csv;version=1.0.0"


def _fetch(url: str) -> bytes:
    """Fetch URL; fall back to curl if Python lacks SSL root certificates."""
    try:
        import ssl
        try:
            import certifi
            ctx = ssl.create_default_context(cafile=certifi.where())
        except ImportError:
            ctx = ssl.create_default_context()
        req = urllib.request.Request(url, headers={"Accept": ACCEPT})
        with urllib.request.urlopen(req, timeout=120, context=ctx) as resp:
            return resp.read()
    except urllib.error.URLError:
        return subprocess.run(
            ["curl", "-sSfL", "-H", f"Accept: {ACCEPT}", url],
            check=True, capture_output=True, timeout=180,
        ).stdout


def download_and_freeze() -> None:
    SRC_DIR.mkdir(parents=True, exist_ok=True)
    raw = _fetch(URL)
    RAW_FILE.write_bytes(raw)
    sha = hashlib.sha256(raw).hexdigest()
    PROV_FILE.write_text(
        "IMF World Economic Outlook database, April 2026 vintage\n"
        f"Dataflow: {DATAFLOW} (SDMX 2.1, IMF Data API)\n"
        f"Indicator: {INDICATOR} (General government gross debt, % of GDP)\n"
        f"URL: {URL}\n"
        f"Downloaded (UTC): {datetime.now(timezone.utc).isoformat()}\n"
        f"SHA-256 of raw file: {sha}\n"
    )


def load_values() -> dict:
    """Return {iso: {year: float_string}} from the frozen raw SDMX-CSV."""
    values = {}
    with open(RAW_FILE, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            iso = row["COUNTRY"]
            year = row["TIME_PERIOD"]
            obs = row["OBS_VALUE"]
            if iso in ALL_CODES and year in ("2025", "2030") and obs != "":
                values.setdefault(iso, {})[year] = obs
    return values


def main() -> None:
    if "--refresh" in sys.argv or not RAW_FILE.exists():
        download_and_freeze()
    vals = load_values()

    missing = [c for c in ALL_CODES if c not in vals]
    if missing:
        print(f"WARNING: no data returned for: {missing}", file=sys.stderr)

    # 1. CSV with exact unrounded values (strings copied verbatim from source)
    with open(OUT_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["iso3", "country",
                    "debt_pct_gdp_2025", "debt_pct_gdp_2030",
                    "source"])
        for iso, name in ALL_CODES.items():
            w.writerow([iso, name,
                        vals.get(iso, {}).get("2025", ""),
                        vals.get(iso, {}).get("2030", ""),
                        "IMF WEO April 2026, GGXWDG_NGDP"])

    # 2-5. Ranking and statistics for 2025 (Iceland vs EU27, 28 economies).
    pool = {iso: float(vals[iso]["2025"])
            for iso in list(ICELAND) + list(EU27) if "2025" in vals.get(iso, {})}
    isl = pool["ISL"]
    below = sum(1 for i, v in pool.items() if i != "ISL" and v < isl)
    tied = sum(1 for i, v in pool.items() if i != "ISL" and v == isl)
    above = sum(1 for i, v in pool.items() if i != "ISL" and v > isl)
    # Rank 1 = highest debt ratio. Standard competition ranking ("1224"):
    # Iceland's rank = 1 + number of economies with a strictly higher value;
    # exact ties would share that same rank.
    rank_high = 1 + above
    rank_low = 1 + below  # rank 1 = lowest debt ratio, for reference

    eu_vals = [float(vals[iso]["2025"]) for iso in EU27 if "2025" in vals.get(iso, {})]
    eu_median = statistics.median(eu_vals)
    eu_mean = statistics.mean(eu_vals)  # simple (unweighted) average
    eu_agg_2025 = vals.get("G998", {}).get("2025", "n/a")
    eu_agg_2030 = vals.get("G998", {}).get("2030", "n/a")

    lines = [
        "IMF WEO April 2026 - General government gross debt, % of GDP (GGXWDG_NGDP)",
        "Ranking pool: Iceland + EU27 = 28 economies, year 2025",
        "",
        f"Iceland 2025: {vals['ISL']['2025']}",
        f"Iceland 2030: {vals['ISL'].get('2030', 'n/a')}",
        "",
        f"Countries with a HIGHER 2025 debt ratio than Iceland: {above}",
        f"Countries TIED with Iceland (exact equality of stored values): {tied}",
        f"Countries with a LOWER 2025 debt ratio than Iceland: {below}",
        "",
        f"Iceland's 2025 rank, highest debt = rank 1: {rank_high} of {len(pool)}",
        f"Iceland's 2025 rank, lowest debt = rank 1: {rank_low} of {len(pool)}",
        "Tie treatment: standard competition ranking on exact stored values;",
        "tied economies share the same rank and the next rank is skipped.",
        f"(No ties occur here: tied count = {tied}.)" if tied == 0 else
        f"(Ties present: {tied} economies share Iceland's rank.)",
        "",
        f"EU27 simple mean 2025 (unweighted, {len(eu_vals)} members): {eu_mean!r}",
        f"EU27 median 2025 ({len(eu_vals)} members): {eu_median!r}",
        "",
        f"IMF EU aggregate (G998 'European Union') 2025: {eu_agg_2025}",
        f"IMF EU aggregate (G998 'European Union') 2030: {eu_agg_2030}",
        "IMF construction of the aggregate (WEO database documentation, 'Data",
        "and Conventions'): composites for fiscal/debt data are sums of member",
        "countries' levels after conversion to U.S. dollars at average market",
        "exchange rates; the group ratio is total EU debt divided by total EU",
        "GDP. This equals a GDP-weighted (market-rate) average of member ratios,",
        "so it is dominated by large high-debt members and is NOT a simple mean.",
    ]
    OUT_TXT.write_text("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
