#!/usr/bin/env python3
"""
Mynd m17_laun_evrur_kaupmattur: sömu árslaun á launþega 2024 sýnd tvisvar,
í evrum (Ísland 2. sæti) og leiðrétt fyrir verðlagi neyslu (Ísland 12. sæti,
rétt undir meðaltali ESB).

Gögn: ../gogn/kaupmattur_launthegi_2024.csv (fryst tafla úr Eurostat
nama_10_a10 D11, nama_10_a10_e SAL_DC og prc_ppp_ind A01). Ekkert netsamband.
Keyrsla: python3 gera_mynd17.py; myndin skrifast í ../mynd/.
"""
import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

HERE = os.path.dirname(os.path.abspath(__file__))
ROT = os.path.dirname(HERE)
CSV = os.path.join(ROT, "gogn", "kaupmattur_launthegi_2024.csv")
MYND = os.path.join(ROT, "mynd")
os.makedirs(MYND, exist_ok=True)

EU = "EU27_2020"
RED = "#c8102e"
MUTED = "#9db4c8"
DARK = "#1a1a1a"
GREY = "#8a8a8a"

rows = {}
with open(CSV) as fh:
    for row in csv.DictReader(fh):
        rows[row["geo"]] = row

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                     "axes.edgecolor": "0.75", "axes.linewidth": 0.8})


def ic(x, nd=1):
    return f"{x:.{nd}f}".replace(".", ",")


def panel(ax, key, title, title_color):
    vals = {g: float(r[key]) / 1000 for g, r in rows.items()}
    order = sorted(vals, key=lambda g: -vals[g])
    ypos = list(range(len(order)))[::-1]
    colors = [RED if g == "IS" else (DARK if g == EU else MUTED)
              for g in order]
    ax.barh(ypos, [vals[g] for g in order], height=0.62, color=colors,
            zorder=3)
    for y, g in zip(ypos, order):
        ax.text(vals[g] + 1.2, y, ic(vals[g]), va="center", ha="left",
                fontsize=8.0,
                fontweight="bold" if g in ("IS", EU) else "normal",
                color=RED if g == "IS" else (DARK if g == EU else "0.35"))
    ax.set_yticks(ypos)
    ax.set_yticklabels([rows[g]["name"] for g in order], fontsize=8.8)
    for tick, g in zip(ax.get_yticklabels(), order):
        if g == "IS":
            tick.set_color(RED)
            tick.set_fontweight("bold")
        elif g == EU:
            tick.set_fontweight("bold")
    ax.set_xlim(0, 92)
    ax.xaxis.set_major_locator(mticker.MultipleLocator(20))
    ax.xaxis.set_major_formatter(
        mticker.FuncFormatter(lambda v, _: ic(v, 0)))
    for s in ["top", "right", "left"]:
        ax.spines[s].set_visible(False)
    ax.grid(axis="x", color="0.88", lw=0.8, zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(length=0)
    ax.set_title(title, fontsize=11, fontweight="bold", color=title_color,
                 loc="left", pad=10)
    ax.set_xlabel("þúsundir evra á ári", fontsize=8, color=GREY)
    return vals, order, ypos


fig, (axL, axR) = plt.subplots(1, 2, figsize=(12.6, 9.2))
fig.subplots_adjust(top=0.845, bottom=0.10, left=0.095, right=0.985,
                    wspace=0.42)

panel(axL, "wage_pe_eur_2024", "Í evrum: Ísland í 2. sæti", DARK)
vals, order, ypos = panel(
    axR, "real_wage_pe",
    "Á kassanum (leiðrétt fyrir verðlagi): 12. sæti", RED)

is_y = ypos[order.index("IS")]
eu_y = ypos[order.index(EU)]
axR.annotate("Rétt undir\nmeðaltali ESB",
             xy=(vals["IS"] + 8, is_y), xytext=(88, is_y - 5.5),
             fontsize=9.2, color=RED, va="center", ha="right",
             fontweight="bold",
             arrowprops=dict(arrowstyle="->", color=RED, lw=1.1,
                             connectionstyle="arc3,rad=0.25"))

fig.text(0.035, 0.965, "Sömu laun — tvær gjörólíkar myndir",
         fontsize=14, fontweight="bold", color=DARK, ha="left")
fig.text(0.035, 0.925,
         "Árslaun á hvern launþega árið 2024. Vinstri: í evrum. Hægri: það sem "
         "launin kaupa, þegar tekið er tillit til þess að verðlag á Íslandi er "
         "73% yfir meðaltali ESB.",
         fontsize=9.5, color=GREY, ha="left", va="top")
fig.text(0.035, 0.012,
         "Heimild: Eurostat (nama_10_a10: laun D11; nama_10_a10_e: fjöldi launþega; "
         "prc_ppp_ind: verðlagsvísitala einstaklingsneyslu A01, útgáfa 10.7.2025); "
         "útreikningar höfundar. ESB-ríkin 27 og Ísland.",
         fontsize=6.8, color=GREY, ha="left", va="bottom")

path = os.path.join(MYND, "m17_laun_evrur_kaupmattur.png")
fig.savefig(path, dpi=200)
print("written:", path)
