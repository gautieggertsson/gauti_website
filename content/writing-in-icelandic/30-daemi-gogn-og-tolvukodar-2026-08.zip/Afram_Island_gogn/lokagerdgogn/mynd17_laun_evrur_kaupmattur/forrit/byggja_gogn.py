#!/usr/bin/env python3
"""
Byggir ../gogn/kaupmattur_launthegi_2024.csv úr hráafritunum í ../hra/.

Laun (D11) og heildarlaunakostnaður (D1) á hvern launþega, allt hagkerfið
(NACE TOTAL), 2024, ESB-27 og Ísland:

    laun á launþega (EUR)   = D11 [nama_10_a10, CP_MEUR]
                              / launþegar, innlent hugtak
                                [nama_10_a10_e, SAL_DC, THS_PER]
    leiðrétt fyrir verðlagi = EUR-gildi / (AIC-verðlagsvísitala 2024 / 100)
                                [prc_ppp_ind, A01, PLI_EU27_2020; sama
                                 verðleiðrétting og síða 19 notar sjálf]

Einnig vinnustundir á launþega [THS_HW/THS_PER] til að brúa yfir í
á-vinnustund-mælikvarðann. Eurostat birtir ekki heilsársígildi launa
(nama_10_fte) fyrir Ísland, svo höfðatala launþega er nothæfa hugtakið.
Keyrsla: python3 byggja_gogn.py. Ekkert netsamband.
"""
import csv
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "..", "hra")
OUT = os.path.join(HERE, "..", "gogn")
os.makedirs(OUT, exist_ok=True)

EU = "EU27_2020"
EU_MEMBERS = ["AT", "BE", "BG", "HR", "CY", "CZ", "DE", "DK", "EE", "EL",
              "ES", "FI", "FR", "HU", "IE", "IT", "LT", "LU", "LV", "MT",
              "NL", "PL", "PT", "RO", "SE", "SI", "SK"]
NAMES = {
    "AT": "Austurríki", "BE": "Belgía", "BG": "Búlgaría", "HR": "Króatía",
    "CY": "Kýpur", "CZ": "Tékkland", "DE": "Þýskaland", "DK": "Danmörk",
    "EE": "Eistland", "EL": "Grikkland", "ES": "Spánn", "FI": "Finnland",
    "FR": "Frakkland", "HU": "Ungverjaland", "IE": "Írland", "IT": "Ítalía",
    "LT": "Litháen", "LU": "Lúxemborg", "LV": "Lettland", "MT": "Malta",
    "NL": "Holland", "PL": "Pólland", "PT": "Portúgal", "RO": "Rúmenía",
    "SE": "Svíþjóð", "SI": "Slóvenía", "SK": "Slóvakía", "IS": "Ísland",
    EU: "ESB",
}
GEOS = EU_MEMBERS + ["IS", EU]


def load_jsonstat(fname):
    d = json.load(open(os.path.join(RAW, fname)))
    dims, sizes = d["id"], d["size"]
    cats = [[c for c, _ in sorted(d["dimension"][k]["category"]["index"].items(),
                                  key=lambda x: x[1])] for k in dims]
    out = {}
    for flat, v in d["value"].items():
        flat = int(flat)
        key, rem = [], flat
        for i in range(len(dims) - 1, -1, -1):
            rem, j = divmod(rem, sizes[i])
            key.append(cats[i][j])
        out[tuple(reversed(key))] = v
    return out


def ranks(vals, group):
    ordered = sorted([g for g in group if vals.get(g) is not None],
                     key=lambda g: -vals[g])
    return {g: i + 1 for i, g in enumerate(ordered)}, len(ordered)


wages = load_jsonstat("nama_10_a10_D1_D11_2024.json")   # (freq, unit, nace, na_item, geo, time)
emp = load_jsonstat("nama_10_a10_e_SAL_2024.json")      # (freq, unit, nace, na_item, geo, time)
ppp = load_jsonstat("estat_prc_ppp_ind.json")           # (freq, na_item, ppp_cat, geo, time)


def get(table, **want):
    """Fetch a value irrespective of dimension order (match by key parts)."""
    for key, v in table.items():
        parts = set(key)
        if all(w in parts for w in want.values()):
            return v
    return None


d11 = {g: get(wages, u="CP_MEUR", i="D11", g=g) for g in GEOS}
d1 = {g: get(wages, u="CP_MEUR", i="D1", g=g) for g in GEOS}
n_emp = {g: get(emp, u="THS_PER", i="SAL_DC", g=g) for g in GEOS}
hrs = {g: get(emp, u="THS_HW", i="SAL_DC", g=g) for g in GEOS}
pli = {g: ppp.get(("A", "PLI_EU27_2020", "A01", g, "2024")) for g in GEOS}
pli[EU] = 100.0

wage_pe = {}
comp_pe = {}
real_wage_pe = {}
real_comp_pe = {}
hrs_pe = {}
for g in GEOS:
    if d11.get(g) and n_emp.get(g):
        wage_pe[g] = d11[g] * 1e6 / (n_emp[g] * 1e3)
        comp_pe[g] = d1[g] * 1e6 / (n_emp[g] * 1e3) if d1.get(g) else None
        if pli.get(g):
            real_wage_pe[g] = wage_pe[g] / (pli[g] / 100.0)
            real_comp_pe[g] = (comp_pe[g] / (pli[g] / 100.0)
                               if comp_pe.get(g) else None)
        if hrs.get(g):
            hrs_pe[g] = hrs[g] / n_emp[g]

rank_group = EU_MEMBERS + ["IS"]
r_eur, n = ranks(wage_pe, rank_group)
r_real, _ = ranks(real_wage_pe, rank_group)
r_realc, _ = ranks(real_comp_pe, rank_group)

with open(os.path.join(OUT, "kaupmattur_launthegi_2024.csv"), "w",
          newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["geo", "name", "wage_pe_eur_2024", "rank_eur",
                "pli_aic_2024", "real_wage_pe", "rank_real",
                "comp_pe_eur_2024", "real_comp_pe", "rank_real_comp",
                "hours_per_employee_2024"])
    for g in sorted([g for g in GEOS if wage_pe.get(g)],
                    key=lambda g: -wage_pe[g]):
        w.writerow([g, NAMES[g], round(wage_pe[g]),
                    r_eur.get(g, ""), pli.get(g, ""),
                    round(real_wage_pe[g]) if real_wage_pe.get(g) else "",
                    r_real.get(g, ""),
                    round(comp_pe[g]) if comp_pe.get(g) else "",
                    round(real_comp_pe[g]) if real_comp_pe.get(g) else "",
                    r_realc.get(g, ""),
                    round(hrs_pe[g]) if hrs_pe.get(g) else ""])

iw, ie = wage_pe["IS"], wage_pe[EU]
rw, re_ = real_wage_pe["IS"], real_wage_pe[EU]
print(f"Laun (D11) á launþega 2024, EUR:  Ísland {iw:,.0f}  ESB {ie:,.0f}  "
      f"index {100*iw/ie:.1f}  sæti {r_eur['IS']} af {n}")
print(f"  leiðrétt fyrir verðlagi (AIC): Ísland {rw:,.0f}  ESB {re_:,.0f}  "
      f"index {100*rw/re_:.1f}  sæti {r_real['IS']} af {n}")
if real_comp_pe.get("IS"):
    rc, rce = real_comp_pe["IS"], real_comp_pe[EU]
    print(f"  heildarlaunakostnaður (D1) raunvirði: index {100*rc/rce:.1f}  "
          f"sæti {r_realc['IS']} af {n}")
print(f"Vinnustundir á launþega 2024:  Ísland {hrs_pe['IS']:.0f}  "
      f"ESB {hrs_pe[EU]:.0f}  (+{100*(hrs_pe['IS']/hrs_pe[EU]-1):.1f}%)")
