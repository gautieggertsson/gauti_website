#!/usr/bin/env python3
"""
Byggir ../gogn/radstofunartekjur_radir.csv úr hráafritunum í ../hra/.

Raðirnar: leiðréttar vergar ráðstöfunartekjur heimila og félagasamtaka sem
þjóna heimilum (B7G), raunvirði á mann, Eurostat nasa_10_ki, vísir
B7G_R_HAB_2010, geiri S14_S15, rétt dagsettar, grunnár 2003 = 100, fyrir
Ísland, ESB-27 og Norðurlönd í ESB (Danmörk, Svíþjóð, Finnland; óvegið
meðaltal vísitalnanna þriggja, auk mannfjöldavegins afbrigðis með
mannfjölda 2003 úr nama_10_pe). Að auki vergar ráðstöfunartekjur (B6G) geira
S.14 á mann á Íslandi, staðvirtar með vísitölu neysluverðs (Hagstofa Íslands
THJ06021, THJ01000 og VIS01005).

SHA-256 gátsummur hráafritanna eru skrifaðar í ../lysigogn/gatsummur_hra.csv.
Keyrsla: python3 byggja_radir.py. Ekkert netsamband.
"""
import csv
import hashlib
import json
import os


HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RAW = os.path.join(ROOT, "hra")
OUT = os.path.join(ROOT, "gogn")
LYS = os.path.join(ROOT, "lysigogn")
os.makedirs(OUT, exist_ok=True)
os.makedirs(LYS, exist_ok=True)

INPUTS = [
    "eurostat_nasa_10_ki_b7g.json",
    "eurostat_nama_10_pe_pop.json",
    "hagstofa_THJ06021_sectors.json",
    "hagstofa_THJ01000_population.json",
    "hagstofa_VIS01005_cpi.json",
]
with open(os.path.join(LYS, "gatsummur_hra.csv"), "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["file", "sha256"])
    for f in INPUTS:
        w.writerow([f, hashlib.sha256(
            open(os.path.join(RAW, f), "rb").read()).hexdigest()])


def jsonstat_records(path):
    """json-stat2 -> list of dicts {dim: category_code, 'value': float}."""
    d = json.load(open(os.path.join(RAW, path)))
    dims, sizes = d["id"], d["size"]
    cats = {}
    for dim in dims:
        idx = d["dimension"][dim]["category"]["index"]
        if isinstance(idx, dict):
            cats[dim] = [k for k, _ in sorted(idx.items(), key=lambda kv: kv[1])]
        else:
            cats[dim] = idx
    vals = d["value"]
    if isinstance(vals, list):
        vals = {str(i): v for i, v in enumerate(vals) if v is not None}
    rows = []
    for flat, val in vals.items():
        rem, coords = int(flat), []
        for i in range(len(dims) - 1, -1, -1):
            coords.append(rem % sizes[i])
            rem //= sizes[i]
        coords = coords[::-1]
        rows.append({dim: cats[dim][c] for dim, c in zip(dims, coords)}
                    | {"value": float(val)})
    return rows


# ---- Eurostat B7G, raunvirði á mann, S14+S15 (röðin sem síðan teiknar)
b7 = {}
for r in jsonstat_records("eurostat_nasa_10_ki_b7g.json"):
    if r["na_item"] == "B7G_R_HAB_2010" and r["sector"] == "S14_S15":
        b7.setdefault(r["geo"], {})[int(r["time"])] = r["value"]

BASE = 2003


def rebase(series):
    return {y: v / series[BASE] * 100.0 for y, v in sorted(series.items())
            if y >= BASE}


isl = rebase(b7["IS"])
eu = rebase(b7["EU27_2020"])

NORDIC3 = ["DK", "SE", "FI"]
nordic_idx = {g: rebase(b7[g]) for g in NORDIC3}
nordic_years = sorted(set.intersection(*(set(v) for v in nordic_idx.values())))
nordic = {y: sum(nordic_idx[g][y] for g in NORDIC3) / 3 for y in nordic_years}

# mannfjöldavegið afbrigði til þolprófunar (fastar vogir 2003, Eurostat POP_NC)
espop = {}
for r in jsonstat_records("eurostat_nama_10_pe_pop.json"):
    if r["na_item"] == "POP_NC" and r["unit"] == "THS_PER":
        espop.setdefault(r["geo"], {})[int(r["time"])] = r["value"]
w03 = {g: espop[g][2003] for g in NORDIC3}
wsum = sum(w03.values())
nordic_pw = {y: sum(nordic_idx[g][y] * w03[g] for g in NORDIC3) / wsum
             for y in nordic_years}

# ---- Ísland B6G (hugtakið sem undirtitill síðunnar nefnir): S.14, VNV, á mann
b6 = {int(r["Ár"]): r["value"]
      for r in jsonstat_records("hagstofa_THJ06021_sectors.json")
      if r["Geiri"] == "S.14" and r["Skipting"] == "100"}
pop = {int(r["Ár"]): r["value"]
       for r in jsonstat_records("hagstofa_THJ01000_population.json")
       if r["Skipting"] == "4"}
cpi = {int(r["Year"]): r["value"]
       for r in jsonstat_records("hagstofa_VIS01005_cpi.json")
       if r["Index"] == "CPI" and r["Base"] == "B1988"}
b6_years = sorted(set(b6) & set(pop) & set(cpi))
b6_real_pc = {y: b6[y] / cpi[y] / pop[y] for y in b6_years if y >= BASE}
b6_idx = rebase(b6_real_pc)

# ---- niðurstöðutafla og staðfesting lykilgilda
with open(os.path.join(OUT, "radstofunartekjur_radir.csv"), "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["year", "island_B7G", "esb_B7G", "nordurlond_DK_SE_FI_B7G",
                "nordurlond_DK_SE_FI_B7G_popweighted",
                "island_B6G_S14_CPI"])
    for y in range(BASE, 2026):
        w.writerow([y] + [round(s[y], 2) if y in s else ""
                          for s in (isl, eu, nordic, nordic_pw, b6_idx)])

end = {n: (max(s), s[max(s)]) for n, s in
       [("Ísland B7G", isl), ("ESB B7G", eu), ("Norðurlönd B7G", nordic),
        ("Norðurlönd B7G pw", nordic_pw), ("Ísland B6G/CPI", b6_idx)]}
for n, (y, v) in end.items():
    print(f"{n}: {BASE}->{y} = {v - 100:+.1f}%  (index {v:.2f})")

assert abs(isl[2024] - 136.28) < 0.05, "Ísland 2024 víkur frá 136,28"
assert abs(eu[2025] - 125.52) < 0.05, "ESB 2025 víkur frá 125,52"
print("Lykilgildi staðfest (Ísland 2024 = 136,28; ESB 2025 = 125,52)")
