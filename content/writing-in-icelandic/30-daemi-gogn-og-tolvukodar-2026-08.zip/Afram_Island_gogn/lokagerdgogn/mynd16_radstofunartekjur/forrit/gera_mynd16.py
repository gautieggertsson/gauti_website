"""Mynd m16_radstofunartekjur: kaupmáttur ráðstöfunartekna heimila á mann,
sömu rétt dagsettu Eurostat-gögnin (nasa_10_ki, B7G_R_HAB_2010, S14_S15) með
tveimur grunnárum, 2003 (grunnár myndar Áfram Íslands) og 2007 (síðasta árið
fyrir hrun). Norðurlönd í ESB eru óvegið meðaltal Danmerkur, Svíþjóðar og
Finnlands.

Gögn: ../gogn/radstofunartekjur_radir.csv (byggð úr hráafritunum í ../hra/
með byggja_radir.py). Ekkert netsamband.
Keyrsla: python3 gera_mynd16.py; myndin skrifast í ../mynd/.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
df = pd.read_csv(BASE / "gogn" / "radstofunartekjur_radir.csv", index_col=0)
(BASE / "mynd").mkdir(exist_ok=True)

BLUE, RED, ORANGE = "#1f4e96", "#d62728", "#f28e2b"
SERIES = [("Ísland", "island_B7G", BLUE),
          ("Norðurlöndin í ESB (DK+SE+FI)", "nordurlond_DK_SE_FI_B7G", RED),
          ("ESB", "esb_B7G", ORANGE)]

plt.rcParams.update({"figure.dpi": 200, "font.size": 13})
fig, axes = plt.subplots(1, 2, figsize=(11.6, 5.2))

for ax, base, subtitle in [
        (axes[0], 2003, "Grunnár 2003 = 100\n(grunnár myndar Kontext)"),
        (axes[1], 2007, "Grunnár 2007 = 100\n(síðasta árið fyrir hrun)")]:
    for name, col, colr in SERIES:
        s = df[col].div(df[col].loc[base]).mul(100).dropna().loc[base:]
        ax.plot(s.index, s, color=colr, lw=2.3,
                label=name if base == 2003 else None)
        last = s.index[-1]
        dy = 0
        if base == 2003 and col == "esb_B7G":
            dy = -12
        if base == 2007 and col == "nordurlond_DK_SE_FI_B7G":
            dy = -13
        ax.annotate(f"{s[last]-100:+.0f}%", (last, s[last]),
                    textcoords="offset points", xytext=(5, dy),
                    color=colr, fontsize=12.5, fontweight="bold")
    ax.axhline(100, color="grey", lw=0.9)
    ax.set_title(subtitle, fontsize=12.5)
    ax.grid(alpha=0.3)
    ax.set_xticks(range(base, 2026, 4 if base == 2003 else 3))
    ax.set_xlim(base, 2028.3)
    lo, hi = ax.get_ylim()
    ax.set_ylim(lo, hi + 4)

axes[0].legend(fontsize=10.5, loc="upper left")
fig.suptitle("Kaupmáttur ráðstöfunartekna heimila á mann: sömu gögn, tvö grunnár",
             fontsize=15, y=0.99)
fig.tight_layout(rect=(0, 0.085, 1, 0.94))
fig.text(0.01, 0.012,
         "Heimild: Eurostat (nasa_10_ki, B7G_R_HAB_2010: kaupmáttur leiðréttra vergra ráðstöfunartekna heimila og félagasamtaka á mann), rétt dagsett.\n"
         "Á mynd Kontext eru gögnin hliðruð um eitt ár (grunnár í reynd 2002), sem sýnir +40% fyrir Ísland í stað +36%; boðuð 2025-áætlun Hagstofu er ekki í birtu gögnunum.\n"
         "Gögn Íslands enda 2024, ESB og Norðurlanda 2025. Norðurlöndin: óvegið meðaltal DK, SE og FI (Noregur, sem er utan ESB, undanskilinn).",
         fontsize=8, color="#666666", va="bottom")
fig.savefig(BASE / "mynd" / "m16_radstofunartekjur.png")
print("Mynd skrifuð:", BASE / "mynd" / "m16_radstofunartekjur.png")
