# Manifest: vaxtamyndirnar þrjár

Einingin teiknar stýrivaxtabrú Íslands og evrusvæðisins (`styrivextir_bru`),
íbúðalánasamanburð Íslands og 27 ríkja ESB (`ibudalan_esb`, birt sem
`m8_vextir` í greininni) og 60 m.kr. heimilisdæmið (`heimili_60m`).
Íbúðalánamyndin notar landsspá hvers ríkis til að mæla vænta raunbyrði
heimila. Grunnmat Eggertssonar (2026a), með sameiginlegri evrusvæðisspá fyrir
evruríkin, er varðveitt samhliða í gagnaskrá, vinnubók og sannprófun.

## Framleiðslukeðja

1. Vinnubókin `gogn/vaxtamyndir_frosin.xlsx` var byggð úr þremur frosnum
   CSV-skrám í `gogn/` (heimildar- og formúlublöð).
2. `forrit/gera_vaxtamyndir.m` les eingöngu vinnubókina, endurreiknar
   Fisher-raunvexti og jafngreiðslur og skrifar PDF og PNG í `mynd/`.
3. Sama MATLAB-keyrsla skrifar tvær sannprófunartöflur í `nidurstodur/`.
4. Vinnubókin var skönnuð fyrir `#REF!`, `#DIV/0!`, `#VALUE!`, `#NAME?`
   og `#N/A`; engin formúluvilla fannst (`nidurstodur/vaxtamyndir_frosin.errors.ndjson`).

Endurgerð myndanna er án nettengingar.

## Lykiltölur

| Stærð | Ónámundað gildi |
|---|---:|
| Raunstýrivextir Íslands | 3,705486% |
| Raunstýrivextir evrusvæðisins | 0,048924% |
| Raunvextir íslenska 9,19% íbúðalánsins | 5,497585% |
| Beinir raunvextir verðtryggða íslenska lánsins | 4,500000% |
| Bil evruríkja, landsspá hvers ríkis | −0,918762% til 1,243926% |
| Hæsta ESB-gildi, landsspá (Ungverjaland) | 3,383422% |
| Raunvaxtaviðmið evrusvæðisins | 0,769605% |
| Jafngild greiðsla við 4,5% | 333,499 þús.kr. |
| Jafngild greiðsla við 0,77% | 219,931 þús.kr. |
| Munur greiðslna | 113,568 þús.kr. |

## Frosnar frumheimildir (SHA-256)

```text
884aaedd45796c0381efe39b49761bb645cd57e8bb7776fcad68080ec61707ab  hra/ecb_key_rates_2026-07-20.html
af7fb37aed6c45ddb167203781a9f60c2afbda85289f45fd1cc0e50a2a9362f7  hra/eggertsson_2026_data_grein.csv
e9ed9b8d344acb9f9d8386629f7b6d60fa3c0fff172b5c76ef5e97338cdb2d3b  hra/eggertsson_2026_grein.pdf
b0ab45d6de01d2450ac935376a5377416c95de43548e26b6b963de99f8045d4b  hra/si_meginvextir_2026-05-20.html
0c9919c1489ba355dded9c3561b0084b0d7f8fd7eb4ddeb435d18081375c18f3  hra/si_stadfesting_2026-07-16.html
7e561c850388b353ae5333af3858801a306dd207ff91c59ff971b4d9b04aa42b  hra/si_vaentingakonnun_2026-05-13.html
```

Könnun Seðlabanka Evrópu meðal greiningaraðila, júní 2026
(`ecb.smar260615_june.en.pdf`, sjá Viðauka A greinarinnar), fylgir ekki
pakkanum vegna höfundarréttar. Eintakið sem notað var hefur gátsummuna
`62d71c0fe8051c7db2e1e9fa10d508562aa437829f3796602bc4009235bdedc0`.

## Inntak, vinnubók og forrit (SHA-256)

```text
0225d779235963a3f61c2a2115996a90cf20e1e5c9ed9be2ce8fe86d8adfb89d  gogn/heimili_60m.csv
59266a90432f5e7b1aa0b5831ec4d0071cc4d5e629acf1a93627f77726e8e8e6  gogn/ibudalan.csv
ab0bd88954be23cc2ceee1a4c37fc2e01e1976d5e825d1f287a5b487b3e8c07d  gogn/styrivextir_bru.csv
a3b27c0d256e7be6a9474ea48ff6a3776bf53ba54fd82d74e0b4646cec70b974  gogn/vaxtamyndir_frosin.xlsx
295243b358940e4c6a5171331c67469ad84b7503af2b06a4b7a332e056b00ee8  forrit/gera_vaxtamyndir.m
```

## Sannprófun (SHA-256)

```text
124948cc2cc54545600ca698a7ff102c4771014dc3e4258e0dee647b289b3c45  nidurstodur/sannprofun_ibudalan.csv
a05c809cdf77ed3a1e02c491356606aa6f5850386f901e9679c709f9c70541f7  nidurstodur/sannprofun_talna.csv
acc0111e19cf44d2753fc9ecd164bf1b27fbd65597463a25cf48bd1c65e90146  nidurstodur/vaxtamyndir_frosin.errors.ndjson
```

Birtu myndirnar þrjár eru í `myndir/` í rót pakkans; gátsummur þeirra eru í
`GATSUMMUR_SHA256.txt` þar.
