#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Python-útgáfa af gera_vaxtamyndir.m (íbúðalánamynd og stýrivaxtabrú) úr sömu frystu
gögnum (gogn/ibudalan.csv, gogn/styrivextir_bru.csv). Hægri hluti íbúðalánamyndarinnar
sýnir grunnmatið: verðbólguspá evrusvæðisins fyrir evruríkin, spá hvers lands fyrir ríki
með eigin mynt. Úttak: ../mynd/ibudalan_esb.{pdf,png}, ../mynd/styrivextir_bru.{pdf,png}."""
import csv, math
from pathlib import Path
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/"mynd"; OUT.mkdir(exist_ok=True)
BLUE=(54/255,112/255,178/255); LBLUE=(93/255,151/255,211/255); RED=(205/255,67/255,54/255)
GRAY=(184/255,184/255,179/255); INK=(31/255,41/255,55/255); MUTED=(100/255,107/255,116/255)
plt.rcParams["font.family"]="Helvetica"; plt.rcParams["axes.unicode_minus"]=False
def pct(v,d): return f"{v:.{d}f}%".replace(".",",")
def real(nv,pi): return ((1+nv/100)/(1+pi/100)-1)*100

# ---------- íbúðalán ----------
rows=list(csv.DictReader(open(ROOT/"gogn"/"ibudalan.csv",encoding="utf-8")))
f=lambda r,k: float(r[k]) if r[k] not in ("","NaN") else math.nan
for r in rows:
    r["nv"]=f(r,"nafnvextir_pct"); r["piL"]=f(r,"vaent_land_pct"); r["piG"]=f(r,"vaent_grunnmat_pct"); r["beint"]=f(r,"beinir_raunvextir_pct")
    r["rvL"]=r["beint"] if not math.isnan(r["beint"]) else real(r["nv"],r["piL"])
    r["rvG"]=r["beint"] if not math.isnan(r["beint"]) else real(r["nv"],r["piG"])
    r["esb"]=r["esb27"]=="1"; r["ice"]=r["land"].startswith("Ísland"); r["indexed"]=r["lanategund"].startswith("Verðtryggt")
bench=[r for r in rows if r["land"]=="Evrusvæði (viðmið)"]; assert len(bench)==1; bench=bench[0]
euro=[r for r in rows if r["esb"] and r["gjaldmidill"]=="EUR"]; own=[r for r in rows if r["esb"] and r["gjaldmidill"]!="EUR"]
assert sum(abs(r["piL"]-r["piG"])>1e-12 for r in euro)==20 and all(abs(r["piL"]-r["piG"])<1e-12 for r in own)
N=[r for r in rows if r["esb"] or (r["ice"] and not r["indexed"])]
Rr=[r for r in rows if r["esb"] or r["ice"]]
# gagnaskráin raðar eftir landsspá; það stemmir (sannprófun), myndin raðar eftir grunnmati
assert [x["land"] for x in sorted(Rr,key=lambda r:int(r["rod_raun_landsspa"]))]==[x["land"] for x in sorted(Rr,key=lambda r:-r["rvL"])]
N=sorted(N,key=lambda r:int(r["rod_nafn"]))[::-1]          # lægstu vextir efst
Rs=sorted(Rr,key=lambda r:-r["rvG"])[::-1]                  # lægstu raunvextir efst
assert abs(bench["rvL"]-0.7696)<1e-3 and abs(bench["nv"]-3.44)<1e-9
nm=lambda s: s.replace("Ísland óverðtr.","Ísland, óverðtr.").replace("Ísland verðtr.","Ísland, verðtr.")
def ranked_bar(ax,labels,vals,colors,limits,benchmark,blabel):
    y=list(range(1,len(vals)+1))
    ax.barh(y,vals,height=0.68,color=colors,zorder=3)
    ax.invert_yaxis(); ax.set_yticks(y); ax.set_yticklabels([f"{i}. {l}" for i,l in zip(y,labels)],fontsize=7.15,color=INK)
    ax.set_xlim(limits); ax.tick_params(length=0,labelsize=7.15); ax.tick_params(axis="x",colors=MUTED)
    ax.grid(axis="x",color=(0.93,0.93,0.93),zorder=0); ax.set_axisbelow(True)
    for s in ("top","right","left"): ax.spines[s].set_visible(False)
    ax.spines["bottom"].set_color(MUTED); ax.set_xlabel("Prósent",color=MUTED,fontsize=8)
    ax.axvline(benchmark,ls="--",lw=0.8,color=(0.35,0.35,0.35),zorder=2)
    ax.text(benchmark+0.04,-0.25,blabel,fontsize=6.8,color=MUTED,ha="left",va="center")
    xr=limits[1]-limits[0]
    for yi,v,c in zip(y,vals,colors):
        xp=v+0.014*xr if v>=0 else 0.06
        ax.text(xp,yi,pct(v,2),fontsize=6.7,color=c,ha="left",va="center")
    ax.set_ylim(len(vals)+0.65,-0.75)
fig=plt.figure(figsize=(11.7,8.0)); fig.patch.set_facecolor("white")
ax1=fig.add_axes([0.115,0.165,0.34,0.70]); ax2=fig.add_axes([0.62,0.165,0.34,0.70])
labN=[nm(r["land"]) for r in N]; valN=[r["nv"] for r in N]; colN=[RED if r["ice"] else GRAY for r in N]
ranked_bar(ax1,labN,valN,colN,(0,10.2),bench["nv"],"Evrusvæðið: "+pct(bench["nv"],2))
ax1.set_title("Nafnvextir nýrra íbúðalána",loc="left",fontsize=11.5,fontweight="bold",color=INK,pad=22)
ax1.text(0,1.012,"Ísland: mars 2026; ESB-ríki: apríl 2026",transform=ax1.transAxes,fontsize=8.2,color=MUTED,va="bottom")
labR=[nm(r["land"]) for r in Rs]; valR=[r["rvG"] for r in Rs]; colR=[RED if r["ice"] else LBLUE for r in Rs]
ranked_bar(ax2,labR,valR,colR,(-1.05,6.25),bench["rvG"],"Evrusvæðið: "+pct(bench["rvG"],1))
ax2.set_title("Áætlaðir raunvextir nýrra íbúðalána",loc="left",fontsize=11.5,fontweight="bold",color=INK,pad=22)
ax2.text(0,1.012,"Miðað við verðbólguspá evrusvæðisins; spá hvers lands fyrir ríki með eigin mynt",transform=ax2.transAxes,fontsize=8.2,color=MUTED,va="bottom")
fig.text(0.045,0.955,"Ný íbúðalán: Ísland og ríki ESB",fontsize=15.5,fontweight="bold",color=INK,va="top")
fig.text(0.045,0.085,"Raunvextir óverðtryggðra lána miðast við 2,65% verðbólguspá evrusvæðisins fyrir evruríkin og spá hvers lands fyrir ríki með eigin mynt; "
         "verðtryggt íslenskt lán er beint raunvaxtaviðmið.\nBrotalínan sýnir 0,8% viðmið evrusvæðisins. Raunvextir miðað við spá hvers lands og við 2% verðbólgumarkmið: "
         "Eggertsson (2026), töflur 2 og 3. Myndin sýnir núverandi kjör, ekki spá um kjör eftir aðild.",fontsize=7.4,color=MUTED,va="top",linespacing=1.4)
fig.savefig(OUT/"ibudalan_esb.pdf"); fig.savefig(OUT/"ibudalan_esb.png",dpi=240); plt.close(fig)
print("íbúðalán: efstu raunvextir",[(l,round(v,2)) for l,v in zip(labR[::-1][:6],valR[::-1][:6])])

# ---------- stýrivaxtabrú ----------
b=list(csv.DictReader(open(ROOT/"gogn"/"styrivextir_bru.csv",encoding="utf-8")))
sv=[r["svadi"] for r in b]; nafn=[float(r["nafnvextir_pct"]) for r in b]; vaent=[float(r["vaent_verdbolga_pct"]) for r in b]
raun=[real(n,v) for n,v in zip(nafn,vaent)]; assert abs(raun[0]-3.7055)<1e-3 and abs(raun[1]-0.0489)<1e-3
def two_bar(ax,labels,vals,colors,limits):
    y=[1,2]; ax.barh(y,vals,height=0.56,color=colors,zorder=3); ax.invert_yaxis()
    ax.set_yticks(y); ax.set_yticklabels(labels,fontsize=10,color=INK); ax.set_xlim(limits)
    ax.tick_params(length=0); ax.tick_params(axis="x",colors=MUTED,labelsize=10)
    ax.grid(axis="x",color=(0.93,0.93,0.93),zorder=0); ax.set_axisbelow(True)
    for s in ("top","right","left"): ax.spines[s].set_visible(False)
    ax.spines["bottom"].set_color(MUTED); ax.set_xlabel("Prósent",color=MUTED,fontsize=9)
    for yi,v,c in zip(y,vals,colors): ax.text(v+0.09,yi,pct(v,2),fontsize=10,fontweight="bold",color=c,va="center")
fig=plt.figure(figsize=(9.6,4.4)); fig.patch.set_facecolor("white")
a1=fig.add_axes([0.16,0.27,0.33,0.46]); a2=fig.add_axes([0.63,0.27,0.33,0.46])
two_bar(a1,sv,nafn,[RED,BLUE],(0,8.8)); a1.set_title("Nafnstýrivextir",loc="left",fontsize=12,fontweight="bold",color=INK,pad=14)
a1.text(0,1.03,"Staða 20. júlí 2026",transform=a1.transAxes,fontsize=8.5,color=MUTED,va="bottom")
two_bar(a2,sv,raun,[RED,BLUE],(0,4.3)); a2.set_title("Áætlaðir raunstýrivextir",loc="left",fontsize=12,fontweight="bold",color=INK,pad=14)
a2.text(0,1.03,"Miðað við vænta verðbólgu eftir um eitt ár",transform=a2.transAxes,fontsize=8.5,color=MUTED,va="bottom")
fig.text(0.055,0.96,"Stýrivextir: nafnvextir segja aðeins hluta sögunnar",fontsize=16,fontweight="bold",color=INK,va="top")
fig.text(0.055,0.885,"Ísland og evrusvæðið",fontsize=9.5,color=MUTED,va="top")
fig.text(0.055,0.10,"Raunvextir eru reiknaðir með Fisher-sambandi. Stýrivextir lýsa aðhaldi peningastefnunnar, ekki þeim vöxtum sem heimili greiða.\nHeimildir: Seðlabanki Íslands og Seðlabanki Evrópu.",fontsize=8.1,color=MUTED,va="top",linespacing=1.4)
fig.savefig(OUT/"styrivextir_bru.pdf"); fig.savefig(OUT/"styrivextir_bru.png",dpi=240); plt.close(fig)
print("brú OK")
