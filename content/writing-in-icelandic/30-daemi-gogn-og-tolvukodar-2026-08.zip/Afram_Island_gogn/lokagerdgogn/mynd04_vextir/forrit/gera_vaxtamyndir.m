function gera_vaxtamyndir()
% GERA_VAXTAMYNDIR
% Teiknar vaxtamyndir greinarinnar þrjár: styrivextir_bru, ibudalan_esb
% (m8_vextir í greininni) og heimili_60m. Öll tölugildi eru lesin úr frystu
% Excel-vinnubókinni ../gogn/vaxtamyndir_frosin.xlsx; engin gögn eru harðkóðuð
% í myndakóðanum. Úttak fer eingöngu í ../mynd og ../nidurstodur.
% Keyrsla frá rót pakkans:
%   matlab -batch "run('lokagerdgogn/mynd04_vextir/forrit/gera_vaxtamyndir.m')"

    close all;
    set(groot, 'defaultTextInterpreter', 'none');
    set(groot, 'defaultAxesTickLabelInterpreter', 'none');
    set(groot, 'defaultLegendInterpreter', 'none');

    scriptDir = fileparts(mfilename('fullpath'));
    rootDir   = fileparts(scriptDir);
    dataFile = fullfile(rootDir, 'gogn', 'vaxtamyndir_frosin.xlsx');
    outDir   = fullfile(rootDir, 'mynd');
    resultDir = fullfile(rootDir, 'nidurstodur');
    if ~exist(outDir, 'dir'); mkdir(outDir); end
    if ~exist(resultDir, 'dir'); mkdir(resultDir); end

    assert(isfile(dataFile), 'Frysta vinnubókin fannst ekki: %s', dataFile);

    BLUE  = [54 112 178] / 255;
    LBLUE = [93 151 211] / 255;
    RED   = [205 67 54] / 255;
    GRAY  = [184 184 179] / 255;
    GREEN = [94 156 123] / 255;
    WINE  = [178 58 72] / 255;
    INK   = [31 41 55] / 255;
    MUTED = [100 107 116] / 255;

    %% 1. Brú: stýrivextir á Íslandi og evrusvæðinu
    p = readcell(dataFile, 'Sheet', 'Styrivextir_hragogn');
    sv = string(p(2:3, 1));
    nafn = cell2num(p(2:3, 2));
    vaent = cell2num(p(2:3, 3));
    raun = ((1 + nafn / 100) ./ (1 + vaent / 100) - 1) * 100;

    f = figure('Color', 'w', 'Units', 'inches', 'Position', [1 1 9.6 4.4]);
    tl = tiledlayout(f, 1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    tl.OuterPosition = [0.055 0.17 0.89 0.60];

    ax1 = nexttile(tl, 1);
    simple_two_bar(ax1, sv, nafn, [RED; BLUE], [0 8.8], INK, MUTED);
    title(ax1, 'Nafnstýrivextir', 'FontSize', 12, 'FontWeight', 'bold', ...
        'Color', INK, 'HorizontalAlignment', 'left', 'Units', 'normalized', ...
        'Position', [0 1.03 0]);
    text(ax1, 0, 0.28, 'Staða 20. júlí 2026', 'FontSize', 8.5, ...
        'Color', MUTED, 'Clipping', 'off');

    ax2 = nexttile(tl, 2);
    simple_two_bar(ax2, sv, raun, [RED; BLUE], [0 4.3], INK, MUTED);
    title(ax2, 'Áætlaðir raunstýrivextir', 'FontSize', 12, 'FontWeight', 'bold', ...
        'Color', INK, 'HorizontalAlignment', 'left', 'Units', 'normalized', ...
        'Position', [0 1.03 0]);
    text(ax2, 0, 0.28, 'Miðað við vænta verðbólgu eftir um eitt ár', ...
        'FontSize', 8.5, 'Color', MUTED, 'Clipping', 'off');

    annotation(f, 'textbox', [0.055 0.92 0.89 0.06], ...
        'String', 'Stýrivextir: nafnvextir segja aðeins hluta sögunnar', ...
        'FontSize', 16, 'FontWeight', 'bold', 'Color', INK, ...
        'EdgeColor', 'none', 'VerticalAlignment', 'top');
    annotation(f, 'textbox', [0.055 0.855 0.89 0.045], ...
        'String', 'Ísland og evrusvæðið', ...
        'FontSize', 9.5, 'Color', MUTED, 'EdgeColor', 'none', ...
        'VerticalAlignment', 'top');
    annotation(f, 'textbox', [0.055 0.065 0.89 0.075], ...
        'String', ['Raunvextir eru reiknaðir með Fisher-sambandi. ' ...
        'Stýrivextir lýsa aðhaldi peningastefnunnar, ekki þeim vöxtum sem heimili greiða. ' ...
        'Heimildir: Seðlabanki Íslands og Seðlabanki Evrópu.'], ...
        'FontSize', 8.1, 'Color', MUTED, 'EdgeColor', 'none', ...
        'VerticalAlignment', 'top');
    export_pair(f, outDir, 'styrivextir_bru');
    close(f);

    %% 2. Ný íbúðalán: Ísland og ESB-27
    c = readcell(dataFile, 'Sheet', 'Ibudalan_hragogn');
    rodN = cell2num(c(2:end, 1));
    rodR = cell2num(c(2:end, 2));
    land = string(c(2:end, 3));
    esb  = cell2num(c(2:end, 5));
    teg  = string(c(2:end, 7));
    nv   = cell2num(c(2:end, 8));
    piLand = cell2num(c(2:end, 9));
    rvBeint = cell2num(c(2:end, 10));
    piGrunn = cell2num(c(2:end, 12));

    rvLand = ((1 + nv / 100) ./ (1 + piLand / 100) - 1) * 100;
    rvGrunn = ((1 + nv / 100) ./ (1 + piGrunn / 100) - 1) * 100;
    useDirect = ~isnan(rvBeint);
    rvLand(useDirect) = rvBeint(useDirect);
    rvGrunn(useDirect) = rvBeint(useDirect);

    isBenchmark = land == 'Evrusvæði (viðmið)';
    assert(sum(isBenchmark) == 1, 'Nákvæmlega ein viðmiðunarlína evrusvæðisins þarf að vera í vinnubókinni.');
    benchmarkNominal = nv(isBenchmark);
    benchmarkReal = rvLand(isBenchmark);

    gjaldmidill = string(c(2:end, 6));
    isEuroState = esb == 1 & gjaldmidill == 'EUR';
    isOwnCurrency = esb == 1 & gjaldmidill ~= 'EUR';
    assert(sum(isEuroState & abs(piLand - piGrunn) > 1e-12) == 20, ...
        'Landsspá og grunnmat eiga að vera ólík fyrir 20 evruríki.');
    assert(all(abs(piLand(isOwnCurrency) - piGrunn(isOwnCurrency)) < 1e-12), ...
        'Landsspá og grunnmat eiga að vera eins fyrir ESB-ríki með eigin mynt.');

    isIce = startsWith(land, 'Ísland');
    isIndexed = startsWith(teg, 'Verðtryggt', 'IgnoreCase', true);
    keepN = (esb == 1) | (isIce & ~isIndexed);
    keepR = (esb == 1) | isIce;

    [~, ixN] = sort(rodN(keepN));
    idxN0 = find(keepN); idxN = idxN0(ixN);
    [~, ixR] = sort(rodR(keepR));
    idxR0 = find(keepR); idxR = idxR0(ixR);
    [~, ixRCalc] = sort(rvLand(keepR), 'descend');
    assert(isequal(ixR, ixRCalc), ...
        'Röð raunvaxta í gagnaskrá stemmir ekki við landsspána.');
    % Myndin sýnir grunnmatið: verðbólguspá evrusvæðisins fyrir evruríkin,
    % spá hvers lands fyrir ríki með eigin mynt. Röðin fylgir því grunnmatinu.
    [~, ixG] = sort(rvGrunn(keepR), 'descend');
    idxR = idxR0(ixG);

    % Regla myndanna: besta staðan (lægstu vextir) er efsta súlan.
    idxN = flipud(idxN);
    idxR = flipud(idxR);

    namesN = land(idxN);
    namesR = land(idxR);
    valsN = nv(idxN);
    valsR = rvGrunn(idxR);
    namesN(namesN == 'Ísland óverðtr.') = 'Ísland, óverðtr.';
    namesR(namesR == 'Ísland óverðtr.') = 'Ísland, óverðtr.';
    namesR(namesR == 'Ísland verðtr.') = 'Ísland, verðtr.';

    f = figure('Color', 'w', 'Units', 'inches', 'Position', [1 1 11.7 8.0]);
    tl = tiledlayout(f, 1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    tl.OuterPosition = [0.045 0.115 0.91 0.77];

    ax1 = nexttile(tl, 1);
    colorsN = repmat(GRAY, numel(valsN), 1);
    colorsN(startsWith(namesN, 'Ísland'), :) = repmat(RED, sum(startsWith(namesN, 'Ísland')), 1);
    ranked_bar(ax1, namesN, valsN, colorsN, [0 10.2], benchmarkNominal, ...
        ['Evrusvæðið: ' pct(benchmarkNominal, 2)], INK, MUTED);
    title(ax1, 'Nafnvextir nýrra íbúðalána', 'FontSize', 11.5, ...
        'FontWeight', 'bold', 'Color', INK, 'HorizontalAlignment', 'left', ...
        'Units', 'normalized', 'Position', [0 1.045 0]);
    text(ax1, 0, 1.01, 'Ísland: mars 2026; ESB-ríki: apríl 2026', ...
        'Units', 'normalized', 'FontSize', 8.2, ...
        'Color', MUTED, 'Clipping', 'off');

    ax2 = nexttile(tl, 2);
    colorsR = repmat(LBLUE, numel(valsR), 1);
    colorsR(startsWith(namesR, 'Ísland'), :) = repmat(RED, sum(startsWith(namesR, 'Ísland')), 1);
    ranked_bar(ax2, namesR, valsR, colorsR, [-1.05 6.25], benchmarkReal, ...
        ['Evrusvæðið: ' pct(benchmarkReal, 1)], INK, MUTED);
    title(ax2, 'Áætlaðir raunvextir nýrra íbúðalána', 'FontSize', 11.5, ...
        'FontWeight', 'bold', 'Color', INK, 'HorizontalAlignment', 'left', ...
        'Units', 'normalized', 'Position', [0 1.045 0]);
    text(ax2, 0, 1.01, 'Miðað við verðbólguspá evrusvæðisins; spá hvers lands fyrir ríki með eigin mynt', ...
        'Units', 'normalized', 'FontSize', 8.2, ...
        'Color', MUTED, 'Clipping', 'off');

    annotation(f, 'textbox', [0.045 0.945 0.91 0.045], ...
        'String', 'Ný íbúðalán: Ísland og ríki ESB', ...
        'FontSize', 15.5, 'FontWeight', 'bold', 'Color', INK, ...
        'EdgeColor', 'none', 'VerticalAlignment', 'top');
    annotation(f, 'textbox', [0.045 0.058 0.91 0.05], ...
        'String', ['Raunvextir óverðtryggðra lána miðast við 2,65% verðbólguspá evrusvæðisins fyrir evruríkin ' ...
        'og spá hvers lands fyrir ríki með eigin mynt; verðtryggt íslenskt lán er beint raunvaxtaviðmið. ' ...
        'Brotalínan sýnir 0,8% viðmið evrusvæðisins. Raunvextir miðað við spá hvers lands og við 2% ' ...
        'verðbólgumarkmið: Eggertsson (2026), töflur 2 og 3. Myndin sýnir núverandi kjör, ekki spá um kjör eftir aðild.'], ...
        'FontSize', 7.4, 'Color', MUTED, 'EdgeColor', 'none', ...
        'VerticalAlignment', 'top');
    export_pair(f, outDir, 'ibudalan_esb');
    close(f);

    %% 3. Heimilisdæmi
    h = readcell(dataFile, 'Sheet', 'Heimili_hragogn');
    Pmkr = cell2num(h(2, 2));
    years = cell2num(h(3, 2));
    rIce = cell2num(h(4, 2));
    rEuro = cell2num(h(5, 2));
    n = 12 * years;
    Pth = Pmkr * 1000;

    payIce = annuity_payment(Pth, rIce, n);
    payEuro = annuity_payment(Pth, rEuro, n);
    intIce = Pth * (rIce / 100 / 12);
    intEuro = Pth * (rEuro / 100 / 12);
    prinIce = payIce - intIce;
    prinEuro = payEuro - intEuro;
    diffPay = payIce - payEuro;

    data = [prinIce intIce; prinEuro intEuro];
    xpos = [1 2];
    f = figure('Color', 'w', 'Units', 'inches', 'Position', [1 1 8.4 7.6]);
    ax = axes(f); hold(ax, 'on');
    b = bar(ax, xpos, data, 0.55, 'stacked');
    b(1).FaceColor = GREEN; b(1).EdgeColor = 'w'; b(1).LineWidth = 1;
    b(2).FaceColor = WINE;  b(2).EdgeColor = 'w'; b(2).LineWidth = 1;

    text(ax, 1, prinIce / 2, sprintf('Raunlækkun\nhöfuðstóls\n%d þús.kr.', round(prinIce)), ...
        'Color', 'w', 'FontWeight', 'bold', 'FontSize', 10.5, ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
    text(ax, 1, prinIce + intIce / 2, sprintf('Raunvaxta-\nkostnaður\n%d þús.kr.', round(intIce)), ...
        'Color', 'w', 'FontWeight', 'bold', 'FontSize', 10.5, ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
    text(ax, 2, prinEuro / 2, sprintf('Raunlækkun\nhöfuðstóls\n%d þús.kr.', round(prinEuro)), ...
        'Color', 'w', 'FontWeight', 'bold', 'FontSize', 10.5, ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
    yIntEuro = prinEuro + intEuro / 2;
    plot(ax, [2.28 2.32], [yIntEuro yIntEuro], '-', 'Color', WINE, 'LineWidth', 0.9);
    text(ax, 2.34, yIntEuro, sprintf('Raunvaxtakostnaður: %d þús.kr.', round(intEuro)), ...
        'Color', WINE, 'FontWeight', 'bold', 'FontSize', 9.8, ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle');

    text(ax, 1, payIce + 13, sprintf('%d þús.kr.\ná mánuði', round(payIce)), ...
        'Color', INK, 'FontWeight', 'bold', 'FontSize', 12.2, ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
    text(ax, 2, payEuro + 13, sprintf('%d þús.kr.\ná mánuði', round(payEuro)), ...
        'Color', INK, 'FontWeight', 'bold', 'FontSize', 12.2, ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');

    bx = 2.64;
    plot(ax, [bx bx], [payEuro payIce], '-', 'Color', [0.27 0.27 0.27], 'LineWidth', 1.3);
    plot(ax, [bx - 0.05 bx], [payEuro payEuro], '-', 'Color', [0.27 0.27 0.27], 'LineWidth', 1.3);
    plot(ax, [bx - 0.05 bx], [payIce payIce], '-', 'Color', [0.27 0.27 0.27], 'LineWidth', 1.3);
    text(ax, bx + 0.07, (payEuro + payIce) / 2, ...
        sprintf('Um %d þús.kr.\nlægri jafngild\ngreiðsla', round(diffPay)), ...
        'Color', INK, 'FontWeight', 'bold', 'FontSize', 10.3, ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle');

    set(ax, 'XTick', xpos, 'XTickLabel', ...
        {sprintf('Við %s%% raunvexti', num_is(rIce, 1)), ...
         sprintf('Við %s%% raunvaxtaviðmið', num_is(rEuro, 1))}, ...
        'FontSize', 10.5, 'TickLength', [0 0]);
    xlim(ax, [0.35 3.30]); ylim(ax, [0 payIce * 1.24]);
    ylabel(ax, 'Jafngild föst greiðsla (þús.kr., á verðlagi dagsins)', ...
        'FontSize', 10, 'Color', [0.2 0.2 0.2]);
    ax.YColor = [0.45 0.45 0.45]; ax.XColor = [0.3 0.3 0.3];
    ax.YGrid = 'on'; ax.GridColor = [0.94 0.94 0.94]; ax.GridAlpha = 1;
    ax.Layer = 'bottom'; box(ax, 'off');
    set(ax, 'Position', [0.115 0.205 0.84 0.56]);

    annotation(f, 'textbox', [0.055 0.94 0.90 0.055], ...
        'String', 'Hvað núverandi raunvaxtamunur þýðir fyrir heimili', ...
        'FontSize', 15.2, 'FontWeight', 'bold', 'Color', INK, ...
        'EdgeColor', 'none', 'VerticalAlignment', 'top');
    annotation(f, 'textbox', [0.055 0.885 0.90 0.045], ...
        'String', sprintf(['Jafngild föst mánaðargreiðsla %s m.kr. jafngreiðsluláns ' ...
        'til %d ára, á verðlagi dagsins'], num_is(Pmkr, 0), round(years)), ...
        'FontSize', 9.6, 'Color', MUTED, 'EdgeColor', 'none', ...
        'VerticalAlignment', 'top');
    annotation(f, 'rectangle', [0.060 0.835 0.020 0.014], ...
        'FaceColor', GREEN, 'EdgeColor', 'none');
    annotation(f, 'textbox', [0.087 0.852 0.44 0.022], ...
        'String', 'Raunlækkun höfuðstóls', 'FontSize', 9.2, ...
        'Color', INK, 'EdgeColor', 'none');
    annotation(f, 'rectangle', [0.060 0.808 0.020 0.014], ...
        'FaceColor', WINE, 'EdgeColor', 'none');
    annotation(f, 'textbox', [0.087 0.825 0.44 0.022], ...
        'String', 'Raunvaxtakostnaður', 'FontSize', 9.2, ...
        'Color', INK, 'EdgeColor', 'none');
    annotation(f, 'textbox', [0.055 0.052 0.90 0.085], ...
        'String', ['Reikningsdæmi við óbreytta skuld, lánstíma og greiðsluform. ' ...
        sprintf('%s%% er námunduð framsetning á %s%% viðmiði. ', num_is(rEuro, 1), num_is(rEuro, 2)) ...
        'Myndin er ekki spá um framtíðarkjör. ' ...
        'Heimild og aðferð: Eggertsson (2026).'], ...
        'FontSize', 7.8, 'Color', MUTED, 'EdgeColor', 'none', ...
        'VerticalAlignment', 'top');
    export_pair(f, outDir, 'heimili_60m');
    close(f);

    %% Reikniskrá fyrir óháða tölusannprófun
    check = table(...
        nafn(1), nafn(2), raun(1), raun(2), ...
        nv(isIce & ~isIndexed), rvLand(isIce & ~isIndexed), rvLand(isIce & isIndexed), ...
        payIce, payEuro, diffPay, ...
        'VariableNames', {'SI_styrivextir', 'ECB_DFR', 'SI_raunstyrivextir', ...
        'EA_raunstyrivextir', 'SI_ibudalan_nafnvextir', ...
        'SI_ibudalan_reiknadir_raunvextir', 'SI_ibudalan_beinir_raunvextir', ...
        'Heimili_greidsla_4_5', 'Heimili_greidsla_0_77', 'Heimili_munur'});
    writetable(check, fullfile(resultDir, 'sannprofun_talna.csv'));

    mortgageCheck = table(land, teg, esb, nv, piLand, piGrunn, rvBeint, rvLand, rvGrunn, ...
        'VariableNames', {'Land', 'Lanategund', 'ESB_27', 'Nafnvextir', ...
        'Vaent_verdbolga_landsspa', 'Vaent_verdbolga_grunnmat', ...
        'Beinir_raunvextir', 'Raunvextir_landsspa', 'Raunvextir_grunnmat'});
    writetable(mortgageCheck, fullfile(resultDir, 'sannprofun_ibudalan.csv'));

    fprintf('Vaxtamyndir vistaðar í %s\n', outDir);
end

function x = cell2num(c)
    if ~iscell(c); c = {c}; end
    x = nan(size(c));
    for k = 1:numel(c)
        v = c{k};
        if isnumeric(v) && isscalar(v)
            if ~isempty(v); x(k) = double(v); end
        elseif islogical(v) && isscalar(v)
            x(k) = double(v);
        elseif isstring(v) || ischar(v)
            s = strrep(string(v), ',', '.');
            if strlength(strtrim(s)) > 0
                x(k) = str2double(s);
            end
        end
    end
end

function simple_two_bar(ax, labels, values, colors, limits, ink, muted)
    y = 1:numel(values);
    b = barh(ax, y, values, 0.56, 'FaceColor', 'flat', 'EdgeColor', 'none');
    b.CData = colors;
    ax.YDir = 'reverse';
    ax.YTick = y; ax.YTickLabel = cellstr(labels);
    ax.FontSize = 10; ax.TickLength = [0 0];
    ax.XLim = limits; ax.XGrid = 'on'; ax.GridColor = [0.93 0.93 0.93];
    ax.GridAlpha = 1; ax.Layer = 'bottom'; ax.Box = 'off';
    ax.XColor = muted; ax.YColor = ink;
    xlabel(ax, 'Prósent', 'Color', muted, 'FontSize', 9);
    for k = 1:numel(values)
        text(ax, values(k) + 0.09, y(k), pct(values(k), 2), ...
            'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', ...
            'FontSize', 10, 'FontWeight', 'bold', 'Color', colors(k, :));
    end
end

function ranked_bar(ax, labels, values, colors, limits, benchmark, benchmarkLabel, ink, muted)
    y = (1:numel(values))';
    b = barh(ax, y, values, 0.68, 'FaceColor', 'flat', 'EdgeColor', 'none');
    b.CData = colors;
    ax.YDir = 'reverse';
    ax.YTick = y; ax.YTickLabel = compose('%d. %s', y, labels);
    ax.FontSize = 7.15; ax.TickLength = [0 0];
    ax.XLim = limits; ax.XGrid = 'on'; ax.GridColor = [0.93 0.93 0.93];
    ax.GridAlpha = 1; ax.Layer = 'bottom'; ax.Box = 'off';
    ax.XColor = muted; ax.YColor = ink;
    xlabel(ax, 'Prósent', 'Color', muted, 'FontSize', 8);
    line(ax, [benchmark benchmark], [0.35 numel(values) + 0.65], ...
        'LineStyle', '--', 'LineWidth', 0.8, 'Color', [0.35 0.35 0.35]);
    text(ax, benchmark + 0.04, 0.42, benchmarkLabel, ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom', ...
        'FontSize', 6.8, 'Color', muted);
    xr = diff(limits);
    for k = 1:numel(values)
        if values(k) >= 0
            xp = values(k) + 0.014 * xr;
            ha = 'left';
        else
            % Neikvæða gildið er sett rétt hægra megin við núllásinn svo
            % það rekist ekki á landaheitið vinstra megin við myndflötinn.
            xp = 0.06;
            ha = 'left';
        end
        text(ax, xp, y(k), pct(values(k), 2), ...
            'HorizontalAlignment', ha, 'VerticalAlignment', 'middle', ...
            'FontSize', 6.7, 'Color', colors(k, :));
    end
end

function s = pct(v, decimals)
    fmt = sprintf('%%.%df%%%%', decimals);
    s = strrep(sprintf(fmt, v), '.', ',');
end

function s = num_is(v, decimals)
    fmt = sprintf('%%.%df', decimals);
    s = strrep(sprintf(fmt, v), '.', ',');
end

function p = annuity_payment(principal, annualPct, months)
    rm = annualPct / 100 / 12;
    p = principal * rm / (1 - (1 + rm)^(-months));
end

function export_pair(f, outDir, stem)
    exportgraphics(f, fullfile(outDir, [stem '.pdf']), 'ContentType', 'vector');
    exportgraphics(f, fullfile(outDir, [stem '.png']), 'Resolution', 240);
end
