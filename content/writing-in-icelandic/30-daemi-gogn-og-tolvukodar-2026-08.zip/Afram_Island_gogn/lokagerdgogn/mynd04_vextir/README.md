# Vaxtamyndirnar þrjár

Þessi eining geymir frosin gögn, útreikninga og forrit þriggja mynda í
meginniðurstöðum greinarinnar:

| Mynd í greininni | Efni | Skrá sem einingin skrifar |
|---|---|---|
| `styrivextir_bru.pdf` | Nafn- og raunstýrivextir Íslands og evrusvæðisins | `mynd/styrivextir_bru.pdf` |
| `m8_vextir.pdf` | Nafn- og raunvextir nýrra íbúðalána á Íslandi og í 27 ríkjum ESB | `mynd/ibudalan_esb.pdf` |
| `heimili_60m.pdf` | Jafngild föst greiðsla af 60 m.kr. láni við 4,5% og 0,77% raunvexti | `mynd/heimili_60m.pdf` |

## Endurgerð myndanna

Frá rót pakkans:

```bash
matlab -batch "run('lokagerdgogn/mynd04_vextir/forrit/gera_vaxtamyndir.m')"
```

Keyrslan þarf ekki nettengingu. Hún les eingöngu
`gogn/vaxtamyndir_frosin.xlsx`, endurreiknar allar stærðir og skrifar PDF
og PNG í `mynd/` (verður til við keyrslu) og sannprófunartöflur í
`nidurstodur/`. `forrit/gera_myndir.m` í rót pakkans keyrir sama fall og
afritar úttakið í `endurgerd/` undir heitum greinarinnar.

`forrit/gera_vaxtamyndir_py.py` teiknar íbúðalánamyndina og stýrivaxtabrúna
í Python úr sömu CSV-skrám í `gogn/`, fyrir þá sem hafa ekki MATLAB. Útlitið er
sambærilegt en ekki hið sama og í birtu myndunum, sem koma úr MATLAB-forritinu.

## Möppuskipan

- `hra/`: frosnar frumskrár frá Seðlabanka Íslands, Seðlabanka Evrópu og
  Eggertsson (2026a), sjá gátsummur í `lysigogn/MANIFEST.md`;
- `gogn/`: þrjár CSV-inntaksskrár og frosna Excel-vinnubókin;
- `forrit/gera_vaxtamyndir.m`: endurreiknar tölur og teiknar myndirnar;
- `nidurstodur/`: tölusannprófun og villuleit vinnubókar;
- `lysigogn/`: heimildir, lykiltölur og SHA-256 gátsummur.

Vinnubókin var byggð úr CSV-skránum þremur í `gogn/`; MATLAB-endurgerðin les
vinnubókina beint.

## Gagnaútgáfa og aðferð

Stýrivaxtabrúin notar opinberar tölur sem giltu 20. júlí 2026: 7,75% meginvexti
Seðlabanka Íslands, 3,9% vænta verðbólgu eftir eitt ár, 2,25% innlánsvexti
Seðlabanka Evrópu og 2,2% vænta ársverðbólgu HICP á öðrum ársfjórðungi 2027.
Fisher-raunvextir eru 3,71% og 0,05%.

Íbúðalánamyndin varðveitir gagnaútgáfu Eggertsson (2026a): 9,19% vexti
íslensks óverðtryggðs láns og 3,5% vænta verðbólgu, 4,5% beina raunvexti
verðtryggðs láns og landsspá hvers ESB-ríkis úr vorspá framkvæmdastjórnar
ESB 2026. Landsspáin er meðaltal HICP-spár fyrir 2026 og 2027 og mælir vænta
raunbyrði vaxtagreiðslna heimila í hverju landi. Grunnmat Eggertssonar (2026a)
notar sameiginlega 2,65% evrusvæðisspá fyrir evruríkin; báðar raðir eru
varðveittar í gagnaskránni og gefa sömu heildarmynd.

Nafnvaxtaviðmið evrusvæðisins er 3,44% og raunvaxtaviðmiðið 0,769605%,
reiknað með 2,65% spá evrusvæðisins sem

```text
((1 + 3,44/100) / (1 + 2,65/100) - 1) × 100.
```

Það er reiknað sem 0,77% en birt sem 0,8%. Brotalínan er aðskilið viðmið
evrusvæðisins í heild, ekki verðbólguforsenda landasúlnanna. Samanburðurinn
inniheldur öll 27 ríki ESB og Ísland, en ekki Noreg.
`hra/eggertsson_2026_data_grein.csv` er frysta frumskráin; `gogn/ibudalan.csv`
er afmarkaður útdráttur fyrir myndina og varðveitir bæði `vaent_land_pct` og
`vaent_grunnmat_pct`.

Heimilisdæmið notar sama 0,77% viðmið og 4,5% íslenska raunvexti.
Höfuðstóllinn, 60 m.kr., er um 85% af 70,6 m.kr. viðmiðskaupverði fyrstu
kaupenda árið 2025 hjá Húsnæðis- og mannvirkjastofnun samkvæmt Eggertsson
(2026a). Jafngild föst raungreiðsla til 25 ára er reiknuð með hefðbundinni
jafngreiðsluformúlu. Greiðslurnar eru 333,499 og 219,931 þús.kr. á mánuði og
munurinn 113,568 þús.kr.

Markaðskönnunin 3,9% í stýrivaxtabrúnni og 3,5% forsenda Eggertsson (2026a)
í íbúðalánamyndinni tilheyra ólíkum gagnaútgáfum. Þær eru varðveittar hvor í
sínum útreikningi.

## Sannprófun

`nidurstodur/sannprofun_talna.csv` geymir lykiltölur sem MATLAB reiknar
sjálfstætt úr vinnubókinni. `nidurstodur/sannprofun_ibudalan.csv` geymir
allar línur íbúðalánasamanburðarins og reiknaða raunvexti.
`nidurstodur/vaxtamyndir_frosin.errors.ndjson` staðfestir að engin
Excel-formúluvilla fannst í vinnubókinni. Nákvæmar heimildir og gátsummur
eru í `lysigogn/MANIFEST.md`.
