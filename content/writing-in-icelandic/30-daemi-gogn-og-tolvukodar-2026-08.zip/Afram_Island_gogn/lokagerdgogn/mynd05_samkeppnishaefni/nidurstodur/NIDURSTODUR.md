# Niðurstöður: IMD World Competitiveness Booklet 2025, Ísland

Heimild: *IMD World Competitiveness Booklet 2025* (IMD World Competitiveness
Center, júní 2025), eintakið sem notað var hefur SHA-256 gátsummuna
`fd693b1cc736621de75c976d655246fcc20448e819a39fb9e04df54112c7fe2d` (bókin
sjálf fylgir ekki pakkanum vegna höfundarréttar),
sótt 20. júlí 2026 af
<https://www.imd.org/wp-content/uploads/2025/06/Booklet-WCR-2025-v3.pdf>.
Blaðsíðutal hér er prentað blaðsíðutal skjalsins (samhljóða PDF-síðuvísitölu).

## Sæti Íslands 2025

| Þáttur | Sæti (af 69) | Stig (0–100) | Bls. |
|---|---:|---:|---:|
| **Heildarsæti** | **15.** | 83,49 | 52 |
| Efnahagsleg frammistaða (Economic Performance) | 52. | 45,91 | 60 |
| Skilvirkni hins opinbera (Government Efficiency) | 18. | 68,86 | 61 |
| Skilvirkni atvinnulífs (Business Efficiency) | 10. | 85,43 | 62 |
| Innviðir (Infrastructure) | 12. | 77,86 | 63 |

Krossstaðfest á bls. 64–65 (fimm ára yfirlitstafla "Factor Rankings:
Five-year Overview"): Ísland raðast 21-16-16-17-**15** (heild), 55-56-45-53-**52**
(efnahagsleg frammistaða) á bls. 64, og 17-14-19-17-**18** (opinber skilvirkni),
14-08-10-13-**10** (atvinnulíf), 09-08-07-12-**12** (innviðir) á bls. 65;
öll 2025-gildi samhljóða töflunum á bls. 60–63. Landaprófíll Íslands (bls. 94)
staðfestir sömu heildarsætaþróun (21, 16, 16, 17, 15).

## Vægi þátta og undirþátta (bls. 54–55)

- Röðunin skiptist í **4 megin-þætti** (Economic Performance, Government
  Efficiency, Business Efficiency, Infrastructure), hvern í **5 undirþætti**,
  samtals 20 undirþættir, taldir upp með nafni á bls. 55.
- Bókin fullyrðir berum orðum á bls. 54: "Each sub-factor, independently of
  the number of criteria it contains, has the same weight in the overall
  consolidation of results, that is 5% (20x5=100)."
- Af þessu leiðir stærðfræðilega (ekki bein tilvitnun, heldur útleiðsla úr
  ofangreindu tvennu): hver megin-þáttur vegur **25%** af heildarröðuninni
  (5 undirþættir × 5%).
- Bókin greinir einnig frá vægi gagnagerða, óháð þáttavæginu: hörð gögn
  ("hard data") vega **2/3** og könnunargögn ("survey data") **1/3** af
  heildarröðuninni (bls. 54). 341 viðmið liggja til grundvallar 20
  undirþáttunum, en fjöldi viðmiða á undirþátt er ekki jafn (bls. 54).

## ESB-ríki ofar Íslandi í heildarröðuninni (bls. 52)

Ríkin í sætum 1.–14. (ofar Íslandi í 15. sæti) eru: Sviss, Singapúr,
Hong Kong, **Danmörk**, Sameinuðu arabísku furstadæmin, Taívan, **Írland**,
**Svíþjóð**, Katar, **Holland**, Kanada, Noregur, Bandaríkin, **Finnland**.

Af þessum 14 eru fimm aðildarríki Evrópusambandsins:

| Sæti | Land | Stig |
|---:|---|---:|
| 4. | Danmörk | 97,51 |
| 7. | Írland | 91,31 |
| 8. | Svíþjóð | 90,20 |
| 10. | Holland | 89,75 |
| 14. | Finnland | 83,83 |

(Noregur og Sviss eru ekki í ESB; Singapúr, Hong Kong, SAF, Taívan, Katar,
Kanada og Bandaríkin eru utan Evrópu/ESB.)

## Mynd

`mynd/m5_samkeppnishaefni.pdf` / `.png` (verður til við keyrslu; birt sem
`m9_imd.pdf` í greininni): einfalt fjögurra súlna súlurit með sæti og stigum
Íslands í fjórum meginþáttum, heildarstig sýnt sem viðmiðunarlína. Búið til
með `forrit/gera_mynd05.py` (Python, matplotlib); litakóðar (RED `#C0392B`,
INK `#1A1A1A`, MUT `#6B6B6B`, grid `#E4E4E2`), leturgerð (Helvetica) og
sjónræn uppsetning (feitletruð fyrirsögn efst til vinstri, daufari
undirtexti, engin rammalína, strikalína fyrir viðmiðunartölu) fylgja sama
sjónræna kerfi og MATLAB-myndir greinarinnar.

## Afmörkun

Aðeins IMD World Competitiveness Ranking er skoðað hér. Engir aðrir
samkeppnishæfnismælikvarðar (t.d. WEF, Global Innovation Index) eru teknir
fyrir.
