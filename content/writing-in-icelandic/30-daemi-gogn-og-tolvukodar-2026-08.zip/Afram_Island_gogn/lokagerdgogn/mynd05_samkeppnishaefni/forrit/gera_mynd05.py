"""gera_mynd05.py

Teiknar m9_imd (mynd 9 í greininni): einfalt fjögurra súlna súlurit sem sýnir
sæti Íslands í fjórum meginþáttum IMD World Competitiveness Ranking 2025, með
heildarsæti sem viðmiðunarlínu. Litir, leturgerð (Helvetica) og sjónræn
hlutföll fylgja sama sjónræna kerfi og MATLAB-myndir greinarinnar.

Gögn koma úr ../gogn/mynd05_ranktable.csv, frosinni, tilvitnaðri talnatöku úr
IMD World Competitiveness Booklet 2025 (sjá ../lysigogn/manifest.json fyrir
nákvæmar blaðsíðutilvísanir). Forritið sækir ekkert af netinu.

Keyrsla frá rót pakkans:
    python3 lokagerdgogn/mynd05_samkeppnishaefni/forrit/gera_mynd05.py
Úttak: ../mynd/m5_samkeppnishaefni.pdf og .png (forrit/gera_myndir.m afritar
PDF-skrána sem m9_imd.pdf).
"""

import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(SCRIPT_DIR)
DATA = os.path.join(ROOT, "gogn", "mynd05_ranktable.csv")
OUT = os.path.join(ROOT, "mynd")
os.makedirs(OUT, exist_ok=True)

# Litir og leturgerð eins og í MATLAB-myndum greinarinnar (forrit/gera_myndir.m)
GRAY = (168 / 255, 166 / 255, 158 / 255)
BLUE = (42 / 255, 120 / 255, 214 / 255)
RED = (192 / 255, 57 / 255, 43 / 255)
LIGHTRED = (232 / 255, 170 / 255, 162 / 255)
INK = (26 / 255, 26 / 255, 26 / 255)
MUT = (107 / 255, 107 / 255, 107 / 255)
GRID = (228 / 255, 228 / 255, 226 / 255)

for fname in ("Helvetica", "Arial", "Helvetica Neue"):
    if any(fname.lower() in f.name.lower() for f in fm.fontManager.ttflist):
        plt.rcParams["font.family"] = fname
        break
else:
    plt.rcParams["font.family"] = "sans-serif"

rows = []
with open(DATA, encoding="utf-8") as fh:
    for r in csv.DictReader(fh, delimiter=";"):
        rows.append(r)

overall = next(r for r in rows if r["flokkur"] == "Heildarsæti")
factors = [r for r in rows if r["flokkur"] != "Heildarsæti"]
assert len(factors) == 4, "Vænt nákvæmlega fjórum megin-þáttum."

labels = [r["flokkur"].replace(" ", "\n", 1) for r in factors]
scores = [float(r["stig"]) for r in factors]
ranks = [int(r["saeti"]) for r in factors]
n_total = int(factors[0]["heild_rikja"])

fig, ax = plt.subplots(figsize=(6.2, 5.0), facecolor="white")
fig.subplots_adjust(left=0.11, right=0.80, top=0.78, bottom=0.20)

x = range(len(labels))
colors = [RED if r["flokkur"] == "Efnahagsleg frammistaða" else GRAY for r in factors]
bars = ax.bar(x, ranks, width=0.58, color=colors, edgecolor="none", zorder=3)

# Viðmiðunarlína: heildarsæti Íslands (15. af 69), sbr. bls. 52
overall_rank = int(overall["saeti"])
ax.axhline(overall_rank, linestyle="--", color=INK, linewidth=0.9, alpha=0.7, zorder=2)

for i, (b, rank) in enumerate(zip(bars, ranks)):
    rautt = colors[i] == RED
    ax.text(
        b.get_x() + b.get_width() / 2, rank + 1.4,
        f"{rank}. sæti",
        ha="center", va="bottom", fontsize=9.5, fontweight="bold",
        color=RED if rautt else INK,
        bbox=dict(facecolor="white", edgecolor="none", pad=1.2),
    )

ax.text(
    3.42, 56,
    "Sá meginþáttur sem var felldur út:\n52. sæti af 69",
    fontsize=8.2, fontweight="bold", color=RED, ha="right", va="top", linespacing=1.3,
)
ax.text(
    3.42, 46,
    "Brotalínan sýnir heildarsæti Íslands: 15.;\nfimm ESB-ríki ofar.",
    fontsize=7.4, color=MUT, ha="right", va="top", linespacing=1.3,
)

ax.set_xticks(list(x))
ax.set_xticklabels(labels, fontsize=8.6, color=INK)
ax.set_ylim(0, 69)
ax.set_yticks(range(0, 70, 10))
ax.set_yticklabels([str(v) for v in range(0, 70, 10)], fontsize=7.6, color=MUT)
ax.set_ylabel("Sæti af 69 (lægra sæti er betra)", fontsize=8.0, color=MUT)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.spines["left"].set_visible(False)
ax.spines["bottom"].set_color(MUT)
ax.tick_params(axis="both", length=0)
ax.yaxis.grid(True, color=GRID, linewidth=0.8, zorder=0)
ax.set_axisbelow(True)

fig.text(
    0.11, 0.965,
    "Fjórir meginþættir samkeppnishæfni IMD 2025",
    fontsize=11.3, fontweight="bold", color=INK, ha="left",
)
fig.text(
    0.11, 0.925,
    f"Sæti Íslands af {n_total} ríkjum; lægra sæti er betra",
    fontsize=8.4, color=MUT, ha="left",
)
fig.text(
    0.11, 0.02,
    "Heimild: IMD World Competitiveness Booklet 2025, bls. 52 (heildarsæti), "
    "60-63 (þættir).",
    fontsize=6.6, color=MUT, ha="left",
)

pdf_path = os.path.join(OUT, "m5_samkeppnishaefni.pdf")
png_path = os.path.join(OUT, "m5_samkeppnishaefni.png")
fig.savefig(pdf_path)
fig.savefig(png_path, dpi=240)
plt.close(fig)

print("Mynd 5 skrifuð:")
print(" ", pdf_path)
print(" ", png_path)
for r, rk in zip(labels, ranks):
    print(f"  {r}: {rk}. sæti")
print(f"  Heildarsæti: {overall['saeti']}. af {overall['heild_rikja']} (stig {overall['stig']})")
