function U = afkoda_jsonstat(txt)
%% afkoda_jsonstat.m, JSON-stat 2.0 → löng tafla með dálki fyrir hverja vídd + gildi
% Afkóðar svar Eurostat-API-sins (JSON-stat 2.0) með skýrum skrefareikningi
% (stride) yfir id/size-vigrana: síðasta víddin hleypur hraðast, skref(k) =
% margfeldi stærðanna aftan við k, og flatt sæti gildis er summa hnit(k)*skref(k).
% Naívur lestur (t.d. struct2cell á value-hlutinn) ruglar löndum saman, þess
% vegna er reikningurinn gerður berum orðum hér og prófaður í prof/ProfAfkodari.m.
% Kóðar víddanna eru lesnir beint úr hráa textanum því jsondecode afbakar
% reitanöfn með bandstriki (t.d. Y15-74 → Y15_74).
% Notkun: U = afkoda_jsonstat(fileread(skra, 'Encoding', 'UTF-8'));  (R2024b)

j = jsondecode(txt);
assert(~isfield(j, 'error'), 'Eurostat skilaði villu: %s', txt(1:min(300, end)));
vidd = cellstr(string(j.id));
staerd = double(j.size(:))';
nv = numel(vidd);
assert(numel(staerd) == nv, 'id/size-vigrar ósamkvæmir');
kodar = cell(1, nv);
for k = 1:nv; kodar{k} = vidd_kodar(txt, vidd{k}, staerd(k)); end
skref = fliplr(cumprod([1, fliplr(staerd(2:end))]));   % skref(nv) = 1
N = prod(staerd);
v = NaN(N, 1);
if isstruct(j.value)                       % gisin framsetning: {"flatt sæti": gildi}
    fn = fieldnames(j.value);
    for i = 1:numel(fn)
        fl = sscanf(fn{i}, 'x%d');         % jsondecode: "137" → reitur x137
        assert(isscalar(fl) && fl >= 0 && fl < N, 'gildissæti %s utan marka', fn{i});
        v(fl+1) = j.value.(fn{i});
    end
elseif iscell(j.value)                     % þétt fylki með null-eyðum
    assert(numel(j.value) == N);
    for i = 1:N; if ~isempty(j.value{i}); v(i) = j.value{i}; end; end
else                                       % þétt talnafylki
    assert(numel(j.value) == N);
    v = double(j.value(:));
end
til = find(~isnan(v));
U = table();
eftir = til - 1;
for k = 1:nv
    hnit = floor(eftir ./ skref(k));       % hnit í vídd k, 0-talið
    eftir = eftir - hnit .* skref(k);
    kk = kodar{k}(:);
    U.(vidd{k}) = reshape(string(kk(hnit + 1)), [], 1);
end
U.gildi = v(til);
end

function k = vidd_kodar(txt, nafn, n)
% Kóðalisti víddar í sætisröð, lesinn úr hráa JSON-textanum (index-hluturinn er flatur).
t0 = strfind(txt, '"dimension"');
assert(~isempty(t0), 'fann ekki "dimension" í svarinu');
tok = regexp(txt(t0(1):end), ['"' nafn '"\s*:\s*\{.*?"index"\s*:\s*(\{[^{}]*\}|\[[^\[\]]*\])'], ...
    'tokens', 'once');
assert(~isempty(tok), 'fann ekki vídd %s', nafn);
b = tok{1};
if b(1) == '{'                             % {"kóði": sæti, ...}
    por = regexp(b, '"([^"]+)"\s*:\s*(\d+)', 'tokens');
    k = cell(1, numel(por));
    for i = 1:numel(por); k{str2double(por{i}{2}) + 1} = por{i}{1}; end
else                                       % ["kóði", ...] í sætisröð
    por = regexp(b, '"([^"]*)"', 'tokens');
    k = cellfun(@(c) c{1}, por, 'UniformOutput', false);
end
assert(numel(k) == n && ~any(cellfun(@isempty, k)), ...
    'vídd %s: %d kóðar, vænti %d', nafn, numel(k), n);
end
