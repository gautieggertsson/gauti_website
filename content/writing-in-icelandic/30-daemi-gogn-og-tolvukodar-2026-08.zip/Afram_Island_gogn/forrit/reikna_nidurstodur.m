%% reikna_nidurstodur.m: allir útreikningar greinarinnar (engin teikning)
% Les EINGÖNGU gogn/gagnagrunnur.csv og gogn/handvirk_gogn.csv og reiknar
% hvert gagnafylki mynda og hverja tölu í texta greinarinnar (sjá talnaskra.csv):
%   nidurstodur/m1.csv … m11.csv   gagnafylki mynda: spjald, sæti, land, gildi
%   nidurstodur/utreikningar.txt   hver tala talnaskrárinnar: reiknað gildi á
%                                  móti gildi í grein, vikmörk og OK/FRÁVIK
% Aðferðir eru þær sem talnaskráin festir: einföld meðaltöl árlegra vaxtar-
% hlutfalla; nákvæmt Fisher-samband (1+i)/(1+pe)-1; jafngreiðsluformúlan
% P = L·(r/12)/(1-(1+r/12)^-n); 30 daga rúllandi staðalfrávik lograbreytinga
% á ársgrundvelli (×sqrt(252)); hæsta->lægsta dagsgildi innan árs; röðun alltaf
% á ónámunduð gildi með jafntefli brotið á landakóða (undantekningar: a_mann-
% spjald M2 og hækkandi M10, sjá rodun). Sæti 0 táknar viðmiðunarlínu (ESB/evrusvæði).
% Keyrsla frá rót pakkans: matlab -batch "run('forrit/reikna_nidurstodur.m')"  (R2024b)

klukka = tic;
rot = fileparts(fileparts(mfilename('fullpath')));   % rót pakkans
ut = fullfile(rot, 'nidurstodur');
if ~exist(ut, 'dir'); mkdir(ut); end

%% ---- Gagnalestur (einu inntaksskrárnar tvær) ----
T = lesa(fullfile(rot, 'gogn', 'gagnagrunnur.csv'), ...
    {'rod','svaedi','timi','gildi','eining','gagnasafn','api_slod','sott_dags'});
T.gildi = str2double(T.gildi);
H = lesa(fullfile(rot, 'gogn', 'handvirk_gogn.csv'), ...
    {'rod','svaedi','timi','gildi_str','eining','heimild','slod','sott_dags','aths'});
H.gildi = str2double(strrep(H.gildi_str, ',', '.'));   % tugstafskomma -> punktur

% ESB-27 landakóðar og íslensk heiti (röð Eurostat); ALL = 27 ríki + Ísland
KOD = ["BE","BG","CZ","DK","DE","EE","IE","EL","ES","FR","HR","IT","CY","LV", ...
       "LT","LU","HU","MT","NL","AT","PL","PT","RO","SI","SK","FI","SE"];
NOFN = ["Belgía","Búlgaría","Tékkland","Danmörk","Þýskaland","Eistland","Írland", ...
        "Grikkland","Spánn","Frakkland","Króatía","Ítalía","Kýpur","Lettland", ...
        "Litáen","Lúxemborg","Ungverjaland","Malta","Holland","Austurríki", ...
        "Pólland","Portúgal","Rúmenía","Slóvenía","Slóvakía","Finnland","Svíþjóð"];
ALLK = [KOD, "IS"]; ALLN = [NOFN, "Ísland"];
EU = "EU27_2020";
R = cell(0, 6);   % safnlisti utreikningar.txt: {merki, lýsing, reiknað, grein, vikmörk, staða}

%% ---- M1: Hagvöxtur, 5/10/20 ára meðaltöl heildar vs á mann ----
v5  = radmedal(T, "hagvoxtur", ALLK, 2021, 2025);
v10 = radmedal(T, "hagvoxtur", ALLK, 2016, 2025);
v20 = radmedal(T, "hagvoxtur", ALLK, 2006, 2025);
p5  = radmedal(T, "hagvoxtur_a_mann", ALLK, 2021, 2025);
p10 = radmedal(T, "hagvoxtur_a_mann", ALLK, 2016, 2025);
p20 = radmedal(T, "hagvoxtur_a_mann", ALLK, 2006, 2025);
e5 = medal(T,"hagvoxtur",EU,2021,2025);  e10 = medal(T,"hagvoxtur",EU,2016,2025);
e20 = medal(T,"hagvoxtur",EU,2006,2025);
q5 = medal(T,"hagvoxtur_a_mann",EU,2021,2025); q10 = medal(T,"hagvoxtur_a_mann",EU,2016,2025);
q20 = medal(T,"hagvoxtur_a_mann",EU,2006,2025);
L = table(ALLK', ALLN', v5', v10', v20', ...
    'VariableNames', {'kodi','land','voxtur_5ara','voxtur_10ara','voxtur_20ara'});
L = sortrows(L, {'voxtur_10ara','kodi'}, {'descend','ascend'});   % raðað á ónámunduð gildi
L.voxtur_5ara = round(L.voxtur_5ara, 2); L.voxtur_10ara = round(L.voxtur_10ara, 2);
L.voxtur_20ara = round(L.voxtur_20ara, 2);
L.saeti = (1:height(L))'; L.spjald = repmat("heild", height(L), 1);
Rp = rodun(ALLK, ALLN, p10);
Rp.spjald = repmat("a_mann", height(Rp), 1);
[~, ixp] = ismember(Rp.kodi, ALLK);
p5r = p5(ixp); p20r = p20(ixp);
M1 = [L(:, {'spjald','saeti','land','voxtur_5ara','voxtur_10ara','voxtur_20ara'});
      table(Rp.spjald, Rp.saeti, Rp.land, round(p5r(:),2), round(Rp.gildi,2), round(p20r(:),2), ...
      'VariableNames', {'spjald','saeti','land','voxtur_5ara','voxtur_10ara','voxtur_20ara'});
      {"heild", 0, "ESB-27", round(e5,2), round(e10,2), round(e20,2)};
      {"a_mann", 0, "ESB-27", round(q5,2), round(q10,2), round(q20,2)}];
skrifa(M1, fullfile(ut, 'm1.csv'));
i10 = medal(T,"hagvoxtur","IS",2016,2025);   ip10 = medal(T,"hagvoxtur_a_mann","IS",2016,2025);
R = bera(R, "K01a", "10 ára heildarhagvöxtur ÍS, %/ári",    i10, 2.80, 0.005);
R = bera(R, "K01b", "10 ára heildarhagvöxtur ESB-27",       e10, 1.61, 0.005);
R = bera(R, "K02a", "10 ára vöxtur á mann ÍS",              ip10, 0.86, 0.005);
R = bera(R, "K02b", "10 ára vöxtur á mann ESB-27",          q10, 1.39, 0.005);
R = bera(R, "K03",  "sæti ÍS í 10 ára vexti á mann (af 28)", find(Rp.kodi=="IS"), 23, 0);
R = bera(R, "K04",  "sæti ÍS í 10 ára heildarvexti (af 28)", find(L.kodi=="IS"), 10, 0);
R = bera(R, "K05a", "5 ára vöxtur á mann ÍS",  medal(T,"hagvoxtur_a_mann","IS",2021,2025), 1.84, 0.005);
R = bera(R, "K05b", "5 ára vöxtur á mann ESB", q5, 2.28, 0.005);
R = bera(R, "K05c", "20 ára vöxtur á mann ÍS (frávik: keðjun námundaðra ársgilda)", ...
    medal(T,"hagvoxtur_a_mann","IS",2006,2025), 0.83, 0.005);
R = bera(R, "K05d", "20 ára vöxtur á mann ESB", q20, 1.11, 0.005);
R = bera(R, "K06a", "5 ára heildarvöxtur ÍS",  medal(T,"hagvoxtur","IS",2021,2025), 3.82, 0.005);
R = bera(R, "K06b", "5 ára heildarvöxtur ESB", e5, 2.62, 0.005);
R = bera(R, "K06c", "20 ára heildarvöxtur ÍS", medal(T,"hagvoxtur","IS",2006,2025), 2.27, 0.005);
R = bera(R, "K06d", "20 ára heildarvöxtur ESB", e20, 1.31, 0.005);
upps = @(sv) (prod(1 + rad(T,"hagvoxtur_a_mann",sv,2018,2025)/100) - 1) * 100;
R = bera(R, "K07a", "uppsafnaður vöxtur á mann 2018-2025 ÍS", upps("IS"), 2.2, 0.05);
R = bera(R, "K07b", "uppsafnaður vöxtur á mann 2018-2025 ESB", upps(EU), 9.5, 0.05);
ib17 = stak(T,"mannfjoldi_1jan","IS","2017"); ib25 = stak(T,"mannfjoldi_1jan","IS","2025");
R = bera(R, "K08a", "íbúar ÍS 1.1.2017",  ib17, 338349, 0);
R = bera(R, "K08b", "íbúar ÍS 1.1.2025",  ib25, 389444, 0);
R = bera(R, "K08c", "fjölgun íbúa 2017-2025, %", (ib25/ib17-1)*100, 15.1, 0.05);
% K58: fólksfjölgun á ári 2017-2025, CAGR (íbúar2025/íbúar2017)^(1/8)-1
eb17 = stak(T,"mannfjoldi_1jan",EU,"2017"); eb25 = stak(T,"mannfjoldi_1jan",EU,"2025");
R = bera(R, "K58a", "fólksfjölgun ÍS 2017-2025, %/ári (CAGR; grein: tæp 1,8)", ((ib25/ib17)^(1/8)-1)*100, 1.8, 0.05);
R = bera(R, "K58b", "fólksfjölgun ESB-27 2017-2025, %/ári (CAGR; grein: um 0,2)", ((eb25/eb17)^(1/8)-1)*100, 0.2, 0.05);
% K62: sundurliðun heildarvaxtar í mannfjölda og vöxt á mann (birt námunduð meðaltöl)
gY62 = round(medal(T,"hagvoxtur","IS",2016,2025), 2);          % 2,80 eins og birt
gy62 = round(medal(T,"hagvoxtur_a_mann","IS",2016,2025), 2);   % 0,86 eins og birt
gN62 = gY62 - gy62;                                            % log-nálgun: 1,94
R = bera(R, "K62a", "mannfjöldaþáttur í log-nálgun, stig (2,80-0,86)", gN62, 1.94, 0.005);
R = bera(R, "K62b", "nákvæm hlutfallsjafna 1,0280/1,0194-1, %", ((1+gY62/100)/(1+gN62/100)-1)*100, 0.84, 0.005);
R = bera(R, "K62c", "námundunargap nálgunar og hlutfallsjöfnu, stig", ...
    gy62 - ((1+gY62/100)/(1+gN62/100)-1)*100, 0.02, 0.005);
R = bera(R, "K62d", "hlutdeild mannfjölda af heildarvexti, % (grein: um 70)", gN62/gY62*100, 70, 1);
R = bera(R, "K09a", "VLF 2024 endurskoðuð (handvirkt, Hagstofa 27.2.2026)", hstak(H,"vlf_2024_endursk"), -1.3, 0);
R = skra(R, "K09b", "VLF 2024 fyrsta birting (handvirkt, í einingardálki)", "+0,5", "+0,5");

%% ---- M9 + verðlagskafli: PLI, 9/12-talningin og tekjuleiðrétti kvarðinn ----
pli = radstak(T, "verdlag_E011", ALLK, "2024");
Ppli = rodun(ALLK, ALLN, pli);
eurpc = radstak(T, "vlf_a_mann_evrur", ALLK, "2024");
eur_eu = stak(T, "vlf_a_mann_evrur", EU, "2024");
adj = pli ./ (eurpc / eur_eu);                       % PLI deilt með hlutfallslegum tekjum
Padj = rodun(ALLK, ALLN, adj);
M9 = [tafla(Padj, "tekjuleidrett", 1); tafla(Ppli, "verdlag", 1)];
skrifa(M9, fullfile(ut, 'm9.csv'));
R = bera(R, "K10a", "PLI einkaneyslu ÍS 2024", pli(ALLK=="IS"), 161.7, 0.05);
R = bera(R, "K10b", "sæti ÍS í verðlagi (1 = dýrast af 28)", find(Ppli.kodi=="IS"), 1, 0);
R = bera(R, "K11",  "verðlag ÍS umfram Danmörku, %", (pli(ALLK=="IS")/pli(ALLK=="DK")-1)*100, 13, 0.5);
n1 = 0;                                              % talning 1. sæta í COICOP-deildum
for d = 1:12
    rd = sprintf("verdlag_A01%02d", d);
    vd = radstak(T, rd, ALLK, "2024");
    n1 = n1 + (vd(ALLK=="IS") == max(vd));
end
R = bera(R, "K12",  "ÍS dýrast í COICOP-deildum (af 12)", n1, 9, 0);
orka = hstak(H, "verdlag_A010405");
R = bera(R, "K13a", "PLI orku ÍS 2024 (handvirkt, prc_ppp_ind A010405)", orka, 64.2, 0.05);
R = bera(R, "K13b", "orkuverð undir ESB-meðaltali, %", 100 - orka, 36, 0.5);
R = bera(R, "K14a", "tekjuleiðréttur kvarði: Grikkland", adj(ALLK=="EL"), 152.9, 0.05);
R = bera(R, "K14b", "tekjuleiðréttur kvarði: Ísland", adj(ALLK=="IS"), 81.5, 0.05);
R = bera(R, "K14c", "sæti ÍS á tekjuleiðrétta kvarðanum (af 28)", find(Padj.kodi=="IS"), 25, 0);
R = bera(R, "K14d", "tekjuleiðréttur kvarði: Lúxemborg", adj(ALLK=="LU"), 41.8, 0.05);
hlutf = eurpc(ALLK=="IS") / eur_eu;
R = bera(R, "K15a", "tekjuhlutfall ÍS/ESB í evrum", hlutf, 1.98, 0.005);
R = bera(R, "K15b", "161,7 deilt með evruhlutfallinu", 161.7/hlutf, 82, 0.5);
g15 = tvo(H, "skyrsla_laun");                        % 26 og 26 af launaglæru bls. 19
laun15 = g15(1) / g15(2);                            % verðlagsleiðrétt ÍS/ESB = 1,00
R = bera(R, "K15c", "launahlutfall skýrslunnar ÍS/ESB (verðlagsleiðrétt 26/26)", laun15, 1.00, 0.005);
% launin á glærunni eru verðlagsleiðrétt; nafnvirðishliðstæðan er 1,00 x 1,617
launnafn = laun15 * 1.617;
R = bera(R, "K15d", "161,7 deilt með nafnvirðishliðstæðu launanna (1,617)", 161.7/(launnafn*100), 1.00, 0.005);
% kaupmáttarstuðlarnir í greininni eru reiknaðir úr birtu námunduðu tölunum
R = bera(R, "K15e", "kaupmáttarstuðull evruleiðar (1,98/1,617)", round(hlutf,2)/1.617, 1.22, 0.005);
R = bera(R, "K15f", "kaupmáttarstuðull launaleiðar (1,617/1,617)", launnafn/1.617, 1.00, 0.005);
pps131 = stak(T, "vlf_a_mann_visitala", "IS", "2024");
R = bera(R, "K16",  "PLI matar ÍS 2024 (A0101)", stak(T,"verdlag_A0101","IS","2024"), 143.9, 0.05);
lk_is = stak(T,"launakostnadur_a_klst","IS","2025"); lk_eu = stak(T,"launakostnadur_a_klst",EU,"2025");
R = bera(R, "K17a", "launakostnaður á stund ÍS 2025, EUR", lk_is, 59.3, 0.05);
R = bera(R, "K17b", "launakostnaður á stund ESB-27, EUR", lk_eu, 34.9, 0.05);
R = bera(R, "K17c", "hlutfall ÍS/ESB", lk_is/lk_eu, 1.70, 0.005);

%% ---- M8 + vaxtakafli: nafnvextir, Fisher-raunvextir, jafngreiðsludæmið ----
fisher = @(i, pe) ((1 + i/100) ./ (1 + pe/100) - 1) * 100;   % nákvæma Fisher-sambandið
i_is = hstak2(H, "ibudalanavextir_overdtryggt", "Ísland");   % 9,19 (Arion, mars 2026)
r_vt = round(hstak2(H, "ibudalanavextir_verdtryggt", "Ísland"), 1);  % 4,49 -> 4,50 eins og í grein
pe_is = hstak2(H, "vaent_verdbolga", "Ísland óverðtryggt");  % 3,5 (Peningamál 2026/1)
i_ea = stak(T, "ibudalanavextir_ny_lan", "U2", "2026-04");   % 3,44 (ECB MIR)
pe_ea = hstak2(H, "vaent_verdbolga", "Evrusvæðið");          % 2,65 (EC vorspá 2026)
% nafnvaxtaspjaldið: evruríki úr ECB MIR (GR = Grikkland), önnur ESB-ríki handvirk
kmir = T.svaedi(T.rod == "ibudalanavextir_ny_lan" & T.svaedi ~= "U2");
imir = T.gildi(T.rod == "ibudalanavextir_ny_lan" & T.svaedi ~= "U2");
kmir(kmir == "GR") = "EL";
khand = H.svaedi(H.rod == "ibudalanavextir_ny_lan");
nofn_n = [arrayfun(@(k) NOFN(KOD==k), kmir'), khand', "Ísland óverðtr."];
kod_n  = [kmir', arrayfun(@(n) KOD(NOFN==n), khand'), "IS"];
i_n    = [imir', arrayfun(@(n) hstak2(H,"ibudalanavextir_ny_lan",n), khand'), i_is];
Pnom = rodun(kod_n, nofn_n, i_n);
assert(height(Pnom) == 28, 'M8: vænti 28 landa í nafnvaxtaspjaldi');
% raunvaxtaspjaldið: pe hvers lands (EC vorspá, öll 27 ríkin); verðtryggt ÍS bætt við
pe_n = arrayfun(@(n) hpe(H, n), nofn_n);   pe_n(end) = pe_is;
lif = ~isnan(pe_n);
kod_r  = [kod_n(lif), "IS2"];
nofn_r = [nofn_n(lif), "Ísland verðtr."];
r_r    = [fisher(i_n(lif), pe_n(lif)), NaN];
r_r(nofn_r == "Ísland verðtr.") = r_vt;    % raunvextir samkvæmt samningi, engin spá
Preal = rodun(kod_r, nofn_r, r_r);
assert(height(Preal) == 29, 'M8: vænti 29 lína í raunvaxtaspjaldi (27 ríki + ÍS x2)');
M8 = [tafla(Pnom, "nafnvextir", 2); tafla(Preal, "raunvextir", 2);
      {"nafnvextir", 0, "Evrusvæðið", round(i_ea,2)};
      {"raunvextir", 0, "Evrusvæðið", round(fisher(i_ea,pe_ea),2)}];
skrifa(M8, fullfile(ut, 'm8.csv'));
R = bera(R, "K18a", "raunvextir óverðtr. íbúðalána ÍS (Fisher 9,19/3,5)", fisher(i_is,pe_is), 5.50, 0.005);
R = bera(R, "K18b", "raunvextir íbúðalána evrusvæðis (Fisher 3,44/2,65)", fisher(i_ea,pe_ea), 0.77, 0.005);
hamark_evru = max(imir);
R = bera(R, "K19a", "verðtryggðir vextir ÍS", r_vt, 4.50, 0.005);
R = bera(R, "K19b", "hæstu nafnvextir evruríkis (frávik: ECB endurskoðaði apríl-tölu Lettlands)", ...
    hamark_evru, 4.18, 0.005);
R = bera(R, "K19c", "verðtryggt ÍS hærra en allir evrunafnvextir (1=satt)", double(r_vt > hamark_evru), 1, 0);
% K19d: hæstu raunvextir evruríkis, endurskoðunarþolið bil [1,15-1,30] (grein: um 1,2%)
raun_evru = r_r(ismember(kod_r, kmir'));            % evruríkin ein (ECB MIR-löndin)
hamark_raun = max(raun_evru);
if hamark_raun >= 1.15 && hamark_raun <= 1.30; st19d = "OK"; else; st19d = "FRÁVIK"; end
R(end+1,:) = {"K19d", "hæstu raunvextir evruríkis (endurskoðunarþolið bil 1,15-1,30)", ...
    isl(hamark_raun), "um 1,2", "bil", st19d};
R = bera(R, "K20a", "nafnvaxtamunur ÍS-evrusvæði, stig", i_is - i_ea, 5.75, 0.005);
R = bera(R, "K20b", "þar af verðbólgumunur (grein: um 1 stig)", pe_is - pe_ea, 1, 0.2);
R = bera(R, "K20c", "þar af raunvaxtamunur, stig", fisher(i_is,pe_is) - fisher(i_ea,pe_ea), 4.7, 0.05);
g21 = tvo(H, "skyrsla_styrivextir_IS");                     % 7,5 og 4,0 af glæru skýrslunnar
R = bera(R, "K21a", "raunstýrivextir af glæru, nákvæm Fisher", fisher(g21(1), g21(2)), 3.37, 0.005);
R = bera(R, "K21b", "raunstýrivextir af glæru, línuleg nálgun", g21(1) - g21(2), 3.5, 0.005);
g21e = tvo(H, "skyrsla_styrivextir_EA");
R = bera(R, "K21c", "evrusvæðið af glæru: 2,0/2,0 gefur núll", fisher(g21e(1), g21e(2)), 0, 0.005);
hofudst = hstak(H, "lansdaemi_hofudstoll"); man = hstak(H, "lansdaemi_manudir");
jafng = @(r) hofudst * (r/12) / (1 - (1 + r/12)^(-man));    % P = L·(r/12)/(1-(1+r/12)^-n)
P_is = jafng(r_vt/100); P_ev = jafng(0.77/100);             % 4,50% og 0,77% raunvextir
R = bera(R, "K22a", "mánaðargreiðsla við 4,50%, þús.kr.", P_is/1e3, 333, 0.5);
R = bera(R, "K22b", "mánaðargreiðsla við 0,77%, þús.kr.", P_ev/1e3, 220, 0.5);
R = bera(R, "K22c", "heildargreiðslur ÍS-dæmis, m.kr.", P_is*man/1e6, 100, 0.5);
R = bera(R, "K22d", "heildargreiðslur evrudæmis, m.kr.", P_ev*man/1e6, 66, 0.5);
R = bera(R, "K22e", "vextir alls ÍS-dæmis, m.kr.", (P_is*man - hofudst)/1e6, 40, 0.5);
R = bera(R, "K22f", "vextir alls evrudæmis, m.kr.", (P_ev*man - hofudst)/1e6, 6, 0.5);
R = bera(R, "K23",  "greiðslumunur á mánuði, þús.kr. (nákvæmt 113,568; grein: um 114)", (P_is - P_ev)/1e3, 114, 0.5);
% K57: vaxtahluti fyrstu mánaðargreiðslu jafngreiðsluláns = L·r/12
R = bera(R, "K57a", "vaxtahluti fyrstu greiðslu við 4,50%, þús.kr.", hofudst*(r_vt/100)/12/1e3, 225, 0.5);
R = bera(R, "K57b", "vaxtahluti fyrstu greiðslu við 0,77%, þús.kr. (grein: um 39)", hofudst*(0.77/100)/12/1e3, 39, 0.5);
% K59: árlegur greiðslumunur; K63: varfærni raunvaxtamunurinn; K66: HMS-forsendan
R = bera(R, "K59",  "árlegur greiðslumunur, m.kr. (grein: um 1,4)", (P_is - P_ev)*12/1e6, 1.4, 0.05);
R = bera(R, "K63",  "varfærni raunvaxtamunurinn 4,50-0,77, stig (grein: 3,7)", r_vt - fisher(i_ea,pe_ea), 3.7, 0.05);
R = bera(R, "K66a", "verð fyrstu íbúðar 2025, m.kr. (handvirkt, HMS — bein slóð ekki varðveitt)", ...
    hstak(H,"hms_fyrsta_ibud")/1e6, 70.6, 0);
R = bera(R, "K66b", "veðhlutfall lánsdæmisins 60/70,6, % (grein: 85)", ...
    hofudst/hstak(H,"hms_fyrsta_ibud")*100, 85, 0.5);

%% ---- M4 + ungmennakafli: tvær nefnaraskilgreiningar ----
% Lúxemborg er ekki í yth_empl_140 (of lítið úrtak) og er því utan beggja spjalda
KU = ALLK(ALLK ~= "LU"); NU = ALLN(ALLK ~= "LU");
u24 = radstak(T, "atvinnuleysi_15_24", KU, "2025");
q24 = radstak(T, "atvinnuleysishlutfall_15_24", KU, "2025");
a24 = radstak(T, "atvinnuthatttaka_15_24", KU, "2025");
Pu = rodun(KU, NU, u24); Pq = rodun(KU, NU, q24);
u_eu = stak(T,"atvinnuleysi_15_24",EU,"2025"); q_eu = stak(T,"atvinnuleysishlutfall_15_24",EU,"2025");
M4 = [tafla(Pu, "af_vinnuafli", 1); tafla(Pq, "af_argangi", 1);
      {"af_vinnuafli", 0, "ESB-27", round(u_eu,1)}; {"af_argangi", 0, "ESB-27", round(q_eu,1)}];
skrifa(M4, fullfile(ut, 'm4.csv'));
R = bera(R, "K24a", "atvinnuleysi 15-24 ára ÍS 2025, % af vinnuafli", u24(KU=="IS"), 9.5, 0.05);
R = bera(R, "K24b", "atvinnuleysi 15-24 ára ESB-27", u_eu, 15.2, 0.05);
R = bera(R, "K25a", "atvinnuþátttaka 15-24 ára ÍS", a24(KU=="IS"), 82.7, 0.05);
R = bera(R, "K25b", "atvinnuþátttaka 15-24 ára ESB-27", stak(T,"atvinnuthatttaka_15_24",EU,"2025"), 40.7, 0.05);
R = bera(R, "K26a", "hlutfall af árgangi ÍS (yth_empl_140)", q24(KU=="IS"), 7.9, 0.05);
R = bera(R, "K26b", "hlutfall af árgangi ESB-27", q_eu, 6.2, 0.05);
R = bera(R, "K26c", "sæti ÍS á árgangskvarða (af 27)", find(Pq.kodi=="IS"), 7, 0);
R = bera(R, "K26d", "sannprófun q = u·a fyrir ÍS", u24(KU=="IS")*a24(KU=="IS")/100, 7.9, 0.05);
R = bera(R, "K27a", "NEET 15-24 ára ÍS 2025", stak(T,"neet_15_24","IS","2025"), 4.1, 0.05);
R = bera(R, "K27b", "NEET 15-24 ára ESB-27", stak(T,"neet_15_24",EU,"2025"), 9.0, 0.05);
R = bera(R, "K28a", "Finnland: atvinnuleysi 15-24", u24(KU=="FI"), 21.8, 0.05);
R = bera(R, "K28b", "Finnland: hlutfall af árgangi", q24(KU=="FI"), 11.7, 0.05);
R = bera(R, "K28c", "Svíþjóð: atvinnuleysi 15-24", u24(KU=="SE"), 24.3, 0.05);
R = bera(R, "K28d", "Svíþjóð: hlutfall af árgangi", q24(KU=="SE"), 13.9, 0.05);
R = bera(R, "K28e", "Svíþjóð efst á árgangskvarða (sæti)", find(Pq.kodi=="SE"), 1, 0);
R = bera(R, "K28f", "Spánn: atvinnuleysi 15-24", u24(KU=="ES"), 24.9, 0.05);
R = bera(R, "K28g", "Spánn: hlutfall af árgangi", q24(KU=="ES"), 8.4, 0.05);

%% ---- M3 + framleiðnikafli: uppsafnað frá 2000, 10 ára gluggi, stig 2024 ----
upp00 = arrayfun(@(k) (stak(T,"framleidni_vinnustund_i15",k,"2025") / ...
                       stak(T,"framleidni_vinnustund_i15",k,"2000") - 1) * 100, ALLK);
upp_eu = (stak(T,"framleidni_vinnustund_i15",EU,"2025")/stak(T,"framleidni_vinnustund_i15",EU,"2000")-1)*100;
nord = mean(upp00(ismember(ALLK, ["DK","SE","FI"])));       % Norðurlöndin í ESB
Pu00 = rodun(ALLK, ALLN, upp00);
M3 = [table(repmat("skyrslan",3,1), zeros(3,1), ["Ísland";"Norðurlöndin í ESB";"ESB-27"], ...
      round([upp00(ALLK=="IS"); nord; upp_eu],1), 'VariableNames', {'spjald','saeti','land','gildi'});
      tafla(Pu00, "oll_riki", 1); {"oll_riki", 0, "ESB-27", round(upp_eu,1)}];
skrifa(M3, fullfile(ut, 'm3.csv'));
f10 = radstak(T, "framleidni_vinnustund_10ara", ALLK, "2025");
P10 = rodun(ALLK, ALLN, f10);
R = bera(R, "K29a", "raunframleiðni á stund, uppsafnað 2000-2025 ÍS, %", upp00(ALLK=="IS"), 52.0, 0.05);
R = bera(R, "K29b", "sæti ÍS í uppsöfnun frá 2000 (af 28)", find(Pu00.kodi=="IS"), 14, 0);
R = bera(R, "K30a", "10 ára framleiðnivöxtur ÍS (nama_10_lp_ulc)", f10(ALLK=="IS"), 11.6, 0.05);
R = bera(R, "K30b", "10 ára framleiðnivöxtur Danmerkur", f10(ALLK=="DK"), 13.2, 0.05);
R = bera(R, "K30c", "sæti ÍS í 10 ára glugganum (af 28)", find(P10.kodi=="IS"), 14, 0);
fst = radstak(T, "framleidni_a_vinnustund_esb100_nama", ALLK, "2024");
Pfst = rodun(ALLK, ALLN, fst);
R = bera(R, "K31a", "framleiðnistig ÍS 2024 (ESB=100, á stund)", fst(ALLK=="IS"), 123.4, 0.05);
R = bera(R, "K31b", "sæti ÍS í framleiðnistigi (af 28)", find(Pfst.kodi=="IS"), 7, 0);
R = bera(R, "K31c", "Þýskaland", fst(ALLK=="DE"), 123.6, 0.05);
R = bera(R, "K31d", "Holland",   fst(ALLK=="NL"), 125.3, 0.05);
R = bera(R, "K31e", "Belgía",    fst(ALLK=="BE"), 133.7, 0.05);
R = bera(R, "K31f", "Danmörk",   fst(ALLK=="DK"), 138.0, 0.05);
R = bera(R, "K32a", "framleiðni 2024, endurskoðað mat SÍ (handvirkt, Peningamál 2025/4)", hstak(H,"framleidni_2024_endursk"), -2.3, 0);
R = skra(R, "K32b", "framleiðni 2024, fyrra mat (handvirkt, í einingardálki)", "-0,6", "-0,6");
R = bera(R, "K32c", "hækkun launakostnaðar á einingu (handvirkt)", hstak(H,"ulc_2024"), 8.4, 0);
z10 = hstak2(H,"ameco_zvgdf_2010"); z21 = hstak2(H,"ameco_zvgdf_2021");
R = bera(R, "K33",  "TFP-breyting 2010-2021 (AMECO ZVGDF)", (z21/z10-1)*100, 10.2, 0.05);
R = bera(R, "K34a", "venjuleg vinnuvika ÍS 2024, klst. (handvirkt, lfsa_ewhun2)", ...
    hstak2(H,"vinnuvika_venjuleg","Ísland"), 39.1, 0);
R = bera(R, "K34b", "venjuleg vinnuvika ESB-27", hstak2(H,"vinnuvika_venjuleg","ESB-27"), 37.3, 0);

%% ---- M10 + skuldakafli: AGS fyrir Ísland, Eurostat fyrir ESB, sama ár ----
d_is = stak(T, "skuldir_hins_opinbera", "ISL", "2025");      % AGS WEO
d_eu = stak(T, "skuldir_hins_opinbera_maastricht", EU, "2025");
dk27 = radstak(T, "skuldir_hins_opinbera_maastricht", KOD, "2025");
Pd = rodun([KOD, "IS"], [NOFN, "Ísland"], [dk27, d_is], "haekkandi");   % lægstu skuldir fyrst
g55sk = H.gildi_str(H.rod == "skyrsla_skuldir");             % "45 vs 84-88" af glæru
M10 = [table(repmat("skyrslan",2,1), zeros(2,1), ["Ísland — spá AGS 2030";"ESB meðaltal — í dag"], ...
      [45; 84], 'VariableNames', {'spjald','saeti','land','gildi'});
      tafla(Pd, "arid_2025", 1); {"arid_2025", 0, "ESB-27", round(d_eu,1)}];
skrifa(M10, fullfile(ut, 'm10.csv'));
R = bera(R, "K35a", "skuldir hins opinbera ÍS 2025 (AGS)", d_is, 56.1, 0.05);
R = bera(R, "K35b", "skuldir ESB-27 2025 (Eurostat)", d_eu, 81.7, 0.05);
R = bera(R, "K35c", "sæti ÍS, talið frá lægstu skuldum (af 28)", find(Pd.kodi=="IS"), 13, 0);
R = bera(R, "K35d", "spá AGS um ÍS 2030", stak(T,"skuldir_hins_opinbera","ISL","2030"), 45.4, 0.05);
KV = ["EL",146.1; "IT",137.1; "FR",115.6; "DK",27.9; "SE",35.1; "IE",32.9; "NL",44.4];
for j = 1:size(KV,1)
    R = bera(R, "K36"+char('a'+j-1), "skuldir 2025: " + NOFN(KOD==KV(j,1)), ...
        dk27(KOD==KV(j,1)), double(KV(j,2)), 0.05);
end

%% ---- M5 + atvinnuleysiskafli: árstölur og mánaðartölur ----
au_is = stak(T,"atvinnuleysi_15_74","IS","2025"); au_eu = stak(T,"atvinnuleysi_15_74",EU,"2025");
R = bera(R, "K37a", "atvinnuleysi 15-74 ára ÍS 2025", au_is, 4.5, 0.05);
R = bera(R, "K37b", "atvinnuleysi ESB-27 2025", au_eu, 6.0, 0.05);
R = bera(R, "K37c", "meðaltal 2016-2025 ÍS", medal(T,"atvinnuleysi_15_74","IS",2016,2025), 3.9, 0.05);
R = bera(R, "K37d", "meðaltal 2016-2025 ESB-27", medal(T,"atvinnuleysi_15_74",EU,2016,2025), 7.0, 0.05);
% mánaðartölur: sameiginlegur apríl og blandað nýjasta (maí, Ísland apríl)
m_apr = radstak(T, "atvinnuleysi_manadarlegt", ALLK, "2026-04");
m_mai = m_apr;                                              % Ísland á ekki maí-tölu
for j = 1:27; m_mai(j) = stak(T, "atvinnuleysi_manadarlegt", KOD(j), "2026-05"); end
Papr = rodun(ALLK, ALLN, m_apr);
nofn_m = ALLN; nofn_m(ALLK=="IS") = "Ísland (apríl)";
Pmai = rodun(ALLK, nofn_m, m_mai);
eu_mai = stak(T, "atvinnuleysi_manadarlegt", EU, "2026-05");
M5 = [tafla(Pmai, "blandad_nyjasta", 1); tafla(Papr, "april_allir", 1);
      {"blandad_nyjasta", 0, "ESB-27", round(eu_mai,1)}];
skrifa(M5, fullfile(ut, 'm5.csv'));
R = bera(R, "K38a", "árstíðaleiðrétt atvinnuleysi ÍS, apríl 2026", m_apr(ALLK=="IS"), 5.8, 0.05);
R = bera(R, "K38b", "atvinnuleysi ESB-27, maí 2026", eu_mai, 5.9, 0.05);
R = bera(R, "K38c", "sæti ÍS, allir á sameiginlegum apríl (af 28)", find(Papr.kodi=="IS"), 14, 0);
R = bera(R, "K38d", "sæti ÍS, blandað nýjasta snið (af 28)", find(Pmai.kodi=="IS"), 14, 0);
R = bera(R, "K39a", "skráð atvinnuleysi VMST maí 2026 (handvirkt)", hstak2(H,"vmst_atvinnuleysi","Ísland","2026-05"), 4.2, 0);
R = bera(R, "K39b", "skráð atvinnuleysi VMST maí 2025 (handvirkt)", hstak2(H,"vmst_atvinnuleysi","Ísland","2025-05"), 3.7, 0);
R = bera(R, "K39c", "breyting starfandi Q4 2025 (handvirkt)", hstak(H,"starfandi_q4"), -2000, 0);

%% ---- M7 + flöktkafli: 30 daga flökt á ársgrundvelli og innanársgengislækkanir ----
[d_iu, v_iu] = flokt(T, "gengi_USD_ISK_midgengi");           % ISK á USD (SÍ 4055)
[d_eu2, v_eu2] = flokt(T, "gengi_USD_EUR");                  % USD á EUR (ECB)
[d_ie, v_ie] = flokt(T, "gengi_EUR_ISK_midgengi");           % ISK á EUR (SÍ 4064)
gl = {"2014-2026 (gluggi skýrslunnar)", 2014, 2026; "2014-2016 (gjaldeyrishöft)", 2014, 2016;
      "2008-2013 (sleppt í skýrslunni)", 2008, 2013; "2008-2026", 2008, 2026; "1999-2026 (allt)", 1999, 2026};
fl = zeros(5, 3);
for j = 1:5
    fl(j,:) = [gluggamedal(d_iu,v_iu,gl{j,2},gl{j,3}), gluggamedal(d_eu2,v_eu2,gl{j,2},gl{j,3}), ...
               gluggamedal(d_ie,v_ie,gl{j,2},gl{j,3})];
end
M7 = table(string(gl(:,1)), round(fl(:,1),1), round(fl(:,2),1), round(fl(:,3),1), ...
    'VariableNames', {'timabil','flokt_ISK_USD','flokt_EUR_USD','flokt_ISK_EUR'});
skrifa(M7, fullfile(ut, 'm7.csv'));
vaent7 = [9.2 7.3 NaN; 7.8 8.5 3.0; 15.1 10.5 NaN; 11.1 8.4 NaN; 11.1 8.7 NaN];
merki7 = ["ISK/USD","EUR/USD","ISK/EUR"];
for j = 1:5
    for k = 1:3
        if ~isnan(vaent7(j,k))
            R = bera(R, sprintf("K40%c%d", 'a'+j-1, k), ...
                "flökt " + merki7(k) + " " + string(gl{j,1}), fl(j,k), vaent7(j,k), 0.06);
        end
    end
end
ar41 = [2001 2006 2008 2018 2020]; vaent41 = [-19.3 -24.2 -51.7 -14.8 -18.0];
kre = T.rod == "gengi_EUR_ISK_midgengi";
d41 = T.timi(kre); g41 = T.gildi(kre);
for j = 1:5
    ka = startsWith(d41, string(ar41(j)));
    laekkun = (min(g41(ka)) / max(g41(ka)) - 1) * 100;       % hæsta -> lægsta dagsgildi ISK
    R = bera(R, "K41"+char('a'+j-1), sprintf("gengislækkun ISK/EUR innan árs %d, %%", ar41(j)), ...
        laekkun, vaent41(j), 0.05);
end
R = bera(R, "K42a", "hlutdeild SÍ í gjaldeyrisveltu, lágmark (handvirkt)", ...
    min(H.gildi(H.rod=="si_gjaldeyrisvelta")), 43, 0);
R = bera(R, "K42b", "hlutdeild SÍ í gjaldeyrisveltu, hámark (handvirkt)", ...
    max(H.gildi(H.rod=="si_gjaldeyrisvelta")), 55, 0);
vb_is = T.gildi(T.rod=="verdbolga_neysluverd" & T.svaedi=="ISL");
vb_em = T.gildi(T.rod=="verdbolga_neysluverd" & T.svaedi=="EMU");
assert(numel(vb_is)==36 && numel(vb_em)==36, 'verðbólga: vænti 36 ára 1990-2025');
R = bera(R, "K43a", "meðalverðbólga ÍS 1990-2025 (Alþjóðabankinn)", mean(vb_is), 4.7, 0.05);
R = bera(R, "K43b", "meðalverðbólga evrusvæðis 1990-2025", mean(vb_em), 2.7, 0.05);
R = bera(R, "K43c", "ár yfir 5% verðbólgu, ÍS", sum(vb_is > 5), 14, 0);
R = bera(R, "K43d", "ár yfir 5% verðbólgu, evrusvæðið", sum(vb_em > 5), 3, 0);
R = skra(R, "K44a", "ECB hætti skráningu ISK (handvirkt)", ...
    extractBefore(H.timi(H.rod=="ecb_isk_skraning_haett"), 5), "2008");
R = skra(R, "K44b", "ECB hóf skráningu ISK aftur (handvirkt)", ...
    extractBefore(H.timi(H.rod=="ecb_isk_skraning_hafin"), 5), "2018");

%% ---- M2 + VLF-kafli: á mann vs á hvern 25-54 ára vs á hvern starfandi ----
gpc = radstak(T, "vlf_a_mann_visitala", ALLK, "2024");
gpw = radstak(T, "framleidni_a_starfandi_esb100", ALLK, "2024");
% VLF á hvern 25-54 ára („prime age", skilgr. BLS; heimild [37]): VLF 2024 í
% millj. PPS (nama_10_gdp CP_MPPS) deilt með meðalfjölda 25-54 ára ársins 2024
% (meðaltal 1.1.2024 og 1.1.2025, demo_pjan stakir aldrar), vísitala ESB-27=100
prim = @(sv) mean([sum(arrayfun(@(a) stak(T, "mannfjoldi_Y"+a, sv, "2024"), 25:54)), ...
                   sum(arrayfun(@(a) stak(T, "mannfjoldi_Y"+a, sv, "2025"), 25:54))]);
vlf_prim = @(sv) stak(T, "vlf_mpps", sv, "2024") * 1e6 / prim(sv);
gpr = arrayfun(@(k) vlf_prim(k) / vlf_prim(EU) * 100, ALLK);
% tec00114 er heiltölukvarði svo jafntefli eru raunveruleg (98/98, 90/90, 79/79);
% birta myndin raðar þeim í öfuga stafrófsröð heita, sama regla notuð hér
Pgpc = rodun(ALLK, ALLN, gpc, "heiti_ofug"); Pgpw = rodun(ALLK, ALLN, gpw);
Pgpr = rodun(ALLK, ALLN, gpr);
M2 = [tafla(Pgpc, "a_mann", 0); tafla(Pgpr, "a_25_54", 0); tafla(Pgpw, "a_starfandi", 1)];
skrifa(M2, fullfile(ut, 'm2.csv'));
R = bera(R, "K45a", "VLF á mann ÍS 2024, PPS", stak(T,"vlf_a_mann_pps","IS","2024"), 52400, 50);
R = bera(R, "K45b", "PPS-vísitala ÍS 2024 (tec00114)", pps131, 131, 0.5);
R = bera(R, "K45c", "sæti ÍS í VLF á mann (af 28)", find(Pgpc.kodi=="IS"), 4, 0);
R = bera(R, "K46a", "VLF á hvern starfandi ÍS 2024 (tesem160)", gpw(ALLK=="IS"), 110.9, 0.05);
R = bera(R, "K46b", "sæti ÍS í VLF á starfandi (af 28)", find(Pgpw.kodi=="IS"), 7, 0);
R = bera(R, "K46c", "forskot á mann, prósentustig yfir 100", gpc(ALLK=="IS") - 100, 31, 0.5);
R = bera(R, "K46d", "forskot á starfandi, prósentustig yfir 100", gpw(ALLK=="IS") - 100, 11, 0.5);
R = bera(R, "K56a", "VLF á hvern 25-54 ára ÍS 2024 (ESB-27=100; grein: 121)", gpr(ALLK=="IS"), 121, 0.5);
R = bera(R, "K56b", "sæti ÍS í VLF á hvern 25-54 ára (af 28)", find(Pgpr.kodi=="IS"), 5, 0);
hlut2554 = @(sv) prim(sv) / mean([stak(T,"mannfjoldi_1jan",sv,"2024"), ...
                                  stak(T,"mannfjoldi_1jan",sv,"2025")]) * 100;
R = bera(R, "K56c", "hlutur 25-54 ára af íbúum ÍS, %", hlut2554("IS"), 42.1, 0.05);
R = bera(R, "K56d", "hlutur 25-54 ára af íbúum ESB-27, %", hlut2554(EU), 39.1, 0.05);
% K61: hlutur aldurssamsetningar í umframforskoti á höfðatölu, úr birtu vísitölunum
R = bera(R, "K61",  "hlutur aldurssamsetningar, % af umframforskoti (grein: um þriðjungur)", ...
    (round(gpc(ALLK=="IS")) - round(gpr(ALLK=="IS"))) / (round(gpc(ALLK=="IS")) - 100) * 100, 33.3, 1.5);
R = bera(R, "K47",  "raunveruleg einstaklingsneysla ÍS, % yfir ESB", ...
    stak(T,"raunneysla_a_mann_esb100","IS","2024") - 100, 16, 0.5);
R = bera(R, "K48a", "innflytjendur 2024, % starfandi (handvirkt, VMST)", hstak(H,"innflytjendur_starfandi"), 24, 0);
R = bera(R, "K48b", "innflytjendur 2024, % íbúa (handvirkt; Hagstofa 1.1.2025: 18,9)", hstak(H,"innflytjendur_ibuar"), 18.2, 0);
R = bera(R, "K64",  "launuð starfsreynsla samhliða námi 2016, % 15-34 ára (handvirkt)", ...
    hstak(H,"eurostat_starfsreynsla_87"), 87, 0);

%% ---- M11 + höfuðborgarkafli: íbúahlutföll, staðgengilslyklarnir þrír, OECD-tekjur ----
HB = ["Reykjavíkurborg","Kópavogsbær","Seltjarnarnesbær","Garðabær", ...
      "Hafnarfjarðarkaupstaður","Mosfellsbær","Kjósarhreppur"];
BELTI = ["Reykjanesbær","Grindavíkurbær","Suðurnesjabær","Sveitarfélagið Vogar", ...
         "Akraneskaupstaður","Hvalfjarðarsveit","Sveitarfélagið Árborg", ...
         "Hveragerðisbær","Sveitarfélagið Ölfus"];
ibu = @(sv, t) stak(T, "mannfjoldi_sveitarfelaga", sv, t);
ibusum = @(svl, t) sum(arrayfun(@(s) ibu(s, t), svl));
hl_hb = @(t) ibusum(HB, t) / ibu("Alls", t);                 % þröngt: hbsv, 7 sveitarfélög
hl_br = @(t) ibusum([HB, BELTI], t) / ibu("Alls", t);        % vítt: + Suðurnes, Akranes o.fl.
R = bera(R, "K49a", "íbúahlutfall hbsv 1.1.2025, %", hl_hb("2025")*100, 64, 0.5);
R = bera(R, "K49b", "íbúahlutfall hbsv 1.1.2026, %", hl_hb("2026")*100, 63.9, 0.05);
R = bera(R, "K49c", "íbúahlutfall víða svæðisins 1.1.2026 (grein: 78,5-79%)", hl_br("2026")*100, 78.5, 0.3);
% K65: akstursmörk víða svæðisins, flokkun höfundar, ósannreynanleg
R = skra(R, "K65", "akstursmörk víða svæðisins, mín. (flokkun höfundar, ósannreynanlegt)", ...
    isl(hstak(H,"akstursmork_vitt_svaedi")), "50");
% stórborgarsvæðaspjaldið (met_10r_3gdp 2021, án Noregs) og Reykjavíkurbilið
CAPK = ["AT","BE","BG","CY","CZ","DE","DK","EE","EL","ES","FI","FR","HR","HU", ...
        "IE","IT","LT","LU","LV","MT","NL","PL","PT","RO","SE","SI","SK"];
CAPN = ["Vín","Brussel","Sofía","Nikósía","Prag","Berlín","Kaupmannahöfn","Tallinn", ...
        "Aþena","Madríd","Helsinki","París","Zagreb","Búdapest","Dyflinni","Róm", ...
        "Vilníus","Lúxemborg","Ríga","Valletta","Amsterdam","Varsjá","Lissabon", ...
        "Búkarest","Stokkhólmur","Ljúbljana","Bratislava"];
kmet = T.svaedi(T.rod == "vlf_storborgarsvaedis_esb100" & T.svaedi ~= "NO001MC");
vmet = T.gildi(T.rod == "vlf_storborgarsvaedis_esb100" & T.svaedi ~= "NO001MC");
lmet = arrayfun(@(k) CAPN(CAPK == extractBefore(k, 3)), kmet');
assert(numel(vmet) == 27, 'M11: vænti 27 stórborgarsvæða höfuðborga');
R = bera(R, "K50a", "stórborgarsvæði 2021: Dyflinni", vmet(kmet=="IE001MC"), 273, 0.5);
R = bera(R, "K50b", "stórborgarsvæði 2021: Aþena", vmet(kmet=="EL001MC"), 87, 0.5);
R = bera(R, "K50c", "höfuðborgarsvæði yfir Íslandsvísitölunni 131 (af 27)", sum(vmet > pps131), 14, 0);
R = bera(R, "K50d", "miðgildi höfuðborgarsvæðanna 27", median(vmet), 132, 0.5);
R = bera(R, "K60a", "stórborgarsvæði 2021: Kaupmannahöfn", vmet(kmet=="DK001MC"), 173, 0.5);
R = bera(R, "K60b", "stórborgarsvæði 2021: París", vmet(kmet=="FR001MC"), 172, 0.5);
R = bera(R, "K60c", "stórborgarsvæði 2021: Stokkhólmur", vmet(kmet=="SE001MC"), 168, 0.5);
R = bera(R, "K60d", "stórborgarsvæði 2021: Varsjá", vmet(kmet=="PL001MC"), 164, 0.5);
R = bera(R, "K51",  "PPS-vísitala ÍS 2021 (tec00114)", stak(T,"vlf_a_mann_visitala","IS","2021"), 124, 0.5);
% lyklarnir þrír: vísitala = hlutdeild / íbúahlutdeild x 131 (VLF styttist út)
laun = @(sv, t) stak(T, "stadgreidsla_laun", sv, t);
ws25 = laun("Höfuðborgarsvæði", "2025") / laun("Alls", "2025");
wb25 = (laun("Höfuðborgarsvæði","2025") + sum(arrayfun(@(s) laun(s,"2025"), BELTI))) / laun("Alls","2025");
L1_th = ws25 / hl_hb("2025") * pps131;                       % L1: launasumma TEK02014 2025
L1_vi = wb25 / hl_br("2025") * pps131;
sh_L2 = hstak(H, "m11_lykill_atvinnutekjur") / 100;          % L2: Byggðastofnun 66,3% (2024)
hb24m = (ibusum(HB,"2024") + ibusum(HB,"2025")) / 2;         %     miðársíbúar 2024
al24m = (ibu("Alls","2024") + ibu("Alls","2025")) / 2;
br24m = (ibusum([HB,BELTI],"2024") + ibusum([HB,BELTI],"2025")) / 2;
skali24 = (laun("Höfuðborgarsvæði","2024") + sum(arrayfun(@(s) laun(s,"2024"), BELTI))) ...
          / laun("Höfuðborgarsvæði","2024");                 % vítt/þröngt eftir launasummum
L2_th = sh_L2 / (hb24m/al24m) * pps131;
L2_vi = sh_L2 * skali24 / (br24m/al24m) * pps131;            % TEK01002-kvarðinn ekki í grunni;
                                                             % launaskali notaður í staðinn
R2019 = hstak(H, "m11_lykill_thattatekjur_hbsv") / hstak(H, "m11_lykill_thattatekjur_landid");
ws19 = laun("Höfuðborgarsvæði", "2019") / laun("Alls", "2019");
rek = (ws25/hl_hb("2025")) / (ws19/hl_hb("2019"));           % L3: launahlutdeild á mann rekur R2019
L3_th = R2019 * rek * pps131;
L3_vi = R2019 * rek * hl_hb("2025") * (wb25/ws25) / hl_br("2025") * pps131;
bil = [min([L1_th L1_vi L2_th L2_vi L3_th L3_vi]), max([L1_th L1_vi L2_th L2_vi L3_th L3_vi])];
R = bera(R, "K52a", "L1: launahlutdeild hbsv 2025 (TEK02014), %", ws25*100, 65.15, 0.05);
R = bera(R, "K52b", "staðgengilsbil, neðri mörk (grein: 131)", bil(1), 131, 0.5);
R = bera(R, "K52c", "staðgengilsbil, efri mörk (grein: 138)", bil(2), 138, 0.5);
R = bera(R, "K52d", "sæti efri marka meðal stórborgarsvæðanna", 1 + sum(vmet > bil(2)), 13, 0);
R = bera(R, "K52e", "sæti neðri marka meðal stórborgarsvæðanna", 1 + sum(vmet > bil(1)), 16, 0);
Pmet = rodun([kmet', "IS"], [lmet, "Reykjavík (mat)"], [vmet', round(bil(1),1)]);
Mv = tafla(Pmet, "vlf_metro_2021", 1);
Mv.bil_lag = nan(height(Mv),1); Mv.bil_ha = nan(height(Mv),1);
Mv.bil_lag(Mv.land=="Reykjavík (mat)") = round(bil(1),1);
Mv.bil_ha(Mv.land=="Reykjavík (mat)") = round(bil(2),1);
% OECD-tekjuspjaldið (B6N á íbúa 2023, þús. USD á jafnvirðisgengi)
OK2 = ["AT13","BE1","BG41","CYP","CZ01","DE3","DK01","EE00","EL30","ES30","FI1B", ...
       "FR1","HR05","HU11","IE06","ITI4","LT01","LU00","LV00","MT00","NL32","PL91", ...
       "PT1A","RO32","SE11","SI04","SK01","IS01"];
ON2 = ["Vín","Brussel","Sofía","Nikósía","Prag","Berlín","Kaupmannahöfn","Tallinn", ...
       "Aþena","Madríd","Helsinki","París","Zagreb","Búdapest","Dyflinni","Róm", ...
       "Vilníus","Lúxemborg","Ríga","Valletta","Amsterdam","Varsjá","Lissabon", ...
       "Búkarest","Stokkhólmur","Ljúbljana","Bratislava","Reykjavík"];
inc23 = arrayfun(@(k) stak(T, "radstofunartekjur_B6N_a_ibua", k, "2023"), OK2);
Pinc = rodun(OK2, ON2, inc23/1e3);            % raðað á ónámunduð gildi; birt með 1 aukastaf
M11 = [Mv; [tafla(Pinc, "tekjur_2023", 1), array2table(nan(28,2), 'VariableNames', {'bil_lag','bil_ha'})];
       {"tekjur_2023", 0, "meðaltal 27", round(mean(inc23(OK2~="IS01"))/1e3,1), NaN, NaN}];
skrifa(M11, fullfile(ut, 'm11.csv'));
R = bera(R, "K53a", "ráðstöfunartekjur Reykjavíkur 2023, USD (OECD IS01)", inc23(OK2=="IS01"), 32420.5, 0.05);
R = bera(R, "K53b", "sæti Reykjavíkur af 28 höfuðborgarsvæðum", find(Pinc.kodi=="IS01"), 21, 0);
R = bera(R, "K53c", "sama röð 2024, USD", stak(T,"radstofunartekjur_B6N_a_ibua","IS01","2024"), 35030.5, 0.05);
kco = T.rod == "leidrettingarstudull_hofudborg";
R = bera(R, "K54a", "leiðréttingarstuðull Reykjavíkur (Brussel=100)", ...
    stak(T,"leidrettingarstudull_hofudborg","IS_CAP","2025"), 142.3, 0.05);
R = bera(R, "K54b", "Reykjavík hæst höfuðborga í safninu (sæti af " + nnz(kco) + ")", ...
    1 + sum(T.gildi(kco) > stak(T,"leidrettingarstudull_hofudborg","IS_CAP","2025")), 1, 0);

%% ---- K55: tölur skýrslunnar sjálfrar (bein tilvitnun, aðeins bergmál) ----
sk = {"K55a","skyrsla_hagvoxtur","2,9 vs 1,6"; "K55b","skyrsla_laun","26 vs 26";
      "K55c","skyrsla_styrivextir_IS","7,5 vs 4,0"; "K55d","skyrsla_styrivextir_EA","2,0 vs 2,0";
      "K55e","skyrsla_skuldir","45 vs 84-88"; "K55f","skyrsla_atvinnuleysi","4,3 vs 6,0";
      "K55g","skyrsla_ungmenni","9 vs 15"; "K55h","skyrsla_verdlag","-28/-40/-73";
      "K55i","skyrsla_TFP","+34"; "K55j","skyrsla_flokt","9,2 vs 7,4";
      "K55k","skyrsla_laun_luxemborg","34"; "K55l","skyrsla_vlf_a_mann","52 þús. evrur PPS, 4. sæti";
      "K55m","skyrsla_ungmenni_saeti","þriðja lægsta"};
for j = 1:size(sk,1)
    R = skra(R, sk{j,1}, "tala skýrslunnar: " + sk{j,2}, H.gildi_str(H.rod==sk{j,2}), sk{j,3});
end

%% ---- utreikningar.txt og samantekt ----
fid = fopen(fullfile(ut, 'utreikningar.txt'), 'w', 'n', 'UTF-8');
fprintf(fid, "UTREIKNINGAR: hver tala greinarinnar gegn talnaskránni (talnaskra.csv)\n");
fprintf(fid, "Inntak: gogn/gagnagrunnur.csv + gogn/handvirk_gogn.csv. Vikmörk hverrar línu\n");
fprintf(fid, "eru hálf eining aftasta birta tugastafs (sæti og talningar: 0).\n");
fprintf(fid, "FRÁVIK eru skýrð í lýsingardálknum.\n");
fprintf(fid, "%s\n", repmat('-', 1, 110));
fprintf(fid, "%-6s %-72s %14s %14s %8s %s\n", "nr", "lýsing", "reiknað", "í grein", "vikmörk", "staða");
fprintf(fid, "%s\n", repmat('-', 1, 110));
n_ok = 0; n_fr = 0; fravik = strings(0,1);
for j = 1:size(R,1)
    fprintf(fid, "%-6s %-72s %14s %14s %8s %s\n", R{j,1}, R{j,2}, R{j,3}, R{j,4}, R{j,5}, R{j,6});
    if R{j,6} == "OK"; n_ok = n_ok + 1;
    else
        n_fr = n_fr + 1;
        fravik(end+1) = sprintf("%s: reiknað %s, í grein %s (%s)", R{j,1}, R{j,3}, R{j,4}, R{j,2}); %#ok<SAGROW>
    end
end
fprintf(fid, "%s\n", repmat('-', 1, 110));
% engin keyrslutíma-/tímastimpilslína í skránni sjálfri svo nidurstodur/ sé
% byte-identical milli keyrslna; tíminn er prentaður á stdout hér að neðan
fprintf(fid, "SAMTALS: %d línur, %d OK, %d FRÁVIK.\n", size(R,1), n_ok, n_fr);
if n_fr > 0
    fprintf(fid, "FRÁVIKIN:\n");
    for j = 1:numel(fravik); fprintf(fid, "  %s\n", fravik(j)); end
end
fclose(fid);
fprintf("utreikningar.txt: %d línur, %d OK, %d FRÁVIK (%s)\n", size(R,1), n_ok, n_fr, ...
    string(datetime("now", "Format", "d.M.yyyy HH:mm")));
for j = 1:numel(fravik); fprintf("  FRÁVIK %s\n", fravik(j)); end
fprintf("m-skrár og utreikningar.txt skrifað í %s\nKeyrslutími: %.0f sek.\n", ut, toc(klukka));

%% ================= Hjálparföll =================
function T = lesa(skra, nofn)                     % tidy-CSV með semíkommum, allt sem strengir
    o = delimitedTextImportOptions('NumVariables', numel(nofn), 'Delimiter', ';', ...
        'VariableNames', nofn, 'VariableTypes', repmat({'string'}, 1, numel(nofn)), ...
        'DataLines', 2, 'Encoding', 'UTF-8');
    T = readtable(skra, o);
end

function v = stak(T, rod, sv, t)                  % nákvæmlega eitt gildi, annars villa
    k = T.rod == rod & T.svaedi == sv & T.timi == t;
    assert(nnz(k) == 1, 'stak: %s %s %s -> %d línur', rod, sv, t, nnz(k));
    v = T.gildi(k);
end

function v = hstak(H, rod)                        % handvirkt stak, aðeins röð
    k = H.rod == rod;
    assert(nnz(k) == 1, 'hstak: %s -> %d línur', rod, nnz(k));
    v = H.gildi(k);
end

function v = hstak2(H, rod, sv, t)                % handvirkt stak eftir röð/svæði/tíma
    if nargin < 4; t = ""; end
    if nargin < 3; sv = ""; end
    k = H.rod == rod;
    if strlength(sv) > 0; k = k & H.svaedi == sv; end
    if strlength(t) > 0; k = k & H.timi == t; end
    if nnz(k) == 0 && strlength(sv) == 0          % ameco_zvgdf_2010 -> rod + ártal í heiti
        d = split(rod, "_"); k = H.rod == join(d(1:end-1), "_") & H.timi == d(end);
    end
    assert(nnz(k) == 1, 'hstak2: %s %s %s -> %d línur', rod, sv, t, nnz(k));
    v = H.gildi(k);
end

function pe = hpe(H, landsnafn)                   % vænt verðbólga lands; NaN ef spá vantar
    k = H.rod == "vaent_verdbolga" & (H.svaedi == landsnafn | ...
        (landsnafn == "Ísland óverðtr." & H.svaedi == "Ísland óverðtryggt"));
    if nnz(k) == 1; pe = H.gildi(k); else; pe = NaN; end
end

function g = tvo(H, rod)                          % "7,5 vs 4,0" -> [7.5 4.0]
    s = H.gildi_str(H.rod == rod);
    g = str2double(strrep(split(s, " vs "), ",", "."))';
end

function v = rad(T, rod, sv, fra, til)            % árleg runa, fullyrt að ekkert ár vanti
    k = T.rod == rod & T.svaedi == sv;
    ar = double(T.timi(k)); g = T.gildi(k);
    m = ar >= fra & ar <= til;
    assert(nnz(m) == til - fra + 1, 'rad: %s %s vantar ár á %d-%d', rod, sv, fra, til);
    [~, i] = sort(ar(m)); g = g(m); v = g(i)';
end

function m = medal(T, rod, sv, fra, til)          % einfalt meðaltal árlegra gilda
    m = mean(rad(T, rod, sv, fra, til));
end

function v = radmedal(T, rod, kodar, fra, til)    % meðaltal fyrir hvert land
    v = arrayfun(@(k) medal(T, rod, k, fra, til), kodar);
end

function v = radstak(T, rod, kodar, t)            % stakt gildi fyrir hvert land
    v = arrayfun(@(k) stak(T, rod, k, t), kodar);
end

function P = rodun(kodar, nofn, gildi, jafnt)     % raðað fallandi; jafntefli á kóða
    % jafnt = "heiti_ofug": jafntefli brotið á heiti lands í öfugri stafrófsröð
    % (röð birtu myndarinnar M2 á heiltölukvarða tec00114);
    % jafnt = "haekkandi": raðað hækkandi (M10: lægstu skuldir fyrst);
    % annars fallandi með jafntefli á landakóða. Alltaf raðað á ónámunduð gildi.
    if nargin < 4; jafnt = "kodi"; end
    P = table(kodar(:), nofn(:), gildi(:), 'VariableNames', {'kodi','land','gildi'});
    if jafnt == "heiti_ofug"
        P = sortrows(P, {'gildi','land'}, {'descend','descend'});
    elseif jafnt == "haekkandi"
        P = sortrows(P, {'gildi','kodi'}, {'ascend','ascend'});
    else
        P = sortrows(P, {'gildi','kodi'}, {'descend','ascend'});
    end
    P.saeti = (1:height(P))';
end

function M = tafla(P, spjald, aukastafir)         % spjald -> úttaksform m-skránna
    M = table(repmat(string(spjald), height(P), 1), P.saeti, P.land, ...
        round(P.gildi, aukastafir), 'VariableNames', {'spjald','saeti','land','gildi'});
end

function skrifa(M, skra)
    writetable(M, skra, 'FileType', 'text', 'Delimiter', ';', 'Encoding', 'UTF-8', ...
        'QuoteStrings', 'minimal');
end

function [dags, vol] = flokt(T, rod)              % 30 daga flökt á ársgrundvelli, %
    k = T.rod == rod;
    [dstr, i] = sort(T.timi(k)); g = T.gildi(k); g = g(i);
    r = diff(log(g));
    vol = movstd(r, [29 0], 0) * sqrt(252) * 100;  % úrtaksstaðalfrávik, 30 síðustu breytingar
    dags = dstr(2:end);
    vol = vol(30:end); dags = dags(30:end);        % fyrstu 29 gluggar ófullir
end

function m = gluggamedal(dags, vol, fra, til)     % meðaltal flökts yfir almanaksglugga
    ar = double(extractBefore(dags, 5));
    m = mean(vol(ar >= fra & ar <= til));
end

function R = bera(R, merki, lysing, reiknad, grein, vik)   % talnasamanburður
    if abs(reiknad - grein) <= vik + 1e-9; st = "OK"; else; st = "FRÁVIK"; end
    R(end+1, :) = {string(merki), string(lysing), isl(reiknad), isl(grein), isl(vik), st};
end

function R = skra(R, merki, lysing, reiknad, grein)        % textasamanburður (bergmál)
    if string(reiknad) == string(grein); st = "OK"; else; st = "FRÁVIK"; end
    R(end+1, :) = {string(merki), string(lysing), string(reiknad), string(grein), "-", st};
end

function s = isl(v)                               % tala með tugstafskommu, hófleg nákvæmni
    if abs(v - round(v)) < 1e-9; s = sprintf('%d', round(v));
    elseif abs(v) >= 1000; s = strrep(sprintf('%.1f', v), '.', ',');
    else; s = strrep(sprintf('%.4g', v), '.', ',');
    end
end
