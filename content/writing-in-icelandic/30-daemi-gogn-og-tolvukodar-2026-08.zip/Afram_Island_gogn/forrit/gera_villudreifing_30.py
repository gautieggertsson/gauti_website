# -*- coding: utf-8 -*-
"""Yfirlitsmynd Viðauka B (villudreifing_30.png): annmarkar greiningar Áfram Íslands,
flokkaðir eftir tegund, og tegundirnar raðaðar eftir alvarleika eins og greinin
sjálf lýsir því stigveldi.

Hlaupandi númer 1-30 svara til upptalningarinnar í Viðauka B, þar sem hvert
atriði er rakið til blaðsíðu í greinargerð greiningarinnar; blaðsíðutal er líka
í athugasemdum hér að neðan. Fimm undirflokkar hagstæðs vals fylgja prentuðum
merkjum Töflu 2 í greininni, að því frátöldu að verðlag og neysla eru hér færð í
flokk misnotkunar gagna og aðferða, eins og greinin rökstyður, og bera ekki
valmerki. Númer 1-11 eru föst auðkenni sem taflan og millifyrirsagnir
greinarinnar vísa í. Inntakið (atriðin þrjátíu, flokkar og merkingar) er skráð
í forritinu sjálfu.

Keyrsla: python3 gera_villudreifing_30.py; myndin skrifast í ../endurgerd/villudreifing_30.png
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

INK = "#15232B"
MUTED = "#5C6970"
NAVY = "#123A52"
RED = "#B83A32"
GRID = "#CBD5D9"
PALE = "#EEF3F4"
VAL = "#4878A8"

# Dálkar: (heiti, litur). Fimm fyrstu eru undirflokkar hagstæðs vals; hinir raðast eftir alvarleika.
COLS = [
    ("Nefnari", VAL),
    ("Heiti\nstærðar", VAL),
    ("Tímabil", VAL),
    ("Samanburðar-\nhópur", VAL),
    ("Breytuval", VAL),
    ("Framsetning\nvantar/röng", "#D79A2B"),
    ("Fullyrt\ná suði", "#7B5EA7"),
    ("Innra\nósamræmi", "#0E6C73"),
    ("Misnotkun\ngagna", "#C2642E"),
    ("Reiknivilla,\ntala án\nheimildar", "#B83A32"),
    ("Útlagi\nlátinn ráða", "#6E1A14"),
]
N, H, T, HO, B, FR, SU, IO, MIS, BV, UT = range(11)

# Flokkar í alvarleikaröð (ofan frá og niður = vinstri til hægri á dálkunum)
GROUPS = [
    ("VAL", "Hagstætt val (vægast)"),
    ("FR", "Framsetningargallar"),
    ("SU", "Fullyrt á suði"),
    ("IO", "Innra ósamræmi"),
    ("MIS", "Misnotkun gagna og aðferða"),
    ("BV", "Reiknivillur og tölur án heimildar"),
    ("UT", "Grófasta villan"),
]
ORDER = [g for g, _ in GROUPS]

# (flokkur, heiti, {dálkar}, gegn_islandi, númer í grein eða None)
ROWS = [
    ("VAL", "Hagvöxtur: heildin, ekki á mann", {N}, False, 1),                        # bls. 7, 9-10
    ("VAL", "Skuldir: ESB-heildin, blandaðar útgáfur", {T, HO}, False, 3),            # bls. 7, 41-42
    ("VAL", "Vextir: raunvextir aldrei reiknaðir", {H}, False, 4),                    # bls. 7, 42-44
    ("VAL", "Ungmenni: deilt með unga vinnuaflinu", {N}, False, None),                # bls. 7, 15-16, 45
    ("VAL", "Framleiðni: aðeins tvö meðaltöl sýnd", {HO}, False, 5),                  # bls. 7, 46
    ("VAL", "Samkeppnishæfni: veikasti þátturinn felldur út", {HO}, False, 6),        # bls. 7, 47-48
    ("VAL", "Kaupmáttarvöxtur: „+68%“ á þremur valkostum", {T, H, N, B}, False, 7),   # bls. 7, 49-52
    ("VAL", "Launastig: evrur í stað kaupmáttar", {H, N, B}, False, 8),               # bls. 7, 19-23, 55-56
    ("VAL", "Krónan: dalur, höft og aðrar myntir", {T, HO, B}, False, 10),            # bls. 8, 58-59
    ("FR", "„+12/+7%“: falið undirtímabil", {FR}, False, None),                       # bls. 46
    ("FR", "Lofuð 2025-áætlun aldrei birt", {FR}, False, None),                       # bls. 51
    ("FR", "Norræna línan endar þegjandi 2022", {FR}, False, None),                   # bls. 51-52
    ("FR", "„Vergar“ tekjur: rangt hugtaksheiti", {FR}, False, None),                 # bls. 51
    ("FR", "IMD-mynd: sæti merkt sem prósentur", {FR}, False, None),                  # bls. 48
    ("FR", "Fátæktargögn frá 2020 án aldursmerkingar", {FR}, False, None),            # bls. 54
    ("FR", "Atvinnuleysi: nýjasta staða ekki sýnd", {FR}, False, None),               # bls. 53-54
    ("FR", "„Á mann“: röng eining á tekjuröð", {FR}, False, None),                    # bls. 58
    ("FR", "Jöfnuður í fyrirsögn, enginn mælikvarði", {FR}, False, None),             # bls. 54
    ("SU", "„Hvergi minni“: 0,2 stig á gömlum gögnum", {SU}, False, None),            # bls. 54
    ("SU", "Þrír „veikir hópar“: enginn stenst", {SU}, False, None),                  # bls. 54
    ("IO", "Vinnustundir: notaðar og hafnað", {IO}, False, None),                     # bls. 8, 27, 56
    ("IO", "Verðvísaskipti: sami bati talinn tvisvar", {IO}, False, None),            # bls. 27, 30, 58
    ("IO", "Vinnutekjur: sjálfstætt starfandi utan summu", {N, IO}, False, None),     # bls. 8, 22-23, 27
    ("MIS", "Verðlag: verð deilt með tekjum og kallað verðlag", {MIS}, False, 2),     # bls. 7, 39-41; verðlagsgreinin
    ("MIS", "Neysla: verðlag fisks og áls, ekki heimilanna", {MIS}, False, 9),        # bls. 8, 24-25, 55
    ("BV", "Skuldasíða: tveimur AGS-útgáfum blandað", {BV}, False, None),             # bls. 13, 42
    ("BV", "20 ára súlur: 19 ár reiknuð sem 20", {BV}, True, None),                   # bls. 50 - GEGN Íslandi
    ("BV", "Ráðstöfunartekjur: gögn hliðruð um ár", {BV}, False, None),               # bls. 51-52
    ("BV", "Ungverjaland: talan 70 á sér enga heimild", {BV}, False, None),           # bls. 54
    ("UT", "OECD-talan: útlagi látinn fella rétta niðurstöðu", {UT}, False, 11),      # bls. 22, 55-56; [9]
]


def build(rows, outfile, title, subtitle):
    rows = sorted(rows, key=lambda r: ORDER.index(r[0]))
    nrows, ncols = len(rows), len(COLS)
    ngroups = len({r[0] for r in rows})
    col_tot = [sum(1 for r in rows if c in r[2]) for c in range(ncols)]

    fig_h = 4.4 + (nrows + (ngroups - 1) * 0.8) * 0.315
    fig, ax = plt.subplots(figsize=(13.4, fig_h), dpi=200)
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")

    # dálkaheiti og súlur efst (fjöldi atriða í hverri tegund)
    head_y = nrows + (ngroups - 1) * 0.8 + 0.55
    bar_base = head_y + 0.35
    bar_scale = 2.4 / max(col_tot)
    for c, (label, color) in enumerate(COLS):
        h = col_tot[c] * bar_scale
        ax.add_patch(Rectangle((c - 0.32, bar_base), 0.64, h, color=color, alpha=0.85, zorder=3))
        ax.text(c, bar_base + h + 0.12, str(col_tot[c]), ha="center", va="bottom",
                fontsize=11, fontweight="bold", color=INK)
        ax.text(c, head_y, label, ha="center", va="top", fontsize=8.7, color=INK)

    # svigi yfir undirflokka valsins og ör fyrir vaxandi alvarleika
    brk_y = bar_base + 2.4 + 0.75
    ax.plot([N - 0.4, B + 0.4], [brk_y, brk_y], color=VAL, lw=1.4, zorder=3)
    ax.plot([N - 0.4, N - 0.4], [brk_y, brk_y - 0.22], color=VAL, lw=1.4, zorder=3)
    ax.plot([B + 0.4, B + 0.4], [brk_y, brk_y - 0.22], color=VAL, lw=1.4, zorder=3)
    ax.text((N + B) / 2, brk_y + 0.15, "Hagstætt val: hvað var valið Íslandi í vil",
            ha="center", va="bottom", fontsize=9.2, color=VAL, fontweight="bold")
    ax.annotate("", xy=(UT + 0.4, brk_y), xytext=(FR - 0.4, brk_y),
                arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=1.3, mutation_scale=14))
    ax.text((FR + UT) / 2, brk_y + 0.15, "alvarleiki eykst",
            ha="center", va="bottom", fontsize=9.2, color=MUTED, fontweight="bold")

    # línur og punktar
    y = float(nrows - 1) + (ngroups - 1) * 0.8
    last_group = None
    ymid = {}
    stripe = 0
    running = 0
    names = dict(GROUPS)
    for g, label, cols, gegn, num in rows:
        if g != last_group:
            if last_group is not None:
                ax.axhline(y + 0.55, color=GRID, lw=1.2, zorder=1)
                y -= 0.8
            ax.text(-1.25, y + 0.62, names[g], ha="right", va="center",
                    fontsize=10.4, fontweight="bold", color=NAVY)
            last_group = g
        if stripe % 2 == 1:
            ax.add_patch(Rectangle((-7.0, y - 0.5), ncols + 6.5, 1, color=PALE, zorder=0))
        stripe += 1
        ax.text(-1.25, y, label, ha="right", va="center", fontsize=10.0, color=INK)
        running += 1
        ax.text(-6.55, y, f"{running}.", ha="right", va="center", fontsize=10.0,
                fontweight="bold", color=INK)
        if num is not None:
            ax.text(-0.62, y, f"({num})", ha="right", va="center", fontsize=9.0,
                    fontweight="bold", color=NAVY)
        for c in range(ncols):
            if c in cols:
                if gegn:
                    ax.scatter([c], [y], s=150, facecolors="white", edgecolors=RED,
                               linewidths=2.2, zorder=4)
                else:
                    ax.scatter([c], [y], s=150, color=COLS[c][1], zorder=4)
            else:
                ax.scatter([c], [y], s=13, color=GRID, zorder=2)
        ymid[label] = y
        y -= 1

    # merking við reiknivilluna sem hallar gegn Íslandi
    for g, label, cols, gegn, num in rows:
        if gegn:
            ax.annotate("eina hreina reiknivillan, og hún er Íslandi í óhag",
                        xy=(BV - 0.22, ymid[label]), xytext=(BV - 0.75, ymid[label]),
                        fontsize=9.0, color=RED, va="center", ha="right",
                        arrowprops=dict(arrowstyle="-", color=RED, lw=0.9))

    ax.set_xlim(-7.1, ncols - 0.3)
    ax.set_ylim(-0.8, brk_y + 0.9)
    ax.axis("off")

    fig.suptitle(title, x=0.02, y=0.995, ha="left", fontsize=16.5,
                 fontweight="bold", color=INK)
    fig.text(0.02, 0.948, subtitle, ha="left", fontsize=10, color=MUTED)
    fig.text(0.02, 0.008,
             "Númer 1–30 svara til upptalningarinnar í Viðauka B, þar sem hvert atriði er rakið til blaðsíðu; "
             "númer í sviga (1–11) eru föstu auðkennin í Töflu 2 og yfirlitsgrein höfundar. Undirflokkar valsins fylgja Töflu 2.",
             ha="left", fontsize=8, color=MUTED)

    fig.subplots_adjust(top=0.905, bottom=0.035, left=0.005, right=0.995)
    fig.savefig(outfile, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(outfile, f"({len(rows)} atriði, {sum(col_tot)} punktar, dálkar: {col_tot})")


if __name__ == "__main__":
    import os
    ut = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "endurgerd")
    os.makedirs(ut, exist_ok=True)
    build(ROWS, os.path.join(ut, "villudreifing_30.png"),
          "30 dæmi um villandi framsetningu, frá hagstæðu vali til grófustu villu: nær öll sýna Ísland í fegurra ljósi",
          "Hver lína er skjalfest dæmi, hver dálkur tegund; tegundirnar raðast eftir alvarleika, "
          "frá vinstri til hægri og ofan frá og niður.\n"
          "Hlaupandi númer 1–30 fylgja upptalningunni í Viðauka B; númer í sviga eru föstu auðkennin 1–11.")
