function run_all(hamur)
%% run_all.m: heildarkeyrsla gagnapakkans (sjá README.md)
% run_all eða run_all('frozen'): endurgerir allar niðurstöður og myndir greinarinnar
%   úr frosnu gögnunum í gogn/, án nets og án gagnaöflunar:
%     forrit/reikna_nidurstodur.m   nidurstodur/m*.csv + nidurstodur/utreikningar.txt
%     forrit/gera_myndir.m          endurgerd/*.pdf
% run_all('refresh'): sækir fyrst öll gögn að nýju (krefst nets og sækjaranna, sem
%   fylgja ekki pakkanum), ber nýja gagnagrunninn saman við þann frosna og prentar
%   endurskoðunarskýrslu (gagnasafn; breyttar, nýjar og brottfallnar línur; mesta
%   breyting), reiknar svo og teiknar úr nýju gögnunum. Skrifar yfir gogn/*.csv og gogn/hra/.
% Í lokin er prentuð samantekt: myndir skrifaðar og OK/FRÁVIK-talning úr
% nidurstodur/utreikningar.txt.
% Keyrsla frá rót pakkans:  matlab -batch "addpath('forrit'); run_all"   (R2024b)

if nargin < 1; hamur = 'frozen'; end
assert(any(strcmp(hamur, {'frozen','refresh'})), 'hamur er ''frozen'' eða ''refresh''');
klukka = tic;
rot = fileparts(fileparts(mfilename('fullpath')));   % rót pakkans
forrit = fullfile(rot, 'forrit');
addpath(forrit);
grunnur = fullfile(rot, 'gogn', 'gagnagrunnur.csv');

%% ---- refresh: sækja að nýju og bera saman við frosna grunninn ----
if strcmp(hamur, 'refresh')
    fprintf('==== run_all(''refresh''): sæki öll gögn að nýju ====\n');
    F = lesa_grunn(grunnur);                          % frosni grunnurinn, í minni
    keyra_skrift(fullfile(forrit, 'saekja_gogn.m'));  % skrifar nýjan gagnagrunn
    N = lesa_grunn(grunnur);
    endurskodun(F, N);
end

%% ---- Reikna og teikna ----
t0 = datetime('now');
keyra_skrift(fullfile(forrit, 'reikna_nidurstodur.m'));
keyra_skrift(fullfile(forrit, 'gera_myndir.m'));

%% ---- Samantekt ----
d = dir(fullfile(rot, 'endurgerd', '*.pdf'));
nyjar = {d([d.datenum] >= convertTo(t0, 'datenum') - 1/86400).name};
txt = fileread(fullfile(rot, 'nidurstodur', 'utreikningar.txt'), 'Encoding', 'UTF-8');
tal = regexp(txt, 'SAMTALS: (\d+)[^,]*, (\d+) OK, (\d+)', 'tokens', 'once');
assert(~isempty(tal), 'fann ekki SAMTALS-línuna í utreikningar.txt');
fprintf('\n==== run_all(''%s'') lokið ====\n', hamur);
fprintf('Myndir: %d skrifaðar í endurgerd/ (%s)\n', numel(nyjar), ...
    strjoin(erase(sort(string(nyjar)), '.pdf'), ', '));
fprintf('Útreikningar: %s línur, %s OK, %s FRÁVIK (sjá nidurstodur/utreikningar.txt)\n', tal{:});
fprintf('Keyrslutími: %.0f sek.\n', toc(klukka));
end

%% ================= Hjálparföll =================
function keyra_skrift(keyrsluskra)
% Keyrir skriftu í einangruðu vinnusvæði (skriftur pakkans mega hreinsa það að vild)
run(keyrsluskra);
end

function T = lesa_grunn(slodin)                   % tidy-CSV með semíkommum, allt sem strengir
o = delimitedTextImportOptions('NumVariables', 8, 'Delimiter', ';', ...
    'VariableNames', {'rod','svaedi','timi','gildi','eining','gagnasafn','api_slod','sott_dags'}, ...
    'VariableTypes', repmat({'string'}, 1, 8), 'DataLines', 2, 'Encoding', 'UTF-8');
T = readtable(slodin, o);
end

function endurskodun(F, N)
% Endurskoðunarskýrsla: nýi grunnurinn borinn saman við þann frosna, eftir gagnasafni.
% Lína telst breytt sé tölugildið annað á sama lykli (rod;svaedi;timi); nýjar og
% brottfallnar línur eru taldar sér. Mesta breyting er hámark |nýtt - frosið|.
lf = F.rod + ";" + F.svaedi + ";" + F.timi;   gf = str2double(F.gildi);
ln = N.rod + ";" + N.svaedi + ";" + N.timi;   gn = str2double(N.gildi);
[~, jf, jn] = intersect(lf, ln);              % sameiginlegir lyklar
delta = gn(jn) - gf(jf);
safn = union(unique(F.gagnasafn), unique(N.gagnasafn));
fprintf('\n---- Endurskoðunarskýrsla: nýr gagnagrunnur á móti frosnum ----\n');
fprintf('%-34s %8s %8s %8s %14s\n', 'gagnasafn', 'breytt', 'nýtt', 'brott', 'mesta breyting');
alls = [0 0 0];
for i = 1:numel(safn)
    kf = F.gagnasafn(jf) == safn(i);          % sameiginlegar línur safnsins
    br = sum(abs(delta(kf)) > 5e-10);
    ny = sum(N.gagnasafn == safn(i)) - sum(kf);
    bt = sum(F.gagnasafn == safn(i)) - sum(kf);
    if br == 0; mb = "-"; else; mb = sprintf('%.6g', max(abs(delta(kf)))); end
    fprintf('%-34s %8d %8d %8d %14s\n', safn(i), br, ny, bt, mb);
    alls = alls + [br ny bt];
end
fprintf('%-34s %8d %8d %8d\n', 'ALLS', alls);
if sum(alls) == 0
    fprintf('Engin breyting: nýi grunnurinn er samhljóða þeim frosna.\n');
else
    fprintf('ATH: %d línur breyttar/nýjar/brottfallnar; birtar tölur greinarinnar\n', sum(alls));
    fprintf('kunna að hliðrast; berið nidurstodur/utreikningar.txt saman við fyrri gerð.\n');
end
end
