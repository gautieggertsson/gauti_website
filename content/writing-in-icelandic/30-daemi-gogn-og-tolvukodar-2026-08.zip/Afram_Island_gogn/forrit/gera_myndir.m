%% gera_myndir.m
% Myndir greinarinnar „Ísland er í efstu deild Evrópu ásamt fremstu ríkjum ESB,
% en á stór sóknarfæri“ (Gauti B. Eggertsson, 2026), teiknaðar úr frystum
% gögnum. Tölugildin eru skráð í forritinu sjálfu og rakin til heimilda í
% Viðauka A greinarinnar; talnaskráin (talnaskra.csv) og útreikningarnir í
% nidurstodur/utreikningar.txt prófa sömu tölur gegn gagnagrunninum.
% Vaxtamyndirnar þrjár, verðlagsmyndin og IMD-myndin eru sóttar í frystu
% lokagerðirnar í lokagerdgogn/ og afritaðar í úttaksmöppuna.
%
% Keyrsla frá rót pakkans:  matlab -batch "run('forrit/gera_myndir.m')"  (R2024b)
% Úttak: endurgerd/*.pdf (verður til við keyrslu); berið saman við myndir/.

clear; close all;
ROT = fileparts(fileparts(mfilename('fullpath')));
OUT = fullfile(ROT, 'endurgerd');
if ~exist(OUT, 'dir'); mkdir(OUT); end

GRAY = [168 166 158]/255; BLUE = [42 120 214]/255; RED = [192 57 43]/255;
INK  = [26 26 26]/255;    MUT  = [107 107 107]/255;
set(groot, 'DefaultAxesFontName', 'Helvetica', 'DefaultTextFontName', 'Helvetica');

%% ---- M1: Hagvöxtur, 5/10/20 ára meðaltöl (framsetning skýrslunnar) vs á mann ----
% dálkar: land, 5 ára, 10 ára, 20 ára meðaltal heildarhagvaxtar til 2025; raðað eftir 10 ára
agg3 = {'Írland',6.62,6.41,5.20;'Malta',7.34,6.16,5.33;'Kýpur',6.28,5.28,2.92;
 'Pólland',3.84,3.62,3.76;'Króatía',6.18,3.54,1.93;'Litáen',3.10,3.24,3.02;
 'Rúmenía',2.74,3.06,2.99;'Búlgaría',4.02,2.88,2.67;'Slóvenía',3.26,2.83,2.02;
 'Ísland',3.82,2.80,2.27;'Ungverjaland',2.36,2.47,1.74;'Danmörk',3.08,2.34,1.52;
 'Portúgal',3.96,2.25,1.05;'Spánn',4.38,2.12,1.32;'Tékkland',2.14,1.96,2.02;
 'Slóvakía',2.20,1.96,2.94;'Holland',2.68,1.93,1.54;'Eistland',0.98,1.81,1.82;
 'Lettland',2.00,1.75,1.79;'Grikkland',4.10,1.72,-0.12;'Lúxemborg',1.38,1.70,2.10;
 'Svíþjóð',1.96,1.63,1.77;'Belgía',2.80,1.62,1.47;'Frakkland',2.70,1.27,1.15;
 'Austurríki',1.90,1.19,1.20;'Ítalía',3.18,1.10,0.31;'Finnland',0.78,0.98,0.74;
 'Þýskaland',0.90,0.75,1.12};
% Sömu gluggar fyrir hagvöxt á mann; raðað eftir 10 ára meðaltali.
pc3 = {'Írland',4.84,4.78,3.76;'Króatía',6.34,4.23,2.47;'Kýpur',4.46,3.83,1.43;
 'Pólland',3.72,3.77,3.86;'Búlgaría',4.44,3.75,3.62;'Rúmenía',3.00,3.46,3.56;
 'Litáen',2.54,3.34,3.76;'Malta',4.74,3.31,3.42;'Ungverjaland',2.68,2.76,2.04;
 'Lettland',2.70,2.51,2.80;'Slóvenía',2.96,2.50,1.70;'Grikkland',4.38,1.97,0.07;
 'Slóvakía',2.22,1.89,2.87;'Portúgal',3.12,1.84,0.92;'Danmörk',2.48,1.77,0.99;
 'Tékkland',1.44,1.60,1.70;'Spánn',3.54,1.49,0.70;'Eistland',0.36,1.39,1.77;
 'Ítalía',3.38,1.34,0.24;'Holland',1.90,1.25,1.02;'Belgía',2.14,1.06,0.82;
 'Frakkland',2.32,0.87,0.68;'Ísland',1.84,0.86,0.83;'Svíþjóð',1.34,0.75,0.91;
 'Finnland',0.34,0.67,0.37;'Austurríki',1.28,0.54,0.63;'Þýskaland',0.58,0.50,0.98;
 'Lúxemborg',-0.30,-0.19,0.14};
G5 = [201 199 192]/255; G10 = GRAY; G20 = [123 121 115]/255;
R5 = [226 148 138]/255; R10 = RED;  R20 = [140 30 20]/255;
B5 = [159 195 238]/255; B10 = BLUE; B20 = [25 77 145]/255;
fig = nyfig(8.6, 8.8);
axL = axes(fig, 'Position', [0.135 0.05 0.30 0.875]); hold(axL, 'on');
n = size(agg3,1); maxL1 = 8.2; hndL = gobjects(1,3); yL = []; xLisl = 0;
for i = 1:n
    y = n - i + 1;
    ice = strcmp(agg3{i,1}, 'Ísland');
    vals = [agg3{i,2} agg3{i,3} agg3{i,4}];
    offs = [0.28 0 -0.28];
    cols = {G5, G10, G20}; if ice; cols = {R5, R10, R20}; end
    for k = 1:3
        b = barh(axL, y+offs(k), max(vals(k),0), 0.24, 'FaceColor', cols{k}, 'EdgeColor','none');
        if i == 1; hndL(k) = b; end
    end
    text(axL, -maxL1*0.015, y, sprintf('%d. %s', i, agg3{i,1}), 'HorizontalAlignment','right', ...
        'FontSize', tern(ice,7.6,7.0), 'Color', tern(ice,RED,INK), ...
        'FontWeight', tern(ice,'bold','normal'), 'Clipping','off');
    text(axL, max(vals(2),0)+maxL1*0.012, y, isl(vals(2),2), 'FontSize', tern(ice,7.2,6.0), ...
        'Color', tern(ice,RED,MUT), 'FontWeight', tern(ice,'bold','normal'), 'Clipping','off');
    if ice; yL = y; xLisl = vals(2) + maxL1*0.055; end
end
xline(axL, 1.61, '--', 'Color', INK, 'LineWidth', 0.9, 'Alpha', 0.6);
text(axL, 1.61, n+1.15, 'ESB-27: 1,61 (10 ár)', 'FontSize',6.6, 'Color',MUT, 'Clipping','off');
xlim(axL, [0 maxL1]); ylim(axL, [0.3 n+1.6]);
snyrta(axL, sprintf('Áfram Ísland:\nHagvöxtur, 5, 10 og 20 ár'), ...
    '% á ári; raðað eftir 10 ára meðaltali', INK, MUT);
legend(axL, hndL, {'5 ár','10 ár','20 ár'}, 'Box','off', 'FontSize',7, 'Location','southeast');
axR = axes(fig, 'Position', [0.665 0.05 0.30 0.875]); hold(axR, 'on');
maxR1 = 7.0; hndR = gobjects(1,3); yR = [];
for i = 1:n
    y = n - i + 1;
    ice = strcmp(pc3{i,1}, 'Ísland');
    vals = [pc3{i,2} pc3{i,3} pc3{i,4}];
    offs = [0.28 0 -0.28];
    cols = {B5, B10, B20}; if ice; cols = {R5, R10, R20}; end
    for k = 1:3
        b = barh(axR, y+offs(k), max(vals(k),0), 0.24, 'FaceColor', cols{k}, 'EdgeColor','none');
        if i == 1; hndR(k) = b; end
    end
    text(axR, -maxR1*0.015, y, sprintf('%d. %s', i, pc3{i,1}), 'HorizontalAlignment','right', ...
        'FontSize', tern(ice,7.6,7.0), 'Color', tern(ice,RED,INK), ...
        'FontWeight', tern(ice,'bold','normal'), 'Clipping','off');
    text(axR, max(vals(2),0)+maxR1*0.012, y, isl(vals(2),2), 'FontSize', tern(ice,7.2,6.0), ...
        'Color', tern(ice,RED,MUT), 'FontWeight', tern(ice,'bold','normal'), 'Clipping','off');
    if ice; yR = y; end
end
xline(axR, 1.39, '--', 'Color', INK, 'LineWidth', 0.9, 'Alpha', 0.6);
text(axR, 1.39, n+1.15, 'ESB-27: 1,39 (10 ár)', 'FontSize',6.6, 'Color',MUT, 'Clipping','off');
xlim(axR, [0 maxR1]); ylim(axR, [0.3 n+1.6]);
snyrta(axR, sprintf('Hefðbundin framsetning:\nHagvöxtur á mann, 5, 10 og 20 ár'), ...
    '% á ári; raðað eftir 10 ára meðaltali', INK, MUT);
legend(axR, hndR, {'5 ár','10 ár','20 ár'}, 'Box','off', 'FontSize',7, 'Location','southeast');
pila(fig, axL, axR, yL, yR, '10. \rightarrow 23. sæti', RED, xLisl);
exportgraphics(fig, fullfile(OUT,'m1_hagvoxtur.pdf'), 'ContentType','vector'); close(fig);

%% ---- M2: VLF á mann vs á hvern starfandi ----
gdppc = {'Lúxemborg',244;'Írland',221;'Holland',134;'Ísland',131;'Danmörk',127;
 'Austurríki',119;'Belgía',117;'Þýskaland',116;'Svíþjóð',112;'Malta',110;
 'Finnland',102;'Kýpur',99;'Ítalía',98;'Frakkland',98;'Spánn',91;'Tékkland',90;
 'Slóvenía',90;'Litáen',87;'Portúgal',82;'Pólland',79;'Eistland',79;'Króatía',78;
 'Rúmenía',77;'Ungverjaland',76;'Slóvakía',75;'Lettland',69;'Grikkland',68;'Búlgaría',66};
gdpw = {'Írland',209.6;'Lúxemborg',156.2;'Belgía',131.5;'Danmörk',117.1;'Holland',113.1;
 'Austurríki',112.1;'Ísland',110.9;'Frakkland',107.4;'Svíþjóð',106.4;'Ítalía',105.5;
 'Þýskaland',102.4;'Finnland',101.7;'Spánn',98.3;'Malta',93.4;'Kýpur',92.1;
 'Tékkland',88.1;'Slóvenía',84.6;'Króatía',82.8;'Rúmenía',82.7;'Pólland',82.4;
 'Litáen',81.9;'Slóvakía',81.4;'Portúgal',81.2;'Eistland',76.4;'Ungverjaland',73.9;
 'Lettland',68.7;'Grikkland',67.6;'Búlgaría',58.6};
% VLF á hvern 25-54 ára („prime age", skilgr. BLS): nama_10_gdp CP_MPPS /
% demo_pjan 25-54 ára (meðaltal 1.1.2024 og 1.1.2025), vísitala ESB-27=100
gdprime = {'Lúxemborg',210;'Írland',207;'Holland',135;'Danmörk',132;'Ísland',121;
 'Þýskaland',119;'Belgía',117;'Austurríki',115;'Svíþjóð',113;'Finnland',105;
 'Frakkland',104;'Ítalía',101;'Slóvenía',89;'Malta',87;'Kýpur',87;
 'Spánn',86;'Tékkland',85;'Litáen',84;'Portúgal',83;'Króatía',78;
 'Eistland',76;'Rúmenía',74;'Pólland',74;'Ungverjaland',71;'Grikkland',70;
 'Lettland',68;'Slóvakía',68;'Búlgaría',66};
fig = nyfig(12.6, 7.6);
ax1 = axes(fig, 'Position', [0.085 0.05 0.19 0.875]);
y1 = spjald(ax1, gdppc, GRAY, sprintf('Áfram Ísland:\nLandsframleiðsla á mann'), ...
 'Árið 2024, PPS (ESB=100): Ísland í 4. sæti', 258, 100, 'ESB-27 = 100', 0, ...
 {'Írland','Lúxemborg'}, RED, INK, MUT);
ax2 = axes(fig, 'Position', [0.415 0.05 0.19 0.875]);
y2 = spjald(ax2, gdprime, BLUE, sprintf('Án aldurssamsetningar:\ná hvern 25–54 ára (prime age)'), ...
 'Árið 2024, PPS: Ísland í 5. sæti', 258, 100, 'ESB-27 = 100', 0, ...
 {'Írland','Lúxemborg'}, RED, INK, MUT);
ax3 = axes(fig, 'Position', [0.745 0.05 0.19 0.875]);
y3 = spjald(ax3, gdpw, BLUE, sprintf('Án atvinnustigs:\ná hvern starfandi'), ...
 'Árið 2024, PPS: Ísland í 7. sæti', 232, 100, 'ESB-27 = 100', 1, ...
 {'Írland','Lúxemborg'}, RED, INK, MUT);
pila(fig, ax1, ax2, y1, y2, '4. \rightarrow 5. sæti', RED, 131 + 258*0.055);
pila(fig, ax2, ax3, y2, y3, '5. \rightarrow 7. sæti', RED, 121 + 258*0.055);
exportgraphics(fig, fullfile(OUT,'m2_vlf_starfandi.pdf'), 'ContentType','vector'); close(fig);

%% ---- M3: Framleiðni, þrjár raðir skýrslunnar vs öll ríkin frá 2000 ----
prod00 = {'Rúmenía',204.2;'Lettland',149.7;'Írland',148.7;'Litáen',138.1;'Pólland',110.3;
 'Slóvakía',108.6;'Búlgaría',103.3;'Eistland',97.5;'Ungverjaland',70.4;'Tékkland',66.0;
 'Malta',59.9;'Slóvenía',55.7;'Króatía',53.8;'Ísland',52.0;'Kýpur',35.1;'Svíþjóð',33.8;
 'Danmörk',31.8;'Austurríki',27.2;'Þýskaland',22.1;'Finnland',21.5;'Portúgal',20.1;
 'Spánn',19.4;'Belgía',17.8;'Holland',17.6;'Frakkland',17.3;'Grikkland',5.6;
 'Ítalía',-0.3;'Lúxemborg',-2.3};
fig = nyfig(8.6, 7.6);
axL = axes(fig, 'Position', [0.135 0.05 0.30 0.875]);
his = {'Ísland',52.0;'Norðurlöndin í ESB',29.1;'ESB-27',27.0};
ysh = [22 18 14]; hold(axL, 'on');
for i = 1:3
    ice = i == 1;
    c = GRAY; if ice; c = RED; end
    barh(axL, ysh(i), his{i,2}, 2.6, 'FaceColor', c, 'EdgeColor', 'none');
    text(axL, -2, ysh(i), his{i,1}, 'HorizontalAlignment','right', 'FontSize',8, ...
        'Color', tern(ice,RED,INK), 'FontWeight', tern(ice,'bold','normal'), 'Clipping','off');
    text(axL, his{i,2}+1.5, ysh(i), ['+' isl(his{i,2},1)], 'FontSize',8, ...
        'Color', tern(ice,RED,MUT), 'FontWeight', tern(ice,'bold','normal'), 'Clipping','off');
end
text(axL, 0, 8.5, sprintf(['Svona lítur glæran út: Ísland „ber af“,\naf því að hin 27 ríkin eru falin\n' ...
    'bak við tvö meðaltöl.\n\nÁ 10 ára glugganum (2015–2025) er\nÍsland einnig í 14. sæti, á eftir\nDanmörku (+13,2%% á móti +11,6%%).']), ...
    'FontSize',7.6, 'Color',MUT, 'VerticalAlignment','top');
xlim(axL, [0 60]); ylim(axL, [0 28]);
snyrta(axL, sprintf('Áfram Ísland:\nÍsland borið við tvö meðaltöl'), ...
    'Framleiðnivöxtur frá 2000: aðeins þrjár raðir', INK, MUT);
axR = axes(fig, 'Position', [0.665 0.05 0.30 0.875]);
yR = spjald(axR, prod00, BLUE, sprintf('Heildarsamanburður:\nFramleiðnivöxtur í 28 ríkjum'), ...
    'Sami mælikvarði og tímabil: Ísland í 14. sæti', 232, 27.0, 'ESB-27: +27,0', 1, ...
    {'Írland','Lúxemborg'}, RED, INK, MUT);
pila(fig, axL, axR, 22, yR, sprintf('1. af 3 sýndum röðum\n\\rightarrow 14. af 28 ríkjum'), ...
    RED, 52 + 60*0.055, -1);
exportgraphics(fig, fullfile(OUT,'m3_framleidni.pdf'), 'ContentType','vector'); close(fig);

%% ---- M3b: Framleiðnistig með og án auðlindagreina (geirapróf 2023) ----
% Fryst gögn: lokagerdgogn/framleidni_kjarna/country_productivity_resource_exclusion.csv
% (prófað sjálfvirkt með lokagerdgogn/framleidni_kjarna/profa_m3b_samraemi.py)
% (Eurostat nama_10_a64/_e + nama_10_gdp; B1G í PPS á unna stund; aðalár 2023;
% fast 20 ríkja úrtak, 8 ríki án A03/D/C24-sundurliðunar undanskilin, ekki núllstillt).
lpal = {'Írland',94.9;'Danmörk',58.0;'Holland',55.0;'Ísland',54.6;'Austurríki',52.5;
 'Svíþjóð',46.6;'Finnland',45.2;'Ítalía',44.8;'Spánn',43.4;'Slóvenía',37.9;
 'Tékkland',36.2;'Slóvakía',35.9;'Kýpur',34.9;'Rúmenía',32.9;'Ungverjaland',30.1;
 'Króatía',29.2;'Portúgal',28.7;'Pólland',28.3;'Lettland',26.2;'Grikkland',23.6};
lpco = {'Írland',94.5;'Danmörk',57.4;'Holland',54.0;'Ísland',51.4;'Austurríki',50.7;
 'Svíþjóð',45.7;'Ítalía',44.1;'Finnland',44.1;'Spánn',42.3;'Slóvenía',36.9;
 'Tékkland',35.3;'Slóvakía',34.7;'Kýpur',34.6;'Rúmenía',32.2;'Ungverjaland',29.5;
 'Króatía',28.9;'Portúgal',28.3;'Pólland',27.6;'Lettland',25.7;'Grikkland',22.8};
tvispjald(fullfile(OUT,'m3b_framleidnistig.pdf'), lpal, lpco, ...
 {sprintf('Allar atvinnugreinar:\nVirðisaukning á unna stund 2023'),'PPS á klst; fast 20 ríkja úrtak; Ísland í 4. sæti',110,51.9,'Vestrænt miðgildi: 51,9',1,{},true}, ...
 {sprintf('Án fiskveiða, orku og málmframleiðslu:\nVirðisaukning á unna stund 2023'),'Sömu 20 ríki; Ísland áfram í 4. sæti',110,44.9,'Vestrænt miðgildi: 44,9',1,{},true}, ...
 '', GRAY, BLUE, RED, INK, MUT);

%% ---- M4: Ungmenni ----
yrate = {'Rúmenía',26.1;'Spánn',24.9;'Svíþjóð',24.3;'Finnland',21.8;'Eistland',20.7;
 'Ítalía',20.6;'Frakkland',19.8;'Portúgal',19.5;'Grikkland',19.1;'Króatía',18.3;
 'Belgía',17.4;'Slóvakía',15.3;'Lettland',14.8;'Litáen',14.1;'Ungverjaland',13.9;
 'Danmörk',13.8;'Kýpur',13.5;'Búlgaría',13.1;'Pólland',12.2;'Slóvenía',12.1;
 'Írland',11.8;'Austurríki',11.5;'Tékkland',10.4;'Malta',9.6;'Ísland',9.5;
 'Holland',8.8;'Þýskaland',7.1};
yratio = {'Svíþjóð',13.9;'Finnland',11.7;'Danmörk',9.6;'Eistland',8.9;'Frakkland',8.5;
 'Spánn',8.4;'Ísland',7.9;'Holland',7.4;'Portúgal',6.7;'Austurríki',6.6;
 'Rúmenía',6.2;'Írland',6.2;'Belgía',6.0;'Króatía',5.4;'Lettland',5.3;
 'Kýpur',5.2;'Malta',5.1;'Litáen',5.0;'Grikkland',4.6;'Ítalía',4.6;
 'Ungverjaland',4.3;'Slóvenía',4.3;'Þýskaland',3.9;'Slóvakía',3.9;'Pólland',3.8;
 'Tékkland',2.9;'Búlgaría',2.5};
% Regla myndanna: besta staðan (lægsta atvinnuleysi) er efsta súlan.
yrate = flipud(yrate); yratio = flipud(yratio);
tvispjald(fullfile(OUT,'m4_ungmenni.pdf'), yrate, yratio, ...
 {sprintf('Áfram Ísland:\nAtvinnulausir af unga vinnuaflinu'),'Atvinnuleitendur ÷ (vinnandi + atvinnuleitendur), 15–24 ára',29,15.2,'ESB-27: 15,2',1,{}}, ...
 {sprintf('Víðari framsetning:\nAtvinnuleitendur af öllum aldurshópnum'),'Allir 15–24 ára í nefnara, þar á meðal námsfólk',16.2,6.2,'ESB-27: 6,2',1,{}}, ...
 '3. \rightarrow 21. sæti', GRAY, BLUE, RED, INK, MUT);

%% ---- M5: Atvinnuleysi í dag ----
unow = {'Finnland',10.8;'Spánn',10.3;'Svíþjóð',8.8;'Frakkland',8.2;'Grikkland',8.1;
 'Litáen',7.0;'Danmörk',6.9;'Lúxemborg',6.9;'Lettland',6.5;'Eistland',6.4;
 'Rúmenía',6.4;'Belgía',6.3;'Austurríki',5.8;'Ísland (apríl)',5.8;'Slóvakía',5.8;
 'Portúgal',5.5;'Ítalía',5.0;'Írland',4.9;'Ungverjaland',4.4;'Króatía',4.3;
 'Slóvenía',4.1;'Holland',3.9;'Þýskaland',3.8;'Malta',3.5;'Kýpur',3.1;
 'Pólland',3.1;'Búlgaría',2.9;'Tékkland',2.9};
% Regla myndanna: besta staðan (lægsta atvinnuleysi) er efsta súlan.
unow = flipud(unow);
fig = nyfig(7.4, 6.8);
ax = axes(fig, 'Position', [0.22 0.06 0.72 0.87]);
spjald(ax, unow, BLUE, 'Samræmt atvinnuleysi vorið 2026', ...
 '15–74 ára, árstíðaleiðrétt; maí (Ísland: apríl); Ísland í 15. sæti af 28', ...
 12, 5.9, 'ESB-27: 5,9', 1, {}, RED, INK, MUT);
exportgraphics(fig, fullfile(OUT,'m5_atvinnuleysi.pdf'), 'ContentType','vector'); close(fig);

%% ---- M7: Flökt krónu og evru gagnvart Bandaríkjadal eftir losun hafta ----
% dálkar: ár, ISK/USD, EUR/USD; 30 daga flökt daglegra lógaritmabreytinga á
% ársgrundvelli, meðaltal almanaksárs (2026 til 10. júlí); reiknað úr frystum
% gögnum meginpakkans (SÍ 4055/4064, ECB eurofxref) með aðferð reikna_nidurstodur.m
groups = {'2018',10.4,7.2; '2019',8.5,5.1; '2020',10.7,7.4; '2021',8.7,5.2;
 '2022',11.7,9.8; '2023',9.6,7.5; '2024',6.5,5.9; '2025',8.4,7.6; '2026',6.5,6.0;
 'Meðaltal 2018–2026',9.2,6.9};
n = size(groups,1);
fig = nyfig(7.4, 3.2);
ax = axes(fig, 'Position', [0.08 0.16 0.89 0.68]); hold(ax, 'on');
x = [1:n-1, n+0.5]; w = 0.34;
for i = 1:n
    feit = tern(i == n, 'bold', 'normal');
    bar(ax, x(i)-0.19, groups{i,2}, w, 'FaceColor', BLUE, 'EdgeColor','none');
    bar(ax, x(i)+0.19, groups{i,3}, w, 'FaceColor', GRAY, 'EdgeColor','none');
    text(ax, x(i)-0.19, groups{i,2}+0.35, isl(groups{i,2},1), 'HorizontalAlignment','center', ...
        'FontSize',6.9, 'FontWeight','bold', 'Color',BLUE);
    text(ax, x(i)+0.19, groups{i,3}+0.35, isl(groups{i,3},1), 'HorizontalAlignment','center', ...
        'FontSize',6.9, 'Color',MUT);
    text(ax, x(i), -0.8, groups{i,1}, 'HorizontalAlignment','center', ...
        'FontSize',7.4, 'FontWeight',feit, 'Color',INK, 'Clipping','off');
end
plot(ax, [n n]-0.15, [0 13], ':', 'Color', MUT, 'LineWidth', 0.5);
xticks(ax, x); xticklabels(ax, repmat({''},1,n)); ax.FontSize = 7.6;
xlim(ax, [0.4 n+1.1]); ylim(ax, [0 13.5]); yticks(ax, 0:3:12);
yticklabels(ax, arrayfun(@(v) sprintf('%d%%', v), 0:3:12, 'UniformOutput', false));
ax.Box = 'off'; ax.TickDir = 'out';
title(ax, 'Gengisflökt eftir losun hafta: króna og evra gagnvart Bandaríkjadal, 30 daga flökt á ársgrundvelli', ...
    'FontSize',9.5, 'FontWeight','bold', 'Color',INK, 'HorizontalAlignment','left', 'Units','normalized', 'Position',[0 1.08 0]);
lg = legend(ax, {'ISK gagnvart USD','EUR gagnvart USD'}, 'Box','off', 'FontSize',7.2, 'Location','northeast'); %#ok<NASGU>
exportgraphics(fig, fullfile(OUT,'m7_flokt.pdf'), 'ContentType','vector'); close(fig);

%% ---- Vaxtamyndirnar þrjár: styrivextir_bru, m8_vextir, heimili_60m ----
% Frysta lokagerðin í lokagerdgogn/mynd04_vextir les öll tölugildi úr frosinni
% vinnubók og teiknar þrjár myndir: stýrivaxtabrú, íbúðalánavexti og
% heimilisdæmið. Úttakið er afritað í úttaksmöppuna.
vaxtaRoot = fullfile(ROT, 'lokagerdgogn', 'mynd04_vextir');
vaxtaForrit = fullfile(vaxtaRoot, 'forrit');
vaxtaMyndir = fullfile(vaxtaRoot, 'mynd');

% Fallið stillir textatúlka fyrir eigin myndir. Gildin eru varðveitt og
% endurheimt svo keyrslan hafi engin áhrif á hinar myndirnar.
fyrriTextInterpreter = get(groot, 'defaultTextInterpreter');
fyrriTickInterpreter = get(groot, 'defaultAxesTickLabelInterpreter');
fyrriLegendInterpreter = get(groot, 'defaultLegendInterpreter');
addpath(vaxtaForrit);
gera_vaxtamyndir();
rmpath(vaxtaForrit);
set(groot, 'defaultTextInterpreter', fyrriTextInterpreter);
set(groot, 'defaultAxesTickLabelInterpreter', fyrriTickInterpreter);
set(groot, 'defaultLegendInterpreter', fyrriLegendInterpreter);

copyfile(fullfile(vaxtaMyndir, 'ibudalan_esb.pdf'), ...
    fullfile(OUT, 'm8_vextir.pdf'), 'f');
copyfile(fullfile(vaxtaMyndir, 'styrivextir_bru.pdf'), ...
    fullfile(OUT, 'styrivextir_bru.pdf'), 'f');
copyfile(fullfile(vaxtaMyndir, 'heimili_60m.pdf'), ...
    fullfile(OUT, 'heimili_60m.pdf'), 'f');

%% ---- m9_imd: IMD-myndin úr frystu lokagerðinni (Python) ----
% Myndin er teiknuð með lokagerdgogn/mynd05_samkeppnishaefni/forrit/gera_mynd05.py
% úr frystri talnatöflu; hér er forritið keyrt og úttakið afritað.
imdForrit = fullfile(ROT, 'lokagerdgogn', 'mynd05_samkeppnishaefni', 'forrit', 'gera_mynd05.py');
imdMynd = fullfile(ROT, 'lokagerdgogn', 'mynd05_samkeppnishaefni', 'mynd', 'm5_samkeppnishaefni.pdf');
[stada, ~] = system(sprintf('python3 "%s"', imdForrit));
if stada == 0 && isfile(imdMynd)
    copyfile(imdMynd, fullfile(OUT, 'm9_imd.pdf'), 'f');
else
    warning('m9_imd.pdf var ekki endurgerð: keyrið python3 %s (þarf matplotlib).', imdForrit);
end

%% ---- M10: Skuldir, heildartala ESB vs dreifing ríkjanna 2025 ----
% ein IMF-röð (WEO DataMapper GGXWDG_NGDP, sótt 20.7.2026) fyrir öll ríki, árið 2025;
% raðað frá lægstu skuldum; 13 ríki undir Íslandi, 14 yfir (14. sæti af 28); miðgildi 58,8
debt = {'Eistland',24.2;'Lúxemborg',27.0;'Búlgaría',27.1;'Danmörk',27.5;'Írland',32.9;
 'Svíþjóð',34.9;'Litáen',39.8;'Holland',43.3;'Tékkland',44.6;'Malta',46.8;
 'Lettland',46.9;'Kýpur',55.3;'Króatía',55.9;'Ísland',56.1;'Pólland',58.8;
 'Rúmenía',60.6;'Slóvakía',61.6;'Þýskaland',62.9;'Slóvenía',65.9;'Ungverjaland',75.2;
 'Austurríki',80.5;'Finnland',89.3;'Portúgal',89.9;'Spánn',100.4;'Belgía',106.3;
 'Frakkland',116.0;'Ítalía',137.1;'Grikkland',145.7};
fig = nyfig(8.6, 7.6);
axL = axes(fig, 'Position', [0.165 0.05 0.28 0.875]); hold(axL, 'on');
his = {'Ísland',56.1;'Miðgildi ESB-ríkjanna',58.8;'Einfalt meðaltal ESB-ríkjanna',65.1;'ESB-heildin',82.5};
ysh = [25 20.4 15.8 11.2];
for i = 1:4
    ice = i == 1;
    c = GRAY; if ice; c = RED; end; if i == 2; c = BLUE; end
    barh(axL, ysh(i), his{i,2}, 3.0, 'FaceColor', c, 'EdgeColor','none');
    text(axL, -3, ysh(i), his{i,1}, 'HorizontalAlignment','right', 'FontSize',7.5, ...
        'Color', tern(ice,RED,INK), 'FontWeight', tern(ice,'bold','normal'), 'Clipping','off');
    text(axL, his{i,2}+2.5, ysh(i), isl(his{i,2},1), 'FontSize',8.5, ...
        'Color', tern(ice,RED,MUT), 'FontWeight', tern(ice,'bold','normal'), 'Clipping','off');
end
text(axL, 0, 7.6, sprintf('26,4 prósentustig við ESB-heildina.\n2,7 prósentustig við miðríkið.'), ...
    'FontSize',7.6, 'Color',INK, 'FontWeight','bold', 'VerticalAlignment','top');
text(axL, 0, 4.4, sprintf('Spá 2030: Ísland 45,4%%;\nESB-heild 85,5%%.'), ...
    'FontSize',7.0, 'Color',MUT, 'VerticalAlignment','top');
xlim(axL, [0 100]); ylim(axL, [0 28]);
snyrta(axL, sprintf('Heildartala og dæmigert ríki:\nSkuldir hins opinbera 2025'), ...
    'Sama IMF-röð (WEO, apríl 2026), % af VLF', INK, MUT);
axR = axes(fig, 'Position', [0.665 0.05 0.30 0.875]);
icey = spjald(axR, debt, BLUE, sprintf('Öll ríkin, sama IMF-röð:\nSkuldir hins opinbera 2025'), ...
 'Raðað frá lægstu skuldum; brotalína: miðgildi, punktalína: ESB-heild', 168, 58.8, 'Miðgildi: 58,8', 1, {}, RED, INK, MUT);
barh(axR, icey-1, 58.8, 0.62, 'FaceColor', [0.10 0.25 0.45], 'EdgeColor','none');
plot(axR, [82.5 82.5], ylim(axR), ':', 'Color', INK, 'LineWidth', 1.0);
text(axR, 84, 26.3, 'ESB-heildin: 82,5', 'FontSize',6.8, 'Color', INK);
text(axR, 88, icey, sprintf('Langt undir ESB-heildinni \\rightarrow\nnær miðju aðildarríkjanna'), ...
    'FontSize',7.2, 'Color', RED, 'FontWeight','bold');
exportgraphics(fig, fullfile(OUT,'m10_skuldir.pdf'), 'ContentType','vector'); close(fig);

%% ---- M12: Verðlag og launakostnaður, Balassa–Samuelson-aðhvarf ----
% x: Eurostat lc_lci_lev, heildarlaunakostnaður á vinnustund 2024, evrur,
% atvinnugreinar B-S án O (heimild [19]); y: prc_ppp_ind, verðlagsvísir
% einkaneyslu 2024, ESB-27=100 (heimild [20]). Aðhvarf metið á ESB-27 í
% lograum; Ísland er UTAN matsins og spáð fyrir það. Sótt 14. júlí 2026.
adf = {'Lúxemborg',54.9,132.8;'Danmörk',50.2,143.1;'Belgía',48.2,116.5;
 'Holland',45.2,116.0;'Austurríki',44.3,112.8;'Þýskaland',43.5,108.6;
 'Frakkland',43.4,111.2;'Írland',42.5,138.1;'Svíþjóð',40.2,115.1;
 'Finnland',37.7,123.5;'Ítalía',31,97.5;'Slóvenía',27.1,90.2;'Spánn',25.5,90.9;
 'Kýpur',21,92.8;'Eistland',19.6,100.0;'Malta',19.1,91.6;'Slóvakía',18.5,84.7;
 'Portúgal',18.2,87.0;'Tékkland',18.1,88.4;'Pólland',17.3,72.2;
 'Grikkland',16.8,86.0;'Króatía',16.5,76.3;'Litáen',16.3,81.6;
 'Lettland',15.1,81.8;'Ungverjaland',14,73.5;'Rúmenía',12.4,63.7;
 'Búlgaría',10.6,59.7};
xIS = 53.2; yIS = 161.7;
lx = log(cell2mat(adf(:,2))); ly = log(cell2mat(adf(:,3)));
nn = numel(lx); mx = mean(lx); Sxx = sum((lx-mx).^2);
hal = sum((lx-mx).*(ly-mean(ly)))/Sxx; skp = mean(ly) - hal*mx;
sse = sum((ly - skp - hal*lx).^2);
r2 = 1 - sse/sum((ly-mean(ly)).^2); see = sqrt(sse/(nn-2));
spa = exp(skp + hal*log(xIS));
fig = nyfig(6.9, 5.6);
ax = axes(fig, 'Position', [0.105 0.115 0.865 0.80]); hold(ax, 'on');
xg = linspace(log(9), log(62), 60);
fill(ax, exp([xg fliplr(xg)]), exp([skp+hal*xg-2*see fliplr(skp+hal*xg+2*see)]), ...
    BLUE, 'FaceAlpha', 0.07, 'EdgeColor', 'none');
plot(ax, exp(xg), exp(skp+hal*xg), '-', 'Color', BLUE, 'LineWidth', 1.6);
scatter(ax, cell2mat(adf(:,2)), cell2mat(adf(:,3)), 26, GRAY, 'filled');
% land, x, y, jöfnun; handstillt svo ekkert skarist við spápunktinn
merki = {'Danmörk',49.5,148.5,'right';'Írland',41.8,133.5,'right';
 'Lúxemborg',54.3,126,'right';'Búlgaría',11.0,57.2,'left';
 'Rúmenía',12.8,61.2,'left';'Ungverjaland',14.2,70.3,'left';
 'Eistland',19.9,104,'left';'Finnland',36.6,127.5,'right';
 'Holland',45.6,111.3,'left'};
for k = 1:size(merki,1)
    text(ax, merki{k,2}, merki{k,3}, merki{k,1}, 'FontSize', 6.6, 'Color', MUT, ...
        'HorizontalAlignment', merki{k,4});
end
plot(ax, [xIS xIS], [spa yIS], '--', 'Color', RED, 'LineWidth', 1.1);
scatter(ax, xIS, spa, 42, 'MarkerEdgeColor', RED, 'MarkerFaceColor', 'w', 'LineWidth', 1.1);
scatter(ax, xIS, yIS, 58, RED, 'filled');
text(ax, xIS*0.985, yIS*1.045, 'Ísland: raunverðlag 162', 'FontSize', 8, ...
    'Color', RED, 'FontWeight', 'bold', 'HorizontalAlignment', 'right');
text(ax, xIS*0.985, spa*0.925, sprintf('spáð verðlag %d', round(spa)), 'FontSize', 7.4, ...
    'Color', RED, 'HorizontalAlignment', 'right');
text(ax, xIS*1.017, sqrt(spa*yIS), '+24%', 'FontSize', 7.6, 'Color', RED, ...
    'FontWeight', 'bold', 'Clipping', 'off');
text(ax, 10.8, 152, sprintf('ln verðlag = %s + %s \\cdot ln launakostnaður', ...
    isl(skp,1), isl(hal,2)), 'FontSize', 7.6, 'Color', INK);
text(ax, 10.8, 143, sprintf('R^2 = %s; skyggt: \\pm 2 staðalvillur', isl(r2,2)), ...
    'FontSize', 7.6, 'Color', MUT);
set(ax, 'XScale', 'log', 'YScale', 'log', 'Box', 'off', 'TickDir', 'out');
ax.XTick = [10 15 20 30 40 55]; ax.YTick = [60 80 100 120 140 160];
ax.XTickLabel = {'10','15','20','30','40','55'};
ax.YTickLabel = {'60','80','100','120','140','160'};
ax.XAxis.FontSize = 7; ax.YAxis.FontSize = 7;
ax.XAxis.Color = MUT; ax.YAxis.Color = MUT;
xlim(ax, [9.5 62]); ylim(ax, [55 175]);
xlabel(ax, 'Launakostnaður á vinnustund 2024, evrur (log-kvarði)', ...
    'FontSize', 8, 'Color', INK);
ylabel(ax, 'Verðlagsvísir einkaneyslu 2024, ESB-27 = 100 (log-kvarði)', ...
    'FontSize', 8, 'Color', INK);
title(ax, 'Verðlag og launakostnaður 2024: aðhvarf ESB-27, Ísland utan mats', ...
    'FontSize', 9.5, 'FontWeight', 'bold', 'Color', INK, ...
    'Units', 'normalized', 'Position', [0 1.03 0], 'HorizontalAlignment', 'left');
grid(ax, 'on'); ax.GridAlpha = 0.12; ax.MinorGridLineStyle = 'none';
exportgraphics(fig, fullfile(OUT,'m12_adhvarf.pdf'), 'ContentType','vector'); close(fig);

%% ---- M13: Atvinnuleysi, 5, 10 og 20 ára meðaltöl til 2025 ----
% une_rt_a 2009-2025 og une_rt_a_h 2006-2008 (sögulegt framhald sömu raðar,
% Y15-74, PC_ACT), einföld meðaltöl ársgilda; raðað hækkandi eftir 10 ára
% meðaltali. Sótt 14. júlí 2026; samhljóða K70 í talnaskránni.
u3 = {'Tékkland',2.6,2.67,4.48;
 'Þýskaland',3.42,3.42,4.96;
 'Pólland',3.02,3.68,6.69;
 'Malta',3.42,3.88,5.09;
 'Ísland',4.3,3.89,4.45;
 'Ungverjaland',4.12,4.06,6.45;
 'Holland',3.78,4.6,5.39;
 'Slóvenía',4.02,4.92,6.18;
 'Búlgaría',4.28,5.47,7.87;
 'Danmörk',5.46,5.48,5.83;
 'Austurríki',5.4,5.54,5.43;
 'Írland',4.8,5.58,8.31;
 'Lúxemborg',5.6,5.78,5.49;
 'Rúmenía',5.66,5.79,6.93;
 'Belgía',5.86,6.17,7.09;
 'Eistland',6.66,6.27,7.67;
 'Slóvakía',5.88,6.6,9.62;
 'Litáen',6.8,7,8.9;
 'Portúgal',6.38,7.35,9.79;
 'Lettland',6.96,7.5,9.87;
 'Kýpur',5.7,7.58,8.33;
 'Króatía',6.06,7.67,10.36;
 'Svíþjóð',8.26,7.71,7.67;
 'Finnland',7.96,7.94,7.98;
 'Frakkland',7.52,8.25,8.75;
 'Ítalía',7.58,9.07,9.17;
 'Spánn',12.4,14.37,16.42;
 'Grikkland',11.46,15.82,16.42};
eu5=6.28; eu10=7.04; eu20=8.36;
fig = nyfig(5.4, 8.8);
ax = axes(fig, 'Position', [0.22 0.05 0.72 0.875]); hold(ax, 'on');
n = size(u3,1); maxv = 19; hnd = gobjects(1,3);
for i = 1:n
    y = n - i + 1;
    ice = strcmp(u3{i,1}, 'Ísland');
    vals = [u3{i,2} u3{i,3} u3{i,4}];
    offs = [0.28 0 -0.28];
    cols = {B5, B10, B20}; if ice; cols = {R5, R10, R20}; end
    for k = 1:3
        b = barh(ax, y+offs(k), vals(k), 0.24, 'FaceColor', cols{k}, 'EdgeColor','none');
        if i == 1; hnd(k) = b; end
    end
    text(ax, -maxv*0.015, y, sprintf('%d. %s', i, u3{i,1}), 'HorizontalAlignment','right', ...
        'FontSize', tern(ice,7.6,7.0), 'Color', tern(ice,RED,INK), ...
        'FontWeight', tern(ice,'bold','normal'), 'Clipping','off');
    text(ax, vals(2)+maxv*0.012, y, isl(vals(2),1), 'FontSize', tern(ice,7.2,6.0), ...
        'Color', tern(ice,RED,MUT), 'FontWeight', tern(ice,'bold','normal'), 'Clipping','off');
end
xline(ax, eu10, '--', 'Color', INK, 'LineWidth', 0.9, 'Alpha', 0.6);
text(ax, eu10, n+1.15, sprintf('ESB-27: %s (10 ár)', isl(eu10,1)), 'FontSize',6.6, ...
    'Color',MUT, 'Clipping','off');
xlim(ax, [0 maxv]); ylim(ax, [0.3 n+1.6]);
ax.YTick = []; ax.Box = 'off'; ax.YAxis.Visible = 'off';
ax.XAxis.FontSize = 7; ax.XAxis.Color = MUT; ax.TickDir = 'out';
title(ax, 'Atvinnuleysi: meðaltöl 5, 10 og 20 ára til 2025', ...
    'FontSize',9.5, 'FontWeight','bold', 'Color',INK, ...
    'Units','normalized', 'Position',[0 1.045 0], 'HorizontalAlignment','left');
text(ax, 0, 1.014, '% af vinnuafli 15-74 ára; raðað frá lægsta 10 ára meðaltali', ...
    'Units','normalized', 'FontSize',7.4, 'Color',MUT);
legend(ax, hnd, {'5 ár','10 ár','20 ár'}, 'Box','off', 'FontSize',7, 'Location','northeast');
exportgraphics(fig, fullfile(OUT,'m13_atvinnuleysi.pdf'), 'ContentType','vector'); close(fig);

%% ---- m2_verdlag: fryst lokagerð úr lokagerdgogn/mynd02_verdlag ----
% gera_mynd02.m er keyrt síðast því það hreinsar vinnusvæðið; slóðirnar eru
% reiknaðar að nýju á eftir.
run(fullfile(ROT, 'lokagerdgogn', 'mynd02_verdlag', 'forrit', 'gera_mynd02.m'));
ROT = fileparts(fileparts(mfilename('fullpath')));
OUT = fullfile(ROT, 'endurgerd');
copyfile(fullfile(ROT, 'lokagerdgogn', 'mynd02_verdlag', 'mynd', 'm2_verdlag.pdf'), ...
    fullfile(OUT, 'm2_verdlag.pdf'), 'f');

fprintf('Myndir skrifaðar í %s\n', OUT);
dir(fullfile(OUT, '*.pdf'))

%% ================= Hjálparföll =================
function s = isl(v, d)
    s = strrep(sprintf(['%.' num2str(d) 'f'], v), '.', ',');
    % ASCII bandstrik: U+2212 vantar i letur PDF-utflutnings
end

function out = tern(cond, a, b)
    if cond; out = a; else; out = b; end
end

function fig = nyfig(w, h)
    fig = figure('Visible','off', 'Units','inches', 'Position',[1 1 w h], 'Color','w');
end

function snyrta(ax, titl, sub, INK, MUT)
    if contains(titl, newline)
        pos = ax.Position;
        pos(4) = pos(4) - 0.055;
        ax.Position = pos;
    end
    ax.YTick = []; ax.Box = 'off';
    ax.YAxis.Visible = 'off';
    ax.XAxis.FontSize = 7; ax.XAxis.Color = MUT;
    ax.TickDir = 'out';
    title(ax, titl, 'FontSize',9.5, 'FontWeight','bold', 'Color',INK, ...
        'Units','normalized', 'Position',[0 1.055 0], 'HorizontalAlignment','left');
    if ~isempty(sub)
        text(ax, 0, 1.018, sub, 'Units','normalized', 'FontSize',7.4, 'Color',MUT);
    end
end

function icey = spjald(ax, data, color, titl, sub, maxv, eu, eulab, d, dimmed, RED, INK, MUT, ofan)
    % ofan=true: gildismerkingar teiknaðar OFAN Á viðmiðunarlínuna (með hvítum
    % grunni) svo brotalínan striki ekki í gegnum tölur sem liggja nærri henni.
    if nargin < 14; ofan = false; end
    hold(ax, 'on');
    n = size(data, 1); icey = []; r = 0; vt = {};
    for i = 1:n
        y = n - i + 1;
        nm = data{i,1}; v = data{i,2};
        % 'Ísland (landið)' er samanburðarlína án sætis (raskar ekki röðun
        % svæðanna); fær daufari rauðan flöt og skáletrað heiti.
        land = strcmp(nm, 'Ísland (landið)');
        ice = ~land && (strncmp(nm, 'Ísland', 6) || strncmp(nm, 'Reykjavík', 9));
        c = color; a = 0.75;
        if ice; c = RED; a = 1;
        elseif land; c = RED; a = 0.40;
        elseif any(strcmp(nm, dimmed)); a = 0.35; end
        b = barh(ax, y, max(v, 0), 0.62, 'FaceColor', c, 'EdgeColor','none');
        b.FaceAlpha = a;
        if land
            lab = nm;
        else
            r = r + 1;
            lab = sprintf('%d. %s', r, nm);
        end
        text(ax, -maxv*0.015, y, lab, 'HorizontalAlignment','right', ...
            'FontSize', tern(ice||land,7.6,7.0), 'Color', tern(ice||land,RED,INK), ...
            'FontWeight', tern(ice,'bold','normal'), ...
            'FontAngle', tern(land,'italic','normal'), 'Clipping','off');
        vt(end+1,:) = {max(v,0)+maxv*0.012, y, isl(v, d), tern(ice||land,7.2,6.4), ...
            tern(ice||land,RED,MUT), tern(ice,'bold','normal'), tern(land,'italic','normal')}; %#ok<AGROW>
        if ~ofan
            text(ax, vt{end,1}, vt{end,2}, vt{end,3}, 'FontSize', vt{end,4}, ...
                'Color', vt{end,5}, 'FontWeight', vt{end,6}, ...
                'FontAngle', vt{end,7}, 'Clipping','off');
        end
        if ice && isempty(icey); icey = y; end
    end
    if ~isempty(eu)
        if ofan
            plot(ax, [eu eu], [0.3 n+1.6], '--', 'Color', [INK 0.6], 'LineWidth', 0.9);
        else
            xline(ax, eu, '--', 'Color', INK, 'LineWidth', 0.9, 'Alpha', 0.6);
        end
        text(ax, eu, n+0.9, eulab, 'FontSize',6.6, 'Color',MUT, 'Clipping','off');
    end
    if ofan
        for k = 1:size(vt,1)
            text(ax, vt{k,1}, vt{k,2}, vt{k,3}, 'FontSize', vt{k,4}, ...
                'Color', vt{k,5}, 'FontWeight', vt{k,6}, 'FontAngle', vt{k,7}, ...
                'BackgroundColor','w', 'Margin',0.5, 'Clipping','off');
        end
    end
    xlim(ax, [0 maxv]); ylim(ax, [0.3 n+1.6]);
    snyrta(ax, titl, sub, INK, MUT);
end

function pila(fig, axL, axR, yL, yR, txt, RED, xstart, hlid)
    % Örin hefst við enda súlu Íslands (xstart í gagnaeiningum vinstra
    % spjalds) og endar rétt framan við sætismerkingu hægra spjalds.
    % hlid = +1 (sjálfgefið): merking ofan við línuna; -1: neðan við.
    if nargin < 8 || isempty(xstart); xstart = axL.XLim(2); end
    if nargin < 9 || isempty(hlid); hlid = 1; end
    p1 = gagn2fig(axL, min(xstart, axL.XLim(2)), yL);
    p2 = gagn2fig(axR, axR.XLim(1), yR);
    p2(1) = p2(1) - 0.072;
    annotation(fig, 'arrow', [p1(1) p2(1)], [p1(2) p2(2)], ...
        'Color', RED, 'LineWidth', 1.6, 'HeadWidth', 8, 'HeadLength', 8);
    if ~isempty(txt)
        ov = axes(fig, 'Position',[0 0 1 1], 'Visible','off', 'HitTest','off');
        xlim(ov,[0 1]); ylim(ov,[0 1]);
        d = (p2 - p1) / max(norm(p2 - p1), eps);
        nh = [-d(2) d(1)]; if nh(2) < 0; nh = -nh; end
        pos = (p1 + p2)/2 + hlid * nh * 0.055;
        text(ov, pos(1), pos(2), txt, 'Color', RED, 'FontSize',11, ...
            'FontWeight','bold', 'HorizontalAlignment','center');
    end
end

function p = gagn2fig(ax, x, y)
    pos = ax.Position; xl = ax.XLim; yl = ax.YLim;
    p = [pos(1) + pos(3)*(x - xl(1))/(xl(2) - xl(1)), ...
         pos(2) + pos(4)*(y - yl(1))/(yl(2) - yl(1))];
end

function tvispjald(fname, L, R, optL, optR, atext, GRAY, BLUE, RED, INK, MUT, hlid)
    if nargin < 12 || isempty(hlid); hlid = 1; end
    fig = nyfig(8.6, 7.6);
    axL = axes(fig, 'Position', [0.135 0.05 0.30 0.875]);
    yL = spjald(axL, L, GRAY, optL{1}, optL{2}, optL{3}, optL{4}, optL{5}, optL{6}, optL{7}, RED, INK, MUT, ...
        numel(optL) >= 8 && optL{8});
    axR = axes(fig, 'Position', [0.665 0.05 0.30 0.875]);
    yR = spjald(axR, R, BLUE, optR{1}, optR{2}, optR{3}, optR{4}, optR{5}, optR{6}, optR{7}, RED, INK, MUT, ...
        numel(optR) >= 8 && optR{8});
    if ~isempty(yL) && ~isempty(yR) && ~isempty(atext)
        xisl = [];
        for ii = 1:size(L,1)
            if strncmp(L{ii,1}, 'Ísland', 6) || strncmp(L{ii,1}, 'Reykjavík', 9)
                xisl = L{ii,2} + optL{3}*0.055; break;
            end
        end
        pila(fig, axL, axR, yL, yR, atext, RED, xisl, hlid);
    end
    exportgraphics(fig, fname, 'ContentType','vector');
    close(fig);
end
