# Leyfi

## Forrit

Öll forrit pakkans (skrár með endingunum `.m` og `.py`) eru gefin út með
MIT-leyfi.

Copyright (c) 2026 Gauti B. Eggertsson

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Gögn, töflur, myndir og texti höfundar

Talnaskráin, unnu gagnatöflurnar, niðurstöðuskrárnar, myndirnar, greinin og
lýsingar pakkans eru gefin út með leyfinu Creative Commons Attribution 4.0
International (CC BY 4.0): <https://creativecommons.org/licenses/by/4.0/>.
Endurnot eru heimil með tilvísun til höfundar og greinarinnar:

> Eggertsson, Gauti B. (2026). Ísland er í efstu deild Evrópu ásamt fremstu
> ríkjum ESB, en á stór sóknarfæri: Mat á fullyrðingu Áfram Íslands um
> efnahagslega yfirburði Íslands gagnvart ríkjum Evrópusambandsins. Fyrsta
> útgáfa, 23. ágúst 2026. Gögn og forrit:
> https://www.gautiesb.is/skjol/30-daemi-gogn-og-tolvukodar-2026-08.zip

## Frosin frumgögn þriðja aðila

Frosnu afritin í `gogn/hra/` og í `hra/` hverrar einingar eru óbreytt svör
frá Eurostat, Hagstofu Íslands, Seðlabanka Íslands, Seðlabanka Evrópu,
Alþjóðagjaldeyrissjóðnum, OECD, Alþjóðabankanum og Alþjóðavinnumálastofnuninni.
Þau lúta skilmálum þeirra stofnana um endurnot, sem í öllum tilvikum heimila
afritun og dreifingu með tilvísun til heimildar. Ritverk sem lúta
höfundarrétti þriðja aðila (IMD World Competitiveness Booklet 2025, könnun
Seðlabanka Evrópu meðal greiningaraðila og greining Áfram Íslands) fylgja
ekki pakkanum.
