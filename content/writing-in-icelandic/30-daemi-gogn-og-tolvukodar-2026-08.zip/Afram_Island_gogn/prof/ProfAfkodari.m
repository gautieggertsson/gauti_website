classdef ProfAfkodari < matlab.unittest.TestCase
%% ProfAfkodari: einingapróf JSON-stat afkóðarans (forrit/afkoda_jsonstat.m)
% Prófar skrefareikninginn (stride) fyrst á tilbúnum smádæmum þar sem rétta
% svarið er þekkt fyrirfram, síðan á frosnum hrásvörum Eurostat í gogn/hra/
% gegn akkerisgildum sem voru staðfest í vef-viðmóti Eurostat. Naívur lestur
% JSON-stat (struct2cell á value-hlutinn) ruglar löndum saman; þessi próf
% eiga að fella hann. Keyrsla: runtests('prof') frá rót pakkans.

properties
    Hra   % slóð gogn/hra/
end

methods (TestClassSetup)
    function stilla(tc)
        rot = fileparts(fileparts(which(class(tc))));            % rót pakkans
        tc.applyFixture(matlab.unittest.fixtures.PathFixture(fullfile(rot, 'forrit')));
        tc.Hra = fullfile(rot, 'gogn', 'hra');
    end
end

methods (Test)
    function thett_fylki_stride(tc)
        % 2x3 þétt fylki: gildi i á flötu sæti i; síðasta víddin (time) hleypur hraðast
        txt = ['{"version":"2.0","class":"dataset","id":["geo","time"],"size":[2,3],' ...
            '"dimension":{"geo":{"category":{"index":{"AA":0,"BB":1}}},' ...
            '"time":{"category":{"index":["2001","2002","2003"]}}},' ...
            '"value":[0,1,2,3,4,5]}'];
        U = afkoda_jsonstat(txt);
        tc.verifyEqual(height(U), 6);
        tc.verifyEqual(cellstr(U.geo),  {'AA';'AA';'AA';'BB';'BB';'BB'});
        tc.verifyEqual(cellstr(U.time), {'2001';'2002';'2003';'2001';'2002';'2003'});
        tc.verifyEqual(U.gildi, (0:5)');
    end

    function gisid_fylki_stride(tc)
        % Gisin framsetning {"flatt sæti": gildi}: eyður falla brott, hnit rétt
        txt = ['{"version":"2.0","class":"dataset","id":["geo","time"],"size":[2,3],' ...
            '"dimension":{"geo":{"category":{"index":{"AA":0,"BB":1}}},' ...
            '"time":{"category":{"index":{"2001":0,"2002":1,"2003":2}}}},' ...
            '"value":{"0":10,"5":20}}'];
        U = afkoda_jsonstat(txt);
        tc.verifyEqual(height(U), 2);
        tc.verifyEqual(cellstr(U.geo),  {'AA';'BB'});
        tc.verifyEqual(cellstr(U.time), {'2001';'2003'});
        tc.verifyEqual(U.gildi, [10; 20]);
    end

    function tec00114_akkeri(tc)
        % tec00114 2024: IS=131, LU=244, NL=134 (staðfest í vef-viðmóti Eurostat)
        U = afkoda_jsonstat(fileread(fullfile(tc.Hra, 'eurostat_tec00114.json'), ...
            'Encoding', 'UTF-8'));
        tc.verifyEqual(stak(tc, U, U.geo == "IS" & U.time == "2024"), 131, 'AbsTol', 5e-3);
        tc.verifyEqual(stak(tc, U, U.geo == "LU" & U.time == "2024"), 244, 'AbsTol', 5e-3);
        tc.verifyEqual(stak(tc, U, U.geo == "NL" & U.time == "2024"), 134, 'AbsTol', 5e-3);
    end

    function met_10r_3gdp_akkeri(tc)
        % met_10r_3gdp 2021: Kaupmannahöfn DK001MC=173, Dyflinni IE001MC=273
        U = afkoda_jsonstat(fileread(fullfile(tc.Hra, 'eurostat_met_10r_3gdp.json'), ...
            'Encoding', 'UTF-8'));
        tc.verifyEqual(stak(tc, U, U.metroreg == "DK001MC" & U.time == "2021"), 173, 'AbsTol', 5e-3);
        tc.verifyEqual(stak(tc, U, U.metroreg == "IE001MC" & U.time == "2021"), 273, 'AbsTol', 5e-3);
    end

    function prc_ppp_ind_akkeri(tc)
        % prc_ppp_ind 2024: PLI einkaneyslu (E011) fyrir Ísland = 161,7
        U = afkoda_jsonstat(fileread(fullfile(tc.Hra, 'eurostat_prc_ppp_ind_pli.json'), ...
            'Encoding', 'UTF-8'));
        tc.verifyEqual(stak(tc, U, U.ppp_cat == "E011" & U.geo == "IS" & U.time == "2024"), ...
            161.7, 'AbsTol', 5e-3);
    end

    function bandstrik_i_kodum(tc)
        % jsondecode afbakar Y15-74 í Y15_74, afkóðarinn les kóðana úr hráa textanum
        U = afkoda_jsonstat(fileread(fullfile(tc.Hra, 'eurostat_une_rt_a.json'), ...
            'Encoding', 'UTF-8'));
        tc.verifyEqual(sort(cellstr(unique(U.age))), {'Y15-24'; 'Y15-74'});
    end
end

methods
    function g = stak(tc, U, k)                    % nákvæmlega ein lína, annars fall
        tc.assertEqual(nnz(k), 1, 'vænti nákvæmlega einnar línu');
        g = U.gildi(k);
    end
end
end
