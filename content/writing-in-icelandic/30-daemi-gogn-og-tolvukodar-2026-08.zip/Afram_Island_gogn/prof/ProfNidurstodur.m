classdef ProfNidurstodur < matlab.unittest.TestCase
%% ProfNidurstodur: burðarniðurstöður greinarinnar reiknaðar úr frosnu gögnunum
% Keyrir forrit/reikna_nidurstodur.m einu sinni (les eingöngu gogn/gagnagrunnur.csv
% og gogn/handvirk_gogn.csv, ekkert net) og ber hverja burðartölu greinarinnar
% saman við gildið eins og það birtist. Vikmörk eru námundun birtingarinnar:
% hálf eining aftasta birta tugastafs; sæti og talningar eru nákvæm. Þekktu
% frávikið eina (K19b, skýrt í utreikningar.txt) er fullyrt
% sérstaklega svo ný frávik komist ekki inn óséð.
% Prófkeyrslan breytir engu í pakkanum: nidurstodur/ er tekin í
% skyndiafrit fyrir endurreikninginn og skilað óbreyttri í lokin.
% Keyrsla: runtests('prof') frá rót pakkans.

properties
    K     % containers.Map: merki talnaskrár -> reiknað gildi (tala)
    St    % containers.Map: merki -> staða ("OK"/"FRÁVIK")
    Nid   % slóð nidurstodur/
end

methods (TestClassSetup)
    function reikna(tc)
        rot = fileparts(fileparts(which(class(tc))));            % rót pakkans
        tc.applyFixture(matlab.unittest.fixtures.PathFixture(fullfile(rot, 'forrit')));
        % skyndiafrit af nidurstodur/ svo runtests skili möppunni óbreyttri
        nid = fullfile(rot, 'nidurstodur');
        afrit = fullfile(tempname, 'nidurstodur');
        copyfile(nid, afrit);
        tc.addTeardown(@() endurheimta(nid, afrit));
        R = keyra_reikna(rot);
        tc.K  = containers.Map(cellstr([R{:,1}]), ...
            num2cell(str2double(strrep([R{:,3}], ',', '.'))));
        tc.St = containers.Map(cellstr([R{:,1}]), cellstr([R{:,6}]));
        tc.Nid = nid;
    end
end

methods (Test)
    function voxtur_a_mann(tc)             % 0,86 vs 1,39 og 23. sæti af 28
        tc.verifyEqual(tc.K('K02a'), 0.86, 'AbsTol', 0.005);
        tc.verifyEqual(tc.K('K02b'), 1.39, 'AbsTol', 0.005);
        tc.verifyEqual(tc.K('K03'), 23);
    end

    function verdlag_og_adlagadur_kvardi(tc)   % 161,7 dýrast; Grikkland efst aðlagað
        tc.verifyEqual(tc.K('K10a'), 161.7, 'AbsTol', 0.05);
        tc.verifyEqual(tc.K('K10b'), 1);                     % ÍS dýrast af 28
        tc.verifyEqual(tc.K('K14a'), 152.9, 'AbsTol', 0.05); % Grikkland
        tc.verifyEqual(tc.K('K14c'), 25);                    % sæti ÍS aðlagað
        m9 = readtable(fullfile(tc.Nid, 'm9.csv'), 'FileType', 'text', ...
            'Delimiter', ';', 'TextType', 'string', 'VariableNamingRule', 'preserve');
        tc.verifyEqual(m9.land(m9.spjald == "tekjuleidrett" & m9.saeti == 1), ...
            "Grikkland");
        tc.verifyEqual(m9.land(m9.spjald == "verdlag" & m9.saeti == 1), "Ísland");
    end

    function fisher_raunvextir(tc)         % 5,50 á Íslandi vs 0,77 á evrusvæðinu
        tc.verifyEqual(tc.K('K18a'), 5.50, 'AbsTol', 0.005);
        tc.verifyEqual(tc.K('K18b'), 0.77, 'AbsTol', 0.005);
    end

    function jafngreidsludaemi(tc)         % 333 þús. á móti 220 þús. á mánuði
        tc.verifyEqual(tc.K('K22a'), 333, 'AbsTol', 0.5);
        tc.verifyEqual(tc.K('K22b'), 220, 'AbsTol', 0.5);
        tc.verifyEqual(tc.K('K23'), 114, 'AbsTol', 0.5);     % munurinn: um 114 þús.
        tc.verifyEqual(tc.K('K59'), 1.4, 'AbsTol', 0.05);    % um 1,4 m.kr. á ári
    end

    function naemnidaemi_verdlags(tc)      % K15: 82 (evruleið) og jafnstaða M=1,00 (launaleið)
        tc.verifyEqual(tc.K('K15b'), 82, 'AbsTol', 0.5);
        tc.verifyEqual(tc.K('K15d'), 1.00, 'AbsTol', 0.005);
    end

    function m8_kroatia_og_29_radir(tc)    % Króatía -0,68 í raunvaxtaspjaldi; 29 raðir
        m8 = readtable(fullfile(tc.Nid, 'm8.csv'), 'FileType', 'text', ...
            'Delimiter', ';', 'TextType', 'string', 'VariableNamingRule', 'preserve');
        tc.verifyEqual(m8.gildi(m8.spjald == "raunvextir" & m8.land == "Króatía"), ...
            -0.68, 'AbsTol', 0.005);
        tc.verifyEqual(nnz(m8.spjald == "raunvextir" & m8.saeti > 0), 29);
    end

    function m10_haekkandi_rodun(tc)       % M10 raðað frá lægstu skuldum
        m10 = readtable(fullfile(tc.Nid, 'm10.csv'), 'FileType', 'text', ...
            'Delimiter', ';', 'TextType', 'string', 'VariableNamingRule', 'preserve');
        p = sortrows(m10(m10.spjald == "arid_2025" & m10.saeti > 0, :), 'saeti');
        tc.verifyTrue(issorted(p.gildi), 'M10 á að vera hækkandi (lægstu skuldir fyrst)');
        tc.verifyEqual(p.saeti(p.land == "Ísland"), 13);
    end

    function fyrsta_greidsla_vaxtahluti(tc)    % K57: 225 og um 39 þús.kr. í vexti
        tc.verifyEqual(tc.K('K57a'), 225, 'AbsTol', 0.5);
        tc.verifyEqual(tc.K('K57b'), 39, 'AbsTol', 0.5);
    end

    function vlf_a_hvern_25_54(tc)         % K56: prime-age vísitalan 121 og 5. sæti
        tc.verifyEqual(tc.K('K56a'), 121, 'AbsTol', 0.5);
        tc.verifyEqual(tc.K('K56b'), 5);
    end

    function ungmenni_argangskvardi(tc)    % 7,9 vs 6,2; Svíþjóð 13,9 efst
        tc.verifyEqual(tc.K('K26a'), 7.9, 'AbsTol', 0.05);
        tc.verifyEqual(tc.K('K26b'), 6.2, 'AbsTol', 0.05);
        tc.verifyEqual(tc.K('K28d'), 13.9, 'AbsTol', 0.05);
        tc.verifyEqual(tc.K('K28e'), 1);                     % Svíþjóð í 1. sæti
    end

    function framleidni_uppsofnun(tc)      % 52,0% frá 2000 og 14. sæti
        tc.verifyEqual(tc.K('K29a'), 52.0, 'AbsTol', 0.05);
        tc.verifyEqual(tc.K('K29b'), 14);
    end

    function skuldir_hins_opinbera(tc)     % 56,1 vs 81,7 og 13. sæti frá lægstu
        tc.verifyEqual(tc.K('K35a'), 56.1, 'AbsTol', 0.05);
        tc.verifyEqual(tc.K('K35b'), 81.7, 'AbsTol', 0.05);
        tc.verifyEqual(tc.K('K35c'), 13);
    end

    function atvinnuleysi_manadarlegt(tc)  % 5,8 vs 5,9 og 14. sæti
        tc.verifyEqual(tc.K('K38a'), 5.8, 'AbsTol', 0.05);
        tc.verifyEqual(tc.K('K38b'), 5.9, 'AbsTol', 0.05);
        tc.verifyEqual(tc.K('K38c'), 14);
    end

    function gengislaekkanir_innan_ars(tc) % hæsta->lægsta dagsgildi ISK/EUR
        vaent = containers.Map({'K41a','K41b','K41c','K41d','K41e'}, ...
            {-19.3, -24.2, -51.7, -14.8, -18.0});
        for merki = ["K41a","K41b","K41c","K41d","K41e"]
            tc.verifyEqual(tc.K(char(merki)), vaent(char(merki)), 'AbsTol', 0.05, ...
                "gengislækkun " + merki);
        end
    end

    function flokt_glugginn(tc)            % 9,2 (ISK/USD) vs 7,3-7,4 (EUR/USD) 2014-2026
        tc.verifyEqual(tc.K('K40a1'), 9.2, 'AbsTol', 0.06);
        tc.verifyGreaterThanOrEqual(tc.K('K40a2'), 7.25);
        tc.verifyLessThanOrEqual(tc.K('K40a2'), 7.45);
    end

    function hofudborgir_m11(tc)           % 21. sæti í tekjum; staðgengilsbil 131-138
        tc.verifyEqual(tc.K('K53b'), 21);
        tc.verifyEqual(tc.K('K52b'), 131, 'AbsTol', 0.5);
        tc.verifyEqual(tc.K('K52c'), 138, 'AbsTol', 0.5);
    end

    function heildarstada(tc)              % engin ný frávik umfram það eina skýrða
        % K19b: ECB endurskoðaði apríl-tölu Lettlands (4,18 -> 4,15).
        merki = tc.St.keys;
        fravik = merki(cellfun(@(m) strcmp(tc.St(m), 'FRÁVIK'), merki));
        tc.verifyEqual(sort(fravik), {'K19b'});
    end
end
end

%% ================= Hjálparföll =================
function R = keyra_reikna(rot)
% Keyrir reikna_nidurstodur.m (skriftu) í vinnusvæði þessa falls og skilar
% R-safnlistanum {merki, lýsing, reiknað, í grein, vikmörk, staða}.
R = cell(0, 6);                              % forlýst svo skriftan fylli í listann
skipun = sprintf('run(''%s'')', fullfile(rot, 'forrit', 'reikna_nidurstodur.m'));
evalc(skipun);
end

function endurheimta(nid, afrit)
% Skilar nidurstodur/ nákvæmlega eins og hún var fyrir prófkeyrsluna
if exist(nid, 'dir'); rmdir(nid, 's'); end
copyfile(afrit, nid);
rmdir(fileparts(afrit), 's');
end
