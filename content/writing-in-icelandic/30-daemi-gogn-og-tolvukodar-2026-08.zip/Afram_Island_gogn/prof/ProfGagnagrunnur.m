classdef ProfGagnagrunnur < matlab.unittest.TestCase
%% ProfGagnagrunnur: skema- og landaprófanir á gogn/gagnagrunnur.csv
% Fullyrðir að birti gagnagrunnurinn hafi rétt skema (átta dálkar, semíkommur,
% UTF-8), að tölugildin séu öll gild, að EES-ríki utan ESB (Noregur, Sviss,
% Bretland) komi hvergi fyrir og að hver ESB-panelröð hafi réttan landafjölda:
% 28 lönd (27 ESB-ríki + Ísland) nema þar sem gagnalind sleppir landi, hver
% undantekning er skráð berum orðum hér. Keyrsla: runtests('prof') frá rót pakkans.

properties
    T        % gagnagrunnur.csv sem strengjatafla
    G        % tölugildi (str2double á gildi-dálkinn)
end

properties (Constant)
    KOD = ["BE","BG","CZ","DK","DE","EE","IE","EL","ES","FR","HR","IT","CY","LV", ...
           "LT","LU","HU","MT","NL","AT","PL","PT","RO","SI","SK","FI","SE"];
    EU  = "EU27_2020";
end

methods (TestClassSetup)
    function lesa(tc)
        rot = fileparts(fileparts(which(class(tc))));            % rót pakkans
        o = delimitedTextImportOptions('NumVariables', 8, 'Delimiter', ';', ...
            'VariableNames', {'rod','svaedi','timi','gildi','eining','gagnasafn', ...
            'api_slod','sott_dags'}, 'VariableTypes', repmat({'string'}, 1, 8), ...
            'DataLines', 2, 'Encoding', 'UTF-8');
        tc.T = readtable(fullfile(rot, 'gogn', 'gagnagrunnur.csv'), o);
        tc.G = str2double(tc.T.gildi);
    end
end

methods (Test)
    function skema(tc)
        % Haus, gild tölugildi, engir tómir lyklar, sott_dags á ISO-sniði
        tc.verifyEqual(tc.T.Properties.VariableNames, ...
            {'rod','svaedi','timi','gildi','eining','gagnasafn','api_slod','sott_dags'});
        tc.verifyTrue(all(isfinite(tc.G)), 'öll gildi eiga að vera gildar tölur');
        for d = ["rod","svaedi","timi","eining","gagnasafn","sott_dags"]
            tc.verifyTrue(all(strlength(tc.T.(d)) > 0), "tómt stak í dálki " + d);
        end
        tc.verifyTrue(all(~cellfun(@isempty, ...
            regexp(cellstr(tc.T.sott_dags), '^\d{4}-\d{2}-\d{2}$', 'once'))));
    end

    function lyklar_einkvaemir(tc)
        % (rod, svaedi, timi) er einkvæmur lykill hverrar línu
        tc.verifyEqual(numel(unique(tc.T.rod + ";" + tc.T.svaedi + ";" + tc.T.timi)), ...
            height(tc.T));
    end

    function engin_efta_riki(tc)
        % NO/CH/UK (og samheiti) hvergi, hvorki sem landakóði né í svæðakóðum
        bann = ["NO","CH","UK","GB","NOR","CHE","GBR"];
        tc.verifyEmpty(intersect(unique(tc.T.svaedi), bann));
        tc.verifyFalse(any(~cellfun(@isempty, ...
            regexp(cellstr(tc.T.svaedi), '^(NO|CH|UK|GB)[0-9_]', 'once'))));
    end

    function full_panelradir(tc)
        % Raðirnar með fullt safn: 27 ESB-ríki + Ísland + ESB-27 samtalan (29 svæði)
        fullar = ["hagvoxtur","hagvoxtur_a_mann","vlf_a_mann_visitala", ...
            "vlf_a_mann_evrur","vlf_a_mann_pps","vlf_mpps","mannfjoldi_1jan", ...
            "atvinnuleysi_15_74", ...
            "atvinnuleysi_15_24","atvinnuleysi_manadarlegt","atvinnuthatttaka_15_24", ...
            "vinnuafl_15_24","neet_15_24","neet_15_29","raunneysla_a_mann_esb100", ...
            "framleidni_a_starfandi_esb100","framleidni_a_vinnustund_esb100", ...
            "framleidni_a_vinnustund_esb100_nama","framleidni_vinnustund_10ara", ...
            "framleidni_vinnustund_i15","verdlag_E011", ...
            arrayfun(@(d) sprintf("verdlag_A01%02d", d), 1:12)];
        vaent = sort([tc.KOD, "IS", tc.EU])';
        for r = fullar
            tc.verifyEqual(sort(unique(tc.T.svaedi(tc.T.rod == r))), vaent, ...
                "röðin " + r + " hefur ekki réttu 29 svæðin");
        end
    end

    function skrad_undantekningar(tc)
        % Raðir þar sem gagnalindin sjálf sleppir landi, undantekningin skráð hér
        s = @(r) sort(unique(tc.T.svaedi(tc.T.rod == r)));
        % yth_empl_140: Lúxemborg vantar hjá Eurostat 2025
        tc.verifyEqual(s("atvinnuleysishlutfall_15_24"), ...
            sort([setdiff(tc.KOD, "LU"), "IS", tc.EU])');
        % lc_lci_lev: Belgíu vantar hjá Eurostat 2025
        tc.verifyEqual(s("launakostnadur_a_klst"), ...
            sort([setdiff(tc.KOD, "BE"), "IS", tc.EU])');
        % gov_10dd_edpt1: Ísland er ekki í Maastricht-safninu (ÍS-talan kemur úr AGS)
        tc.verifyEqual(s("skuldir_hins_opinbera_maastricht"), sort([tc.KOD, tc.EU])');
        tc.verifyEqual(s("skuldir_hins_opinbera"), "ISL");
    end

    function aldursradir_25_54(tc)
        % demo_pjan stakir aldrar Y25..Y54 (nefnari VLF á hvern 25-54 ára):
        % hver aldursröð hefur öll 29 svæðin (27 ESB-ríki + IS + ESB-27 samtalan)
        % og nákvæmlega árin 2024 og 2025 (1. janúar hvors árs)
        vaent = sort([tc.KOD, "IS", tc.EU])';
        for a = 25:54
            r = "mannfjoldi_Y" + a;
            tc.verifyEqual(sort(unique(tc.T.svaedi(tc.T.rod == r))), vaent, ...
                "röðin " + r + " hefur ekki réttu 29 svæðin");
            tc.verifyEqual(sort(unique(tc.T.timi(tc.T.rod == r))), ["2024"; "2025"], ...
                "röðin " + r + " hefur ekki árin 2024 og 2025");
        end
    end

    function hofudborgaradir(tc)
        % Stórborgarsvæðin: 27 ESB-höfuðborgir (*MC), Amsterdam = NL002MC, ekkert Osló
        s = sort(unique(tc.T.svaedi(tc.T.rod == "vlf_storborgarsvaedis_esb100")));
        mc = [arrayfun(@(k) k + "001MC", setdiff(tc.KOD, "NL")), "NL002MC"];
        tc.verifyEqual(s, sort(mc)');
        % Leiðréttingarstuðlar framkvæmdastjórnarinnar: 26 *_CAP + IS_CAP (NL vantar)
        c = sort(unique(tc.T.svaedi(tc.T.rod == "leidrettingarstudull_hofudborg")));
        tc.verifyEqual(c, sort([arrayfun(@(k) k + "_CAP", setdiff(tc.KOD, "NL")), "IS_CAP"])');
        % OECD-ráðstöfunartekjur: allar 28 höfuðborgir (þ.m.t. IS01) til fyrir 2023
        OK2 = ["AT13","BE1","BG41","CYP","CZ01","DE3","DK01","EE00","EL30","ES30", ...
               "FI1B","FR1","HR05","HU11","IE06","ITI4","LT01","LU00","LV00","MT00", ...
               "NL32","PL91","PT1A","RO32","SE11","SI04","SK01","IS01"];
        h = tc.T.svaedi(tc.T.rod == "radstofunartekjur_B6N_a_ibua" & tc.T.timi == "2023");
        tc.verifyEmpty(setdiff(OK2, h), 'höfuðborgarsvæði vantar í OECD-röðina 2023');
    end

    function landafjoldi_27_eda_28(tc)
        % Hver ESB-panelröð hefur 27 eða 28 lönd þegar samtölur eru taldar frá
        radir = ["hagvoxtur","hagvoxtur_a_mann","vlf_a_mann_visitala","vlf_a_mann_evrur", ...
            "vlf_a_mann_pps","atvinnuleysi_15_74","atvinnuleysi_15_24", ...
            "atvinnuleysi_manadarlegt","atvinnuthatttaka_15_24","vinnuafl_15_24", ...
            "neet_15_24","neet_15_29","raunneysla_a_mann_esb100","verdlag_E011", ...
            "framleidni_a_starfandi_esb100","framleidni_a_vinnustund_esb100", ...
            "framleidni_a_vinnustund_esb100_nama","framleidni_vinnustund_10ara", ...
            "framleidni_vinnustund_i15","atvinnuleysishlutfall_15_24", ...
            "launakostnadur_a_klst","skuldir_hins_opinbera_maastricht", ...
            "vlf_storborgarsvaedis_esb100","leidrettingarstudull_hofudborg"];
        for r = radir
            n = numel(setdiff(unique(tc.T.svaedi(tc.T.rod == r)), tc.EU));
            tc.verifyTrue(n == 27 || n == 28, ...
                sprintf('röðin %s: %d lönd, vænti 27 eða 28', r, n));
        end
    end
end
end
