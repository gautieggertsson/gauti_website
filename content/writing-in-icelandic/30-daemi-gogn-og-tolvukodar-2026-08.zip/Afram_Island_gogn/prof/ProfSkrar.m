classdef ProfSkrar < matlab.unittest.TestCase
%% ProfSkrar: formlegur CSV-samningur inntaksskránna og talnaskrárinnar
% Fullyrðir að hver einasta lína hafi nákvæmlega réttan reitafjölda þegar
% skipt er á semíkommum utan tvöfaldra gæsalappa (RFC-4180-regla með
% semíkommuskilum): talnaskra.csv 7 reiti, gogn/handvirk_gogn.csv 9 reiti,
% gogn/gagnagrunnur.csv 8 reiti, og að gæsalappir hverrar línu gangi upp.
% Keyrsla: runtests('prof') frá rót pakkans.

properties
    Rot   % rót pakkans
end

methods (TestClassSetup)
    function finna(tc)
        tc.Rot = fileparts(fileparts(which(class(tc))));
    end
end

methods (Test)
    function talnaskra(tc)
        reitaprof(tc, fullfile(tc.Rot, 'talnaskra.csv'), 7);
    end

    function handvirk_gogn(tc)
        reitaprof(tc, fullfile(tc.Rot, 'gogn', 'handvirk_gogn.csv'), 9);
    end

    function gagnagrunnur(tc)
        reitaprof(tc, fullfile(tc.Rot, 'gogn', 'gagnagrunnur.csv'), 8);
    end
end
end

%% ================= Hjálparföll =================
function reitaprof(tc, skra, vaent)
% Telur reiti hverrar línu með gæsalappavitund og fullyrðir nákvæman fjölda
linur = splitlines(string(fileread(skra, 'Encoding', 'UTF-8')));
linur = linur(strlength(linur) > 0);                 % síðasta línubil fellt
tc.assertGreaterThan(numel(linur), 1, skra + ": engin gögn");
for j = 1:numel(linur)
    [n, lokad] = telja_reiti(char(linur(j)));
    tc.verifyTrue(lokad, sprintf('%s lína %d: gæsalappir ganga ekki upp', skra, j));
    tc.verifyEqual(n, vaent, sprintf('%s lína %d: %d reitir, vænti %d', skra, j, n, vaent));
end
end

function [n, lokad] = telja_reiti(l)
% Skipt á ';' utan gæsalappa samkvæmt RFC-4180: gæsalöpp er aðeins merkingarbær
% í upphafi reits (þá afmarkar hún reitinn, "" er varin gæsalöpp og á eftir
% lokagæsalöppinni má aðeins koma ';' eða lok línu); gæsalöpp inni í óvörðum
% reit er venjulegur stafur.
n = 1; lokad = true; j = 1; byrjun = true;
while j <= numel(l)
    if byrjun && l(j) == '"'
        j = j + 1; lokad = false;                    % varinn reitur: leita loka
        while j <= numel(l)
            if l(j) == '"'
                if j < numel(l) && l(j+1) == '"'; j = j + 2; continue; end
                lokad = true; j = j + 1; break
            end
            j = j + 1;
        end
        if ~lokad; return; end
        if j <= numel(l)                             % eftir lokun: ';' eða línulok
            if l(j) == ';'; n = n + 1; j = j + 1;    % byrjun helst true
            else; lokad = false; return
            end
        end
    elseif l(j) == ';'
        n = n + 1; byrjun = true; j = j + 1;
    else
        byrjun = false; j = j + 1;
    end
end
end
